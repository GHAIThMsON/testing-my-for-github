let workspaceDb = loadWorkspaceDatabase();
let state = getActiveWorkspace().data;
let selectedId = state.selectedId || state.tree.id;
let historyBack = [];
let historyForward = [];
let modalMode = { action: "create", parentId: null, editId: null };
let selectedType = "Topic";
let selectedWorkspaceTemplate = "red-team";
let dragBlockId = null;
let dragNodeId = null;
let activeBlockId = null;
let saveTimer = null;
let audioObjectUrl = null;
let youtubePlayer = null;
let youtubeReady = false;
let musicQueue = JSON.parse(localStorage.getItem("red-team-os-music-queue") || '["WGF9BdL7c3Y"]');
let musicIndex = 0;
let pendingAttachType = null;

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const els = {
  tree: $("#tree"), blocks: $("#blocks"), toc: $("#toc"), pageTitle: $("#pageTitle"), pageDescription: $("#pageDescription"), pageIcon: $("#pageIcon"), breadcrumb: $("#breadcrumb"),
  modal: $("#pageModal"), backdrop: $("#modalBackdrop"), modalTitle: $("#modalTitle"), modalPageTitle: $("#modalPageTitle"), modalPageIcon: $("#modalPageIcon"), typeSelect: $("#typeSelect"), statusSelect: $("#statusSelect"),
  commandPalette: $("#commandPalette"), commandInput: $("#commandInput"), commandResults: $("#commandResults"),
  contextMenu: $("#contextMenu"), selectionToolbar: $("#selectionToolbar"), slashMenu: $("#slashMenu"), dropZone: $("#dropZone"), subpagesPanel: $("#subpagesPanel"), toast: $("#toast"), allPagesPanel: $("#allPagesPanel"), backupPanel: $("#backupPanel"),
  statusBoardPanel: $("#statusBoardPanel"), workspaceDashboard: $("#workspaceDashboard"),
  workspaceModal: $("#workspaceModal"), workspaceList: $("#workspaceList"), workspaceName: $("#workspaceName"), workspaceIcon: $("#workspaceIcon"), sessionClock: $("#sessionClock")
};

init();

function init() {
  applySavedTheme();
  buildCustomSelect();
  buildStatusSelect();
  bindUI();
  initCursor();
  initBackground();
  initSessionTimer();
  initSidebarResize();
  renderAll();
}

function loadWorkspaceDatabase() {
  try {
    const raw = localStorage.getItem(WORKSPACES_KEY);
    if (raw) {
      const db = JSON.parse(raw);
      if (Array.isArray(db.workspaces) && db.workspaces.length) {
        db.workspaces.forEach(w => normalizeWorkspace(w.data));
        if (!db.activeId || !db.workspaces.some(w => w.id === db.activeId)) db.activeId = db.workspaces[0].id;
        return db;
      }
    }
  } catch {}

  const legacy = loadLegacyState();
  const db = {
    version: 2,
    activeId: "ws-red-team",
    workspaces: [{ id: "ws-red-team", name: "Red Team OS", icon: "☠️", template: "red-team", data: legacy }]
  };
  return db;
}

function loadLegacyState() {
  const keys = [STORAGE_KEY, ...(typeof LEGACY_STORAGE_KEYS !== "undefined" ? LEGACY_STORAGE_KEYS : [])];
  for (const key of keys) {
    try {
      const raw = localStorage.getItem(key);
      if (!raw) continue;
      const parsed = JSON.parse(raw);
      if (parsed?.tree?.id === "root-web") {
        parsed.tree = { ...structuredCloneSafe(ROOT_TREE), children: [parsed.tree] };
        parsed.selectedId = parsed.selectedId || "root-web";
      }
      normalizeWorkspace(parsed);
      return parsed;
    } catch {}
  }
  const fresh = { tree: structuredCloneSafe(ROOT_TREE), selectedId: "root-web", updatedAt: Date.now(), recent: [] };
  normalizeWorkspace(fresh);
  return fresh;
}

function getActiveWorkspace() {
  let ws = workspaceDb.workspaces.find(w => w.id === workspaceDb.activeId);
  if (!ws) {
    ws = workspaceDb.workspaces[0] || createWorkspace("Red Team OS", "☠️", "red-team");
    if (!workspaceDb.workspaces.length) workspaceDb.workspaces.push(ws);
    workspaceDb.activeId = ws.id;
  }
  normalizeWorkspace(ws.data);
  return ws;
}

function getWorkspaceById(id) {
  return workspaceDb.workspaces.find(w => w.id === id);
}

function normalizeWorkspace(workspace) {
  if (!workspace.tree) workspace.tree = structuredCloneSafe(ROOT_TREE);
  if (!Array.isArray(workspace.recent)) workspace.recent = [];
  ensureRedTeamStructure(workspace);
  flatten(workspace.tree).forEach(n => {
    if (!n.type) n.type = "Topic";
    if (!n.status) n.status = "Not Started";
    if (typeof n.favorite !== "boolean") n.favorite = false;
    if (!Array.isArray(n.children)) n.children = [];
    if (!Array.isArray(n.blocks)) n.blocks = defaultBlocks(n.title || "Untitled", n.type);
  });
}

function ensureRedTeamStructure(workspace) {
  const root = workspace?.tree;
  if (!root || root.template !== "red-team") return;
  if (!Array.isArray(root.children)) root.children = [];
  const existing = new Set(root.children.map(n => n.title));
  defaultRedTeamModules().forEach(module => {
    if (!existing.has(module.title)) {
      root.children.push(module);
      existing.add(module.title);
    }
  });
  const web = root.children.find(n => n.title === "Web Application Penetration Testing");
  if (web && typeof ensureWebPlaybook === "function") ensureWebPlaybook(web);
  workspace.redTeamModulesVersion = 3;
}

function saveState() {
  state.selectedId = selectedId;
  state.updatedAt = Date.now();
  normalizeWorkspace(state);
  const active = getActiveWorkspace();
  active.data = state;
  active.updatedAt = Date.now();
  try {
    localStorage.setItem(WORKSPACES_KEY, JSON.stringify(workspaceDb));
  } catch (e) {
    toast("Storage is full. Export a backup and remove heavy files if needed.");
  }
}
function scheduleSave() { clearTimeout(saveTimer); saveTimer = setTimeout(saveState, 160); }
function structuredCloneSafe(obj) { return JSON.parse(JSON.stringify(obj)); }

function renderAll() {
  renderWorkspaceSwitcher();
  renderTree();
  renderPage();
  renderStats();
  renderWorkspaceDashboard();
}

function renderTree() {
  els.tree.innerHTML = "";
  (state.tree.children || []).forEach(child => els.tree.appendChild(renderNode(child, 0)));
}

function renderNode(node, depth) {
  const wrap = document.createElement("div");
  wrap.className = "tree-node";
  wrap.dataset.id = node.id;

  const row = document.createElement("div");
  row.className = "tree-row" + (node.id === selectedId ? " active" : "");
  row.draggable = true;
  row.dataset.id = node.id;
  row.innerHTML = `
    <span class="twisty">${node.children?.length ? (node.expanded ? "▾" : "▸") : ""}</span>
    <span class="node-icon">${escapeHtml(node.icon || "◦")}</span>
    <span class="node-title">${escapeHtml(node.title)}</span>
    <span class="node-pin">${node.favorite ? "★" : ""}</span>
    <span class="node-type">${escapeHtml(shortType(node.type))}</span>
  `;

  row.addEventListener("click", (e) => {
    if (e.target.classList.contains("twisty") && node.children?.length) {
      node.expanded = !node.expanded;
      scheduleSave(); renderTree();
      return;
    }
    selectPage(node.id);
  });
  row.addEventListener("dblclick", () => openPageModal("edit", null, node.id));
  row.addEventListener("contextmenu", (e) => showNodeContext(e, node.id));
  row.addEventListener("dragstart", (e) => { dragNodeId = node.id; e.dataTransfer.effectAllowed = "move"; });
  row.addEventListener("dragover", (e) => { e.preventDefault(); row.classList.add("drag-over"); });
  row.addEventListener("dragleave", () => row.classList.remove("drag-over"));
  row.addEventListener("drop", (e) => {
    e.preventDefault(); row.classList.remove("drag-over");
    if (!dragNodeId || dragNodeId === node.id) return;
    moveNodeInto(dragNodeId, node.id);
    dragNodeId = null;
  });

  wrap.appendChild(row);
  if (node.expanded && node.children?.length) {
    const kids = document.createElement("div");
    kids.className = "tree-children";
    node.children.forEach(child => kids.appendChild(renderNode(child, depth + 1)));
    wrap.appendChild(kids);
  }
  return wrap;
}
function shortType(t) { return t === "Vulnerability" ? "Vuln" : t === "Folder" ? "" : t; }

function renderPage() {
  const node = findNode(selectedId) || state.tree.children?.[0] || state.tree;
  selectedId = node.id;
  els.pageTitle.textContent = node.title;
  els.pageDescription.textContent = node.description || `Editable ${node.type.toLowerCase()} page.`;
  els.pageIcon.textContent = node.icon || "◦";
  els.breadcrumb.textContent = getPath(node.id).map(n => n.title).join(" / ");
  renderSubpages(node);
  renderBlocks(node);
  renderToc(node);
  renderPageControls(node);
}

function renderSubpages(node) {
  if (!els.subpagesPanel) return;
  const children = Array.isArray(node.children) ? node.children : [];
  if (!children.length) {
    els.subpagesPanel.innerHTML = `
      <div class="subpages-title">
        <span>Subpages</span>
        <button id="subpageAddBtn" title="Add subpage">＋ New</button>
      </div>
      <div class="empty-subpages">No subpages yet. Add a section, topic, lab, tool, or any custom page.</div>
    `;
  } else {
    els.subpagesPanel.innerHTML = `
      <div class="subpages-title">
        <span>Subpages</span>
        <button id="subpageAddBtn" title="Add subpage">＋ New</button>
      </div>
      ${children.map(child => `
        <button class="subpage-row" data-subpage-open="${child.id}" data-subpage-id="${child.id}">
          <span class="subpage-icon">${escapeHtml(child.icon || "◦")}</span>
          <span class="subpage-title">${escapeHtml(child.title || "Untitled")}</span>
          <span class="subpage-meta">${escapeHtml(child.type || "Page")}</span>
        </button>
      `).join("")}
    `;
  }
  els.subpagesPanel.querySelector("#subpageAddBtn")?.addEventListener("click", () => openPageModal("create", node.id));
  els.subpagesPanel.querySelectorAll("[data-subpage-open]").forEach(row => {
    row.addEventListener("click", () => selectPage(row.dataset.subpageOpen));
    row.addEventListener("contextmenu", (e) => showNodeContext(e, row.dataset.subpageOpen));
    row.draggable = true;
    row.addEventListener("dragstart", (e) => { dragNodeId = row.dataset.subpageId; e.dataTransfer.effectAllowed = "move"; });
    row.addEventListener("dragover", (e) => { e.preventDefault(); row.classList.add("drag-over"); });
    row.addEventListener("dragleave", () => row.classList.remove("drag-over"));
    row.addEventListener("drop", (e) => {
      e.preventDefault(); row.classList.remove("drag-over");
      if (!dragNodeId || dragNodeId === row.dataset.subpageId) return;
      moveNodeInto(dragNodeId, row.dataset.subpageId);
      dragNodeId = null;
    });
  });
}

function renderBlocks(node) {
  els.blocks.innerHTML = "";
  if (!node.blocks) node.blocks = defaultBlocks(node.title, node.type);
  if (!node.blocks.length) {
    els.blocks.appendChild(renderInsertRow(0, "Start writing or press + to add a block"));
    return;
  }
  node.blocks.forEach((block, index) => {
    els.blocks.appendChild(renderBlock(block, index));
    els.blocks.appendChild(renderInsertRow(index + 1));
  });
}

function renderInsertRow(index, label = "Add block") {
  const row = document.createElement("div");
  row.className = "block-insert-row";
  row.innerHTML = `<button title="Add block here"><span>＋</span>${escapeHtml(label)}</button>`;
  row.querySelector("button").addEventListener("click", () => addBlock("text", "", index));
  row.addEventListener("dragover", (e) => { e.preventDefault(); row.classList.add("drag-over"); });
  row.addEventListener("dragleave", () => row.classList.remove("drag-over"));
  row.addEventListener("drop", (e) => {
    e.preventDefault(); row.classList.remove("drag-over");
    const files = [...(e.dataTransfer?.files || [])];
    if (files.length) {
      files.forEach((file, offset) => addFileAsBlock(file, index + offset));
      return;
    }
    if (dragBlockId) {
      moveBlockToIndex(dragBlockId, index);
      dragBlockId = null;
    }
  });
  return row;
}

function renderBlock(block, index) {
  const node = findNode(selectedId);
  const div = document.createElement("div");
  div.className = `block block-${block.type}`;
  div.draggable = true;
  div.dataset.id = block.id;
  div.innerHTML = `<div class="drag-handle" title="Drag">⋮⋮</div>`;

  const body = document.createElement("div");
  body.className = "block-body";

  if (block.type === "toggle") {
    body.innerHTML = `
      <div class="toggle-head"><span class="toggle-arrow">${block.open ? "▾" : "▸"}</span><span class="block-content" contenteditable="true" spellcheck="false"></span></div>
      <div class="toggle-body ${block.open ? "" : "hidden"}" contenteditable="true" spellcheck="false"></div>
    `;
    const title = body.querySelector(".block-content");
    const child = body.querySelector(".toggle-body");
    title.textContent = block.content || "Toggle Heading";
    child.textContent = block.children || "";
    body.querySelector(".toggle-arrow").addEventListener("click", () => { block.open = !block.open; scheduleSave(); renderPage(); });
    title.addEventListener("input", () => { block.content = title.textContent; scheduleSave(); renderToc(node); });
    child.addEventListener("input", () => { block.children = child.textContent; scheduleSave(); });
    title.addEventListener("focus", () => { activeBlockId = block.id; });
    child.addEventListener("focus", () => { activeBlockId = block.id; });
    title.addEventListener("keydown", handleBlockKey);
    child.addEventListener("keydown", handleSlashKey);
  } else if (block.type === "checklist") {
    body.innerHTML = `<label class="checkline"><input type="checkbox" ${block.checked ? "checked" : ""}><span class="block-content" contenteditable="true" spellcheck="false" data-placeholder="To-do"></span></label>`;
    const cb = body.querySelector("input");
    const content = body.querySelector(".block-content");
    content.textContent = block.content || "";
    cb.addEventListener("change", () => { block.checked = cb.checked; scheduleSave(); });
    content.addEventListener("input", () => { block.content = content.textContent; scheduleSave(); });
    content.addEventListener("keydown", handleSlashKey);
    content.addEventListener("focus", () => { activeBlockId = block.id; });
  } else if (["bulleted", "numbered"].includes(block.type)) {
    body.innerHTML = `<div class="list-line ${block.type}"><span class="list-marker">${block.type === "numbered" ? (index + 1) + "." : "•"}</span><span class="block-content" contenteditable="true" spellcheck="false" data-placeholder="List item"></span></div>`;
    const content = body.querySelector(".block-content");
    content.textContent = block.content || "";
    content.addEventListener("input", () => { block.content = content.textContent; scheduleSave(); });
    content.addEventListener("keydown", handleBlockKey);
    content.addEventListener("focus", () => { activeBlockId = block.id; });
  } else if (block.type === "callout") {
    body.innerHTML = `<div class="callout-line"><span class="callout-icon">✦</span><span class="block-content" contenteditable="true" spellcheck="false" data-placeholder="Callout"></span></div>`;
    const content = body.querySelector(".block-content");
    content.textContent = block.content || "";
    content.addEventListener("input", () => { block.content = content.textContent; scheduleSave(); });
    content.addEventListener("keydown", handleBlockKey);
    content.addEventListener("focus", () => { activeBlockId = block.id; });
  } else if (block.type === "page") {
    body.innerHTML = `<button class="page-block"><span>▣</span><span class="block-content" contenteditable="true" spellcheck="false" data-placeholder="Page title"></span></button>`;
    const content = body.querySelector(".block-content");
    content.textContent = block.content || "";
    content.addEventListener("input", () => { block.content = content.textContent; scheduleSave(); });
    content.addEventListener("keydown", handleBlockKey);
    content.addEventListener("focus", () => { activeBlockId = block.id; });
  } else if (block.type === "code") {
    body.innerHTML = `<div class="code-card"><button class="code-copy" title="Copy code">Copy</button><pre class="block-content" contenteditable="true" spellcheck="false" data-placeholder="Code or copy-ready note"></pre></div>`;
    const content = body.querySelector(".block-content");
    content.textContent = block.content || "";
    content.addEventListener("input", () => { block.content = content.textContent; scheduleSave(); });
    content.addEventListener("keydown", handleBlockKey);
    content.addEventListener("focus", () => { activeBlockId = block.id; });
    body.querySelector(".code-copy").addEventListener("click", async () => { await navigator.clipboard.writeText(block.content || ""); toast("Copied"); });
  } else if (block.type === "divider") {
    body.innerHTML = `<hr class="block-divider" aria-hidden="true">`;
  } else if (block.type === "image") {
    body.innerHTML = `<figure class="block-image"><img alt="Attached image"><figcaption contenteditable="true" spellcheck="false"></figcaption></figure>`;
    const img = body.querySelector("img");
    const cap = body.querySelector("figcaption");
    img.src = block.src || "";
    cap.textContent = block.caption || "Image note";
    cap.addEventListener("input", () => { block.caption = cap.textContent; scheduleSave(); });
  } else if (block.type === "file") {
    const size = block.size ? formatSize(block.size) : "file";
    body.innerHTML = `<a class="file-chip" href="${block.src || "#"}" download="${escapeHtml(block.name || "file")}">📎 ${escapeHtml(block.name || "Attached file")} <small>${size}</small></a>`;
  } else {
    const content = document.createElement("div");
    content.className = "block-content";
    content.contentEditable = true;
    content.spellcheck = false;
    content.textContent = block.content || "";
    content.dataset.placeholder = placeholderFor(block.type) || "Type / for commands";
    content.addEventListener("input", () => { block.content = content.textContent; scheduleSave(); if (["heading","subheading","heading3","heading4"].includes(block.type)) renderToc(node); });
    content.addEventListener("keydown", handleBlockKey);
    content.addEventListener("focus", () => { activeBlockId = block.id; });
    body.appendChild(content);
  }

  const actions = document.createElement("div");
  actions.className = "block-actions";
  actions.innerHTML = `
    <button class="icon-btn" title="Move up">↑</button>
    <button class="icon-btn" title="Move down">↓</button>
    <button class="icon-btn" title="Change type">⋯</button>
    <button class="icon-btn" title="Duplicate">⧉</button>
    <button class="icon-btn" title="Delete">×</button>
  `;
  const [upBtn, downBtn, typeBtn, dupBtn, delBtn] = actions.querySelectorAll("button");
  upBtn.addEventListener("click", () => moveBlock(block.id, -1));
  downBtn.addEventListener("click", () => moveBlock(block.id, 1));
  typeBtn.addEventListener("click", (e) => showBlockContext(e, block.id));
  dupBtn.addEventListener("click", () => duplicateBlock(block.id));
  delBtn.addEventListener("click", () => deleteBlock(block.id));

  div.appendChild(body);
  div.appendChild(actions);
  div.addEventListener("dragstart", (e) => { dragBlockId = block.id; div.classList.add("dragging"); e.dataTransfer.effectAllowed = "move"; });
  div.addEventListener("dragend", () => { div.classList.remove("dragging"); dragBlockId = null; });
  div.addEventListener("dragover", (e) => { e.preventDefault(); if (dragBlockId && dragBlockId !== block.id) div.classList.add("drag-over"); });
  div.addEventListener("dragleave", () => div.classList.remove("drag-over"));
  div.addEventListener("drop", (e) => {
    e.preventDefault(); div.classList.remove("drag-over");
    const files = [...(e.dataTransfer?.files || [])];
    if (files.length) {
      const node = findNode(selectedId);
      const pos = node.blocks.findIndex(b => b.id === block.id) + 1;
      files.forEach((file, offset) => addFileAsBlock(file, pos + offset));
      return;
    }
    if (dragBlockId && dragBlockId !== block.id) reorderBlocks(dragBlockId, block.id);
  });
  div.addEventListener("mousedown", () => { activeBlockId = block.id; });
  div.addEventListener("contextmenu", (e) => showBlockContext(e, block.id));

  return div;
}

function placeholderFor(type) {
  return ({
    heading: "Heading 1", subheading: "Heading 2", heading3: "Heading 3", heading4: "Heading 4",
    text: "", quote: "", callout: "", code: "", bulleted: "", numbered: "", checklist: "", page: "Untitled page", divider: ""
  })[type] ?? "";
}

function renderToc(node) {
  els.toc.innerHTML = "";
  (node.blocks || []).filter(b => ["heading", "subheading", "heading3", "heading4", "toggle"].includes(b.type)).forEach((b) => {
    const li = document.createElement("li");
    li.textContent = b.content || "Untitled";
    li.addEventListener("click", () => document.querySelector(`.block[data-id="${b.id}"]`)?.scrollIntoView({ behavior: "smooth", block: "center" }));
    els.toc.appendChild(li);
  });
}

function renderStats() {
  // v1.1: dashboard counters were removed from the UI.
  // Keep this function as a safe no-op so older events do not break.
  const all = flatten(state.tree);
  const pages = all.filter(n => n.id !== state.tree.id);
  const pinned = pages.filter(n => n.favorite).length;
  const random = $("#randomTopicBtn");
  if (random) random.textContent = state.tree?.template === "programming" ? "Random Task" : "Random Topic";
}


function renderWorkspaceDashboard() {
  // v1.3: keep the page focused like Notion. Child pages now render as clean subpage rows inside the editor.
  if (els.workspaceDashboard) els.workspaceDashboard.innerHTML = "";
}


function renderPageControls(node) {
  if ($("#favoriteBtn")) {
    $("#favoriteBtn").textContent = node.favorite ? "★ Pinned" : "☆ Pin Page";
    $("#favoriteBtn").classList.toggle("active", !!node.favorite);
  }
}


function bindUI() {
  $("#newPageBtn").addEventListener("click", () => openPageModal("create", selectedId));
  $("#addRootBtn").addEventListener("click", () => openPageModal("create", state.tree.id));
  $("#workspaceSwitcher")?.addEventListener("click", openWorkspaceManager);
  $("#newWorkspaceBtn")?.addEventListener("click", () => openWorkspaceManager(true));
  $("#workspaceClose")?.addEventListener("click", closeWorkspaceManager);
  $("#workspaceCancel")?.addEventListener("click", closeWorkspaceManager);
  $("#workspaceCreate")?.addEventListener("click", createWorkspaceFromForm);
  $("#workspaceTemplates")?.querySelectorAll("button").forEach(btn => btn.addEventListener("click", () => selectWorkspaceTemplate(btn.dataset.template)));
  $("#addChildBtn").addEventListener("click", () => openPageModal("create", selectedId));
  $("#duplicatePageBtn").addEventListener("click", () => duplicatePage(selectedId));
  $("#deletePageBtn").addEventListener("click", () => deletePage(selectedId));
  $("#expandAllBtn").addEventListener("click", () => { flatten(state.tree).forEach(n => n.expanded = true); scheduleSave(); renderTree(); });
  $("#collapseAllBtn").addEventListener("click", () => { flatten(state.tree).forEach(n => { if (n.id !== state.tree.id) n.expanded = false; }); scheduleSave(); renderTree(); });
  $("#modalClose").addEventListener("click", closeModal);
  $("#modalCancel").addEventListener("click", closeModal);
  $("#modalSave").addEventListener("click", saveModalPage);
  els.backdrop.addEventListener("click", () => { closeModal(); closeAllPages(); closeStatusBoard(); closeBackupCenter(); closeWorkspaceManager(); });

  $("#themeBtn").addEventListener("click", toggleXenon);
  $("#audioBtn").addEventListener("click", playThemeAudio);
  $("#audioFile").addEventListener("change", handleAudioUpload);
  $("#musicClose")?.addEventListener("click", () => $("#musicDock").classList.add("hidden"));
  $("#musicNext")?.addEventListener("click", playNextTrack);
  $("#musicAddBtn")?.addEventListener("click", addTrackFromInput);
  $("#randomTopicBtn")?.addEventListener("click", randomTopic);
  $("#randomPayloadBtn")?.addEventListener("click", randomPayloadDrill);
  $("#homeBtn")?.addEventListener("click", () => selectPage(state.tree.id));
  $("#allPagesBtn")?.addEventListener("click", openAllPages);
  $("#allPagesClose")?.addEventListener("click", closeAllPages);
  $("#statusBoardBtn")?.addEventListener("click", openStatusBoard);
  $("#statusBoardClose")?.addEventListener("click", closeStatusBoard);
  $("#allPagesSearch")?.addEventListener("input", renderAllPagesTable);
  $("#backupBtn")?.addEventListener("click", openBackupCenter);
  $("#backupClose")?.addEventListener("click", closeBackupCenter);
  $("#backupExportJson")?.addEventListener("click", exportBackup);
  $("#backupExportWorkspace")?.addEventListener("click", exportCurrentWorkspace);
  $("#backupImportJson")?.addEventListener("click", () => $("#importFile").click());
  $("#backupClearLocal")?.addEventListener("click", clearLocalData);
  $("#favoriteBtn")?.addEventListener("click", toggleFavorite);
  $("#musicOpenCurrent")?.addEventListener("click", openCurrentTrack);
  $("#musicOpenQueue")?.addEventListener("click", openQueueOnYouTube);

  els.pageTitle.addEventListener("input", () => { const n = findNode(selectedId); n.title = els.pageTitle.textContent.trim() || "Untitled"; scheduleSave(); renderTree(); renderToc(n); });
  els.pageDescription.addEventListener("input", () => { const n = findNode(selectedId); n.description = els.pageDescription.textContent.trim(); scheduleSave(); });

  $$("[data-add-block]").forEach(btn => btn.addEventListener("click", () => requestAddBlock(btn.dataset.addBlock)));
  $$("[data-template]").forEach(btn => btn.addEventListener("click", () => insertTemplate(btn.dataset.template)));
  $("#imageAttachInput")?.addEventListener("change", (e) => handlePickedAttachment(e, "image"));
  $("#fileAttachInput")?.addEventListener("change", (e) => handlePickedAttachment(e, "file"));

  $("#commandBtn").addEventListener("click", openCommandPalette);
  $("#commandClose")?.addEventListener("click", closeCommandPalette);
  document.addEventListener("keydown", (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); openCommandPalette(); }
    if (e.key === "Escape") { hideFloating(); closeModal(); closeCommandPalette(); closeAllPages(); closeStatusBoard(); closeBackupCenter(); closeWorkspaceManager(); }
  });
  els.commandInput.addEventListener("input", renderCommandResults);

  document.addEventListener("click", (e) => {
    if (!els.commandPalette.classList.contains("hidden") && !els.commandPalette.contains(e.target) && e.target.id !== "commandBtn") closeCommandPalette();
    if (!els.contextMenu.contains(e.target)) els.contextMenu.classList.add("hidden");
    if (!els.slashMenu.contains(e.target)) els.slashMenu.classList.add("hidden");
    if (!els.typeSelect.contains(e.target)) els.typeSelect.classList.remove("open");
    if (els.statusSelect && !els.statusSelect.contains(e.target)) els.statusSelect.classList.remove("open");
  });
  document.addEventListener("selectionchange", handleSelectionToolbar);
  $("#googleSelectionBtn").addEventListener("click", () => {
    const t = getSelectionText(); if (t) window.open(`https://www.google.com/search?q=${encodeURIComponent(t)}`, "_blank");
    hideFloating();
  });
  $("#copySelectionBtn").addEventListener("click", async () => { const t = getSelectionText(); if (t) { await navigator.clipboard.writeText(t); toast("Copied"); } hideFloating(); });
  $("#quoteSelectionBtn").addEventListener("click", () => { const t = getSelectionText(); if (t) addBlock("quote", t); hideFloating(); });

  els.dropZone.addEventListener("dragover", (e) => { e.preventDefault(); els.dropZone.classList.add("drag-active"); });
  els.dropZone.addEventListener("dragleave", (e) => { if (!els.dropZone.contains(e.relatedTarget)) els.dropZone.classList.remove("drag-active"); });
  els.dropZone.addEventListener("drop", handleDropFiles);

  $("#exportBtn").addEventListener("click", exportBackup);
  $("#importBtn").addEventListener("click", () => $("#importFile").click());
  $("#importFile").addEventListener("change", importBackup);

  $("#backBtn").addEventListener("click", () => { const prev = historyBack.pop(); if (prev) { historyForward.push(selectedId); selectedId = prev; renderAll(); } });
  $("#forwardBtn").addEventListener("click", () => { const next = historyForward.pop(); if (next) { historyBack.push(selectedId); selectedId = next; renderAll(); } });
}

function selectPage(id, pushHistory = true) {
  if (!findNode(id)) return;
  if (pushHistory && selectedId !== id) { historyBack.push(selectedId); historyForward = []; }
  selectedId = id;
  touchRecent(id);
  scheduleSave(); renderAll();
}

function openPageModal(action = "create", parentId = selectedId, editId = null) {
  modalMode = { action, parentId, editId };
  const node = editId ? findNode(editId) : null;
  els.modalTitle.textContent = action === "edit" ? "Edit Page" : "New Page";
  els.modalPageTitle.value = node?.title || "";
  els.modalPageIcon.value = node?.icon || "";
  selectedType = node?.type || "Topic";
  els.typeSelect.querySelector(".select-value").textContent = selectedType;
  els.backdrop.classList.remove("hidden");
  els.modal.classList.remove("hidden");
  setTimeout(() => els.modalPageTitle.focus(), 30);
}
function closeModal() { els.modal.classList.add("hidden"); closeBackdropIfClear(); }
function saveModalPage() {
  const title = els.modalPageTitle.value.trim() || "Untitled";
  const icon = els.modalPageIcon.value.trim() || iconForType(selectedType);
  if (modalMode.action === "edit") {
    const n = findNode(modalMode.editId);
    if (n) { n.title = title; n.icon = icon; n.type = selectedType; n.description = n.description || `Editable ${selectedType.toLowerCase()} page.`; n.status = n.status || "Not Started"; if (typeof n.favorite !== "boolean") n.favorite = false; }
  } else {
    const parent = findNode(modalMode.parentId) || state.tree;
    if (!parent.children) parent.children = [];
    parent.expanded = true;
    const newNode = { id: uid(), title, icon, type: selectedType, status: "Not Started", favorite: false, expanded: true, description: "", blocks: [], children: [] };
    parent.children.push(newNode);
    selectedId = newNode.id;
  }
  closeModal(); scheduleSave(); renderAll();
}
function buildCustomSelect() {
  const optionsBox = els.typeSelect.querySelector(".select-options");
  optionsBox.innerHTML = PAGE_TYPES.map(t => `<div class="select-option" data-value="${t}">${t}</div>`).join("");
  els.typeSelect.addEventListener("click", (e) => { els.typeSelect.classList.toggle("open"); });
  optionsBox.querySelectorAll(".select-option").forEach(opt => opt.addEventListener("click", (e) => {
    selectedType = opt.dataset.value;
    els.typeSelect.querySelector(".select-value").textContent = selectedType;
    els.typeSelect.classList.remove("open");
    e.stopPropagation();
  }));
}
function buildStatusSelect() {
  if (!els.statusSelect) return;
  const optionsBox = els.statusSelect.querySelector(".select-options");
  optionsBox.innerHTML = STATUS_OPTIONS.map(t => `<div class="select-option" data-value="${t}">${t}</div>`).join("");
  els.statusSelect.addEventListener("click", (e) => { els.statusSelect.classList.toggle("open"); e.stopPropagation(); });
  optionsBox.querySelectorAll(".select-option").forEach(opt => opt.addEventListener("click", (e) => {
    const node = findNode(selectedId);
    if (!node) return;
    node.status = opt.dataset.value;
    els.statusSelect.querySelector(".select-value").textContent = node.status;
    els.statusSelect.classList.remove("open");
    scheduleSave(); renderStats(); renderAllPagesTable();
    e.stopPropagation();
  }));
}

function blocksForType(title, type) {
  if (type === "Vulnerability") return vulnerabilityBlocks(title);
  if (type === "Tool") return toolBlocks(title);
  if (type === "Lab") return labBlocks(title);
  if (type === "Writeup") return structuredCloneSafe(PAGE_TEMPLATES.writeup).map((b,i)=> i===0 ? {...b, content:title} : b);
  if (type === "Report") return structuredCloneSafe(PAGE_TEMPLATES.report).map((b,i)=> i===0 ? {...b, content:title} : b);
  if (type === "Forensics Case") return caseBlocks(title);
  if (type === "Programming Project") return projectBlocks(title);
  if (type === "Reverse Engineering") return reverseBlocks(title);
  if (type === "Research Note") return researchBlocks(title);
  if (type === "Snippet") return snippetBlocks(title);
  if (type === "Evidence") return evidenceBlocks(title);
  return defaultBlocks(title, type);
}
function iconForType(t) { return ({ Folder:"📁", Topic:"📌", Vulnerability:"🚨", Tool:"🛠️", Lab:"🧪", Writeup:"📚", Report:"📑", "Forensics Case":"🧬", "Programming Project":"💻", "Reverse Engineering":"🧩", "Research Note":"🕸️", Snippet:"🧩", Evidence:"🔎", Note:"📝" })[t] || "📌"; }

function requestAddBlock(type = "text") {
  if (type === "image") { pendingAttachType = "image"; $("#imageAttachInput")?.click(); return; }
  if (type === "file") { pendingAttachType = "file"; $("#fileAttachInput")?.click(); return; }
  addBlock(type);
}
function getActiveInsertIndex() {
  const node = findNode(selectedId);
  if (!node || !Array.isArray(node.blocks) || !activeBlockId) return null;
  const i = node.blocks.findIndex(b => b.id === activeBlockId);
  return i >= 0 ? i + 1 : null;
}
function addBlock(type = "text", content = null, index = null) {
  const node = findNode(selectedId);
  if (!node.blocks) node.blocks = [];
  const b = createBlock(type, content);
  const pos = index === null ? getActiveInsertIndex() : index;
  if (pos === null) node.blocks.push(b); else node.blocks.splice(pos, 0, b);
  activeBlockId = b.id;
  scheduleSave(); renderPage(); renderStats();
  setTimeout(() => document.querySelector(`.block[data-id="${b.id}"] .block-content`)?.focus(), 20);
}
function createBlock(type, content = null) {
  if (type === "checklist") return { id: uid(), type, checked: false, content: content ?? "" };
  if (type === "toggle") return { id: uid(), type, content: content ?? "", open: true, children: "" };
  if (type === "image") return { id: uid(), type, src: "", caption: content ?? "" };
  if (type === "file") return { id: uid(), type, name: "Attached file", src: "", size: 0 };
  if (type === "page") return { id: uid(), type, content: content ?? "Untitled page" };
  if (type === "divider") return { id: uid(), type };
  return { id: uid(), type, content: content ?? "" };
}
function insertTemplate(name) {
  const node = findNode(selectedId);
  const tpl = structuredCloneSafe(PAGE_TEMPLATES[name] || PAGE_TEMPLATES.vulnerability);
  node.blocks.push(...tpl.map(b => ({...b, id: uid()})));
  scheduleSave(); renderPage(); renderStats(); toast("Template inserted");
}
function duplicateBlock(id) {
  const n = findNode(selectedId), i = n.blocks.findIndex(b => b.id === id);
  if (i < 0) return;
  const copy = structuredCloneSafe(n.blocks[i]); copy.id = uid();
  n.blocks.splice(i + 1, 0, copy); scheduleSave(); renderPage(); renderStats();
}
function deleteBlock(id) {
  const n = findNode(selectedId);
  n.blocks = n.blocks.filter(b => b.id !== id);
  scheduleSave(); renderPage(); renderStats();
}
function changeBlockType(id, type) {
  const b = findNode(selectedId).blocks.find(x => x.id === id);
  if (!b) return;
  b.type = type;
  if (type === "toggle") { b.open = true; b.children = b.children || ""; }
  if (type === "checklist") b.checked = !!b.checked;
  scheduleSave(); renderPage();
}
function reorderBlocks(fromId, toId) {
  const n = findNode(selectedId);
  const from = n.blocks.findIndex(b => b.id === fromId), to = n.blocks.findIndex(b => b.id === toId);
  if (from < 0 || to < 0) return;
  const [item] = n.blocks.splice(from, 1);
  n.blocks.splice(to, 0, item);
  scheduleSave(); renderPage();
}
function moveBlock(id, delta) {
  const n = findNode(selectedId);
  if (!n?.blocks) return;
  const i = n.blocks.findIndex(b => b.id === id);
  const j = i + delta;
  if (i < 0 || j < 0 || j >= n.blocks.length) return;
  const [item] = n.blocks.splice(i, 1);
  n.blocks.splice(j, 0, item);
  activeBlockId = id;
  scheduleSave(); renderPage();
}
function moveBlockToIndex(id, index) {
  const n = findNode(selectedId);
  if (!n?.blocks) return;
  const i = n.blocks.findIndex(b => b.id === id);
  if (i < 0) return;
  const [item] = n.blocks.splice(i, 1);
  const safeIndex = Math.max(0, Math.min(index > i ? index - 1 : index, n.blocks.length));
  n.blocks.splice(safeIndex, 0, item);
  activeBlockId = id;
  scheduleSave(); renderPage();
}

function handleBlockKey(e) {
  handleSlashKey(e);
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    const blockEl = e.target.closest(".block");
    const node = findNode(selectedId);
    const i = node.blocks.findIndex(b => b.id === blockEl.dataset.id);
    addBlock("text", "", i + 1);
  }
}
function handleSlashKey(e) {
  activeBlockId = e.target.closest(".block")?.dataset.id || activeBlockId;
  if (e.key === "/") setTimeout(() => showSlashMenu(e.target), 0);
}
function showSlashMenu(target) {
  const text = target.textContent.trim();
  if (text !== "/") return;
  const r = target.getBoundingClientRect();
  const items = [
    ["heading", "H1", "Heading 1", "#"],
    ["subheading", "H2", "Heading 2", "##"],
    ["heading3", "H3", "Heading 3", "###"],
    ["heading4", "H4", "Heading 4", "####"],
    ["bulleted", "•", "Bulleted list", "-"],
    ["numbered", "1.", "Numbered list", "1."],
    ["checklist", "☐", "To-do list", "[]"],
    ["toggle", "▸", "Toggle list", ">"],
    ["page", "▣", "Page", ""],
    ["callout", "✦", "Callout", ""],
    ["quote", "❝", "Quote", ""],
    ["divider", "—", "Divider", ""],
    ["text", "T", "Text", ""],
    ["code", "{}", "Code", ""],
    ["payloadDrill", "⚡", "Random payload drill", "safe"],
    ["vulnerabilityTemplate", "V", "Vulnerability template", "tpl"],
    ["toolTemplate", "🛠", "Tool template", "tpl"],
    ["labTemplate", "🧪", "Lab template", "tpl"],
    ["image", "▧", "Image", ""],
    ["file", "⌁", "File", ""]
  ];
  els.slashMenu.innerHTML = items.map(([t, icon, label, hint]) => `<button data-type="${t}"><span class="slash-icon">${icon}</span><span class="slash-label">${label}</span><span class="slash-hint">${hint}</span></button>`).join("");
  els.slashMenu.style.left = Math.min(r.left, window.innerWidth - 330) + "px";
  els.slashMenu.style.top = Math.min(r.bottom + 8, window.innerHeight - 520) + "px";
  els.slashMenu.classList.remove("hidden");
  els.slashMenu.querySelectorAll("button").forEach(btn => btn.addEventListener("click", () => {
    const b = findNode(selectedId).blocks.find(x => x.id === activeBlockId);
    const type = btn.dataset.type;
    if (type === "payloadDrill") { if (b) b.content = ""; els.slashMenu.classList.add("hidden"); randomPayloadDrill(); return; }
    if (type === "vulnerabilityTemplate") { if (b) b.content = ""; els.slashMenu.classList.add("hidden"); insertTemplate("vulnerability"); return; }
    if (type === "toolTemplate") { if (b) b.content = ""; els.slashMenu.classList.add("hidden"); insertTemplate("tool"); return; }
    if (type === "labTemplate") { if (b) b.content = ""; els.slashMenu.classList.add("hidden"); insertTemplate("lab"); return; }
    if (type === "image" || type === "file") {
      if (b) { b.content = ""; }
      scheduleSave(); renderPage(); requestAddBlock(type); els.slashMenu.classList.add("hidden"); return;
    }
    if (b) { b.type = type; b.content = ""; if (b.type === "toggle") { b.open = true; b.children = ""; } }
    els.slashMenu.classList.add("hidden"); scheduleSave(); renderPage();
  }));
}

function showNodeContext(e, id) {
  e.preventDefault(); e.stopPropagation();
  selectedId = id; renderAll();
  const items = [
    ["Add child page", () => openPageModal("create", id)],
    ["Add top-level module", () => openPageModal("create", state.tree.id)],
    ["Rename / Edit", () => openPageModal("edit", null, id)],
    ["Duplicate", () => duplicatePage(id)],
    ["Delete", () => deletePage(id)]
  ];
  showMenu(e.clientX, e.clientY, items);
}
function showBlockContext(e, id) {
  e.preventDefault(); e.stopPropagation();
  const items = [
    ["Turn into Heading", () => changeBlockType(id, "heading")],
    ["Turn into Text", () => changeBlockType(id, "text")],
    ["Turn into Toggle", () => changeBlockType(id, "toggle")],
    ["Turn into Numbered list", () => changeBlockType(id, "numbered")],
    ["Turn into Bulleted list", () => changeBlockType(id, "bulleted")],
    ["Turn into Callout", () => changeBlockType(id, "callout")],
    ["Turn into Code", () => changeBlockType(id, "code")],
    ["Turn into Divider", () => changeBlockType(id, "divider")],
    ["Move Up", () => moveBlock(id, -1)],
    ["Move Down", () => moveBlock(id, 1)],
    ["Duplicate Block", () => duplicateBlock(id)],
    ["Delete Block", () => deleteBlock(id)]
  ];
  showMenu(e.clientX, e.clientY, items);
}
function showMenu(x, y, items) {
  els.contextMenu.innerHTML = "";
  items.forEach(([label, fn]) => {
    const b = document.createElement("button");
    b.textContent = label;
    b.addEventListener("click", () => { fn(); hideFloating(); });
    els.contextMenu.appendChild(b);
  });
  els.contextMenu.style.left = Math.min(x, window.innerWidth - 220) + "px";
  els.contextMenu.style.top = Math.min(y, window.innerHeight - 260) + "px";
  els.contextMenu.classList.remove("hidden");
}
function hideFloating() { els.contextMenu.classList.add("hidden"); els.selectionToolbar.classList.add("hidden"); els.slashMenu.classList.add("hidden"); }

function duplicatePage(id) {
  if (id === state.tree.id) return toast("Workspace root cannot be duplicated here");
  const found = findParentAndNode(id);
  if (!found) return;
  const copy = structuredCloneSafe(found.node);
  assignNewIds(copy);
  copy.title += " Copy";
  found.parent.children.splice(found.index + 1, 0, copy);
  selectedId = copy.id;
  scheduleSave(); renderAll();
}
function assignNewIds(n) { n.id = uid(); (n.blocks || []).forEach(b => b.id = uid()); (n.children || []).forEach(assignNewIds); }
function deletePage(id) {
  if (id === state.tree.id) return toast("Workspace root cannot be deleted");
  const found = findParentAndNode(id);
  if (!found) return;
  if (!confirm(`Delete "${found.node.title}"?`)) return;
  found.parent.children.splice(found.index, 1);
  selectedId = found.parent.id;
  scheduleSave(); renderAll();
}
function moveNodeInto(fromId, toId) {
  if (fromId === state.tree.id || isDescendant(fromId, toId)) return toast("Cannot move page there");
  const from = findParentAndNode(fromId), target = findNode(toId);
  if (!from || !target) return;
  const [node] = from.parent.children.splice(from.index, 1);
  if (!target.children) target.children = [];
  target.children.push(node); target.expanded = true;
  scheduleSave(); renderAll();
}
function isDescendant(parentId, childId) {
  const p = findNode(parentId);
  return flatten(p).some(n => n.id === childId);
}

function toggleFavorite() {
  const node = findNode(selectedId);
  if (!node || node.id === state.tree.id) return toast("Workspace root is always available");
  node.favorite = !node.favorite;
  scheduleSave(); renderTree(); renderPageControls(node); renderStats(); renderAllPagesTable();
  toast(node.favorite ? "Pinned" : "Unpinned");
}

function touchRecent(id) {
  if (!state.recent) state.recent = [];
  state.recent = [id, ...state.recent.filter(x => x !== id)].slice(0, 12);
}


function renderWorkspaceSwitcher() {
  const ws = getActiveWorkspace();
  if (els.workspaceName) els.workspaceName.textContent = ws.name;
  if (els.workspaceIcon) els.workspaceIcon.textContent = ws.icon || "◇";
  const brandTitle = $("#brandTitle");
  const brandSubtitle = $("#brandSubtitle");
  if (brandTitle) brandTitle.textContent = ws.name;
  if (brandSubtitle) brandSubtitle.textContent = workspaceSubtitle(ws.template);
  document.title = ws.name;
}
function workspaceSubtitle(template) {
  return ({"red-team":"Red Team Workspace", forensics:"Forensics Workspace", programming:"Programming Workspace", reverse:"Reverse Engineering Workspace", "dark-research":"Dark Research Workspace", study:"Study Workspace", blank:"Custom Workspace"})[template] || "Custom Workspace";
}

function openWorkspaceManager(focusCreate = false) {
  renderWorkspaceManager();
  els.backdrop.classList.remove("hidden");
  els.workspaceModal.classList.remove("hidden");
  if (focusCreate) setTimeout(() => $("#workspaceTitle")?.focus(), 30);
}

function closeWorkspaceManager() {
  if (!els.workspaceModal) return;
  els.workspaceModal.classList.add("hidden");
  closeBackdropIfClear();
}

function renderWorkspaceManager() {
  if (!els.workspaceList) return;
  els.workspaceList.innerHTML = workspaceDb.workspaces.map(ws => `
    <div class="workspace-item ${ws.id === workspaceDb.activeId ? "active" : ""}" data-ws="${ws.id}">
      <div class="workspace-item-main">
        <strong>${escapeHtml(ws.icon || "◇")} ${escapeHtml(ws.name)}</strong>
        <small>${escapeHtml(ws.template || "custom")} · ${flatten(ws.data.tree).length - 1} pages</small>
      </div>
      <div class="workspace-item-actions">
        <button data-switch-ws="${ws.id}">${ws.id === workspaceDb.activeId ? "Active" : "Switch"}</button>
        <button data-rename-ws="${ws.id}">Rename</button>
        <button data-duplicate-ws="${ws.id}">Duplicate</button>
        <button data-delete-ws="${ws.id}" class="danger-mini">Delete</button>
      </div>
    </div>
  `).join("");
  els.workspaceList.querySelectorAll("[data-switch-ws]").forEach(btn => btn.addEventListener("click", () => switchWorkspace(btn.dataset.switchWs)));
  els.workspaceList.querySelectorAll("[data-rename-ws]").forEach(btn => btn.addEventListener("click", () => renameWorkspace(btn.dataset.renameWs)));
  els.workspaceList.querySelectorAll("[data-duplicate-ws]").forEach(btn => btn.addEventListener("click", () => duplicateWorkspace(btn.dataset.duplicateWs)));
  els.workspaceList.querySelectorAll("[data-delete-ws]").forEach(btn => btn.addEventListener("click", () => deleteWorkspace(btn.dataset.deleteWs)));
}

function selectWorkspaceTemplate(template) {
  selectedWorkspaceTemplate = template || "blank";
  $("#workspaceTemplates")?.querySelectorAll("button").forEach(btn => btn.classList.toggle("active", btn.dataset.template === selectedWorkspaceTemplate));
  const title = $("#workspaceTitle");
  const icon = $("#workspaceIconInput");
  const presets = {
    "red-team": ["Red Team OS", "☠️"],
    reverse: ["Reverse Engineering", "🧩"],
    "dark-research": ["Dark Research", "🕸️"],
    forensics: ["Forensics Workspace", "🧬"],
    programming: ["Programming Workspace", "💻"],
    study: ["Study Workspace", "📚"],
    blank: ["Custom Workspace", "◇"]
  };
  const p = presets[selectedWorkspaceTemplate] || presets.blank;
  if (title && !title.value.trim()) title.placeholder = `Example: ${p[0]}`;
  if (icon && !icon.value.trim()) icon.placeholder = `Example: ${p[1]}`;
}

function createWorkspaceFromForm() {
  const presets = {
    "red-team": ["Red Team OS", "☠️"],
    reverse: ["Reverse Engineering", "🧩"],
    "dark-research": ["Dark Research", "🕸️"],
    forensics: ["Forensics Workspace", "🧬"],
    programming: ["Programming Workspace", "💻"],
    study: ["Study Workspace", "📚"],
    blank: ["Custom Workspace", "◇"]
  };
  const p = presets[selectedWorkspaceTemplate] || presets.blank;
  const name = $("#workspaceTitle").value.trim() || p[0];
  const icon = $("#workspaceIconInput").value.trim() || p[1];
  const ws = createWorkspace(name, icon, selectedWorkspaceTemplate);
  saveState();
  workspaceDb.workspaces.push(ws);
  workspaceDb.activeId = ws.id;
  state = ws.data;
  selectedId = state.selectedId || state.tree.id;
  historyBack = []; historyForward = [];
  $("#workspaceTitle").value = "";
  $("#workspaceIconInput").value = "";
  saveState(); closeWorkspaceManager(); renderAll(); toast("Workspace created");
}

function createWorkspace(name, icon, template = "blank") {
  const root = createWorkspaceRoot(name, icon, template);
  const data = { tree: root, selectedId: root.id, updatedAt: Date.now(), recent: [] };
  normalizeWorkspace(data);
  return { id: uid(), name, icon, template, updatedAt: Date.now(), data };
}

function pageOfType(icon, title, type) {
  return { id: uid(), title, icon, type, status: "Not Started", favorite: false, expanded: false, description: `Editable ${type.toLowerCase()} page.`, blocks: blocksForType(title, type), children: [] };
}

function createWorkspaceRoot(name, icon, template) {
  if (template === "red-team") {
    const root = structuredCloneSafe(ROOT_TREE);
    assignNewIds(root);
    root.title = name; root.icon = icon || "☠️"; root.template = "red-team"; root.description = "Editable red team workspace. Add, delete, rename, and reshape modules freely.";
    root.blocks = workspaceDashboardBlocks(name, "red-team");
    return root;
  }
  const root = { id: uid(), title: name, icon: icon || "◇", type: "Workspace", template, status: "Learning", favorite: true, expanded: true, description: `A flexible ${name} workspace.`, blocks: workspaceDashboardBlocks(name, template), children: [] };
  if (template === "forensics") {
    root.children = [
      folder("🧾", "Cases", [pageOfType("🧬", "New Case", "Forensics Case"), topic("⏱️", "Timeline"), topic("🔗", "Chain of Custody")]),
      folder("💽", "Disk & File Analysis", [topic("📁", "File Systems"), topic("🧩", "Artifacts"), topic("🗑️", "Deleted Files"), pageOfType("🔎", "Evidence Notes", "Evidence")]),
      folder("🧠", "Memory Forensics", [topic("⚙️", "Processes"), topic("🌐", "Network Connections"), topic("🧬", "Suspicious Indicators")]),
      folder("🌐", "Network Forensics", [topic("📦", "PCAP Notes"), topic("🔌", "Connections"), topic("🧭", "Timeline Mapping")]),
      folder("🪟", "Windows Artifacts", [topic("📜", "Event Logs"), topic("🧾", "Registry"), topic("🧩", "Prefetch")]),
      folder("🐧", "Linux Artifacts", [topic("📜", "Logs"), topic("👤", "Users"), topic("⏱️", "Cron")]),
      folder("🧰", "Tools", [tool("🧪", "Autopsy"), tool("🧠", "Volatility"), tool("📦", "ExifTool"), tool("🌐", "Wireshark")])
    ];
  } else if (template === "programming") {
    root.children = [
      folder("🧭", "Roadmap", [topic("📌", "Goals"), topic("✅", "Tasks"), topic("📚", "Resources")]),
      folder("💻", "Languages", [topic("🐍", "Python"), topic("🟨", "JavaScript"), topic("⚙️", "C / C++"), topic("🦀", "Rust")]),
      folder("🧱", "Projects", [pageOfType("🚀", "New Project", "Programming Project"), topic("🧪", "Experiments"), topic("🐞", "Bug Notes")]),
      folder("📦", "Snippets", [pageOfType("🧩", "Reusable Snippets", "Snippet"), topic("🗃️", "Data Structures"), topic("🌐", "Web Snippets")]),
      folder("🛠️", "Tools", [tool("📝", "VS Code"), tool("🌿", "Git"), tool("📦", "Package Managers")])
    ];
  } else if (template === "reverse") {
    root.children = [
      folder("🧭", "Reverse Roadmap", [topic("📌", "Goals"), topic("📚", "References"), topic("✅", "Practice Queue")]),
      folder("🧩", "Samples & Labs", [pageOfType("🧪", "New Analysis", "Reverse Engineering"), topic("🎯", "Crackmes"), topic("🧬", "Malware Analysis Notes")]),
      folder("🔎", "Static Analysis", [topic("🔤", "Strings"), topic("📦", "Sections"), topic("🔌", "Imports"), topic("🧠", "Functions")]),
      folder("⚙️", "Dynamic Analysis", [topic("🧪", "Sandbox Notes"), topic("🧾", "Logs"), topic("📸", "Screenshots")]),
      folder("🛠️", "Tools", [tool("🧠", "Ghidra"), tool("🔬", "x64dbg"), tool("📦", "Detect It Easy"), tool("🧪", "Cutter")])
    ];
  } else if (template === "dark-research") {
    root.children = [
      folder("🕸️", "Research Notes", [pageOfType("🧿", "New Research Note", "Research Note"), topic("📌", "Questions"), topic("📚", "References")]),
      folder("🧭", "OPSEC & Safety", [topic("🛡️", "Boundaries"), topic("🧾", "Source Log"), topic("⚖️", "Legal Notes")]),
      folder("📰", "Threat Intel", [topic("🧩", "Indicators"), topic("🏷️", "Actors"), topic("⏱️", "Timeline")]),
      folder("📎", "Media & Evidence", [pageOfType("🔎", "Evidence Notes", "Evidence"), topic("📸", "Screenshots"), topic("📄", "Files")])
    ];
  } else if (template === "study") {
    root.children = [
      folder("📚", "Subjects", [topic("📖", "Subject 1"), topic("🧠", "Weak Points"), topic("📝", "Summaries")]),
      folder("✅", "Tasks", [topic("📌", "Today"), topic("🗓️", "Weekly Review"), topic("🎯", "Goals")]),
      folder("🧪", "Practice", [topic("❓", "Questions"), topic("🧩", "Exercises"), topic("📎", "Files")]),
      folder("🔖", "References", [topic("🌐", "Websites"), topic("📄", "PDFs"), topic("🎥", "Videos")])
    ];
  }
  return root;
}

function switchWorkspace(id) {
  const ws = getWorkspaceById(id);
  if (!ws) return;
  saveState();
  workspaceDb.activeId = id;
  state = ws.data;
  normalizeWorkspace(state);
  selectedId = state.selectedId || state.tree.id;
  historyBack = []; historyForward = [];
  saveState(); closeWorkspaceManager(); renderAll(); toast(`Switched to ${ws.name}`);
}

function renameWorkspace(id) {
  const ws = getWorkspaceById(id); if (!ws) return;
  const name = prompt("Workspace name", ws.name); if (!name) return;
  const icon = prompt("Workspace icon", ws.icon || "◇") || ws.icon || "◇";
  ws.name = name.trim(); ws.icon = icon.trim(); ws.data.tree.title = ws.name; ws.data.tree.icon = ws.icon;
  if (id === workspaceDb.activeId) { state = ws.data; selectedId = state.selectedId || state.tree.id; }
  saveState(); renderWorkspaceManager(); renderAll(); toast("Workspace renamed");
}

function duplicateWorkspace(id) {
  const ws = getWorkspaceById(id); if (!ws) return;
  const copy = structuredCloneSafe(ws);
  copy.id = uid(); copy.name = ws.name + " Copy"; copy.updatedAt = Date.now();
  assignNewIds(copy.data.tree); copy.data.selectedId = copy.data.tree.id;
  workspaceDb.workspaces.push(copy);
  saveState(); renderWorkspaceManager(); toast("Workspace duplicated");
}

function deleteWorkspace(id) {
  if (workspaceDb.workspaces.length <= 1) return toast("Keep at least one workspace");
  const ws = getWorkspaceById(id); if (!ws) return;
  if (!confirm(`Delete workspace "${ws.name}"?`)) return;
  workspaceDb.workspaces = workspaceDb.workspaces.filter(w => w.id !== id);
  if (workspaceDb.activeId === id) {
    workspaceDb.activeId = workspaceDb.workspaces[0].id;
    state = getActiveWorkspace().data;
    selectedId = state.selectedId || state.tree.id;
  }
  saveState(); renderWorkspaceManager(); renderAll(); toast("Workspace deleted");
}

function closeBackdropIfClear() {
  const panels = [els.modal, els.allPagesPanel, els.backupPanel, els.statusBoardPanel, els.workspaceModal, els.commandPalette].filter(Boolean);
  if (panels.every(p => p.classList.contains("hidden"))) els.backdrop.classList.add("hidden");
}


function openStatusBoard() {
  if (!els.statusBoardPanel) return;
  renderStatusBoard();
  els.backdrop.classList.remove("hidden");
  els.statusBoardPanel.classList.remove("hidden");
}
function closeStatusBoard() {
  if (!els.statusBoardPanel) return;
  els.statusBoardPanel.classList.add("hidden");
  closeBackdropIfClear();
}
function renderStatusBoard() {
  const board = $("#kanbanBoard");
  if (!board) return;
  const pages = flatten(state.tree).filter(n => n.id !== state.tree.id);
  board.innerHTML = STATUS_OPTIONS.map(status => {
    const items = pages.filter(p => (p.status || "Not Started") === status);
    return `<div class="kanban-column" data-status="${escapeHtml(status)}">
      <div class="kanban-title">${escapeHtml(status)} <span>${items.length}</span></div>
      <div class="kanban-items">${items.map(n => `<button class="kanban-card" draggable="true" data-board-open="${n.id}" data-board-id="${n.id}">${escapeHtml(n.icon||"◦")} ${escapeHtml(n.title)}<small>${escapeHtml(n.type||"Topic")}</small></button>`).join("") || `<small class="empty-board">Empty</small>`}</div>
    </div>`;
  }).join("");
  board.querySelectorAll("[data-board-open]").forEach(btn => btn.addEventListener("click", () => { closeStatusBoard(); selectPage(btn.dataset.boardOpen); }));
  board.querySelectorAll(".kanban-card").forEach(card => card.addEventListener("dragstart", e => { e.dataTransfer.setData("text/plain", card.dataset.boardId); }));
  board.querySelectorAll(".kanban-column").forEach(col => {
    col.addEventListener("dragover", e => { e.preventDefault(); col.classList.add("drag-over"); });
    col.addEventListener("dragleave", () => col.classList.remove("drag-over"));
    col.addEventListener("drop", e => {
      e.preventDefault(); col.classList.remove("drag-over");
      const id = e.dataTransfer.getData("text/plain");
      const n = findNode(id);
      if (n) { n.status = col.dataset.status; scheduleSave(); renderStatusBoard(); renderPageControls(findNode(selectedId)); renderStats(); }
    });
  });
}

function openAllPages() {
  renderAllPagesTable();
  els.backdrop.classList.remove("hidden");
  els.allPagesPanel.classList.remove("hidden");
}
function closeAllPages() {
  els.allPagesPanel.classList.add("hidden");
  closeBackdropIfClear();
}
function renderAllPagesTable() {
  const body = $("#allPagesBody"); if (!body) return;
  const q = ($("#allPagesSearch")?.value || "").toLowerCase().trim();
  const pages = flatten(state.tree)
    .filter(n => n.id !== state.tree.id)
    .filter(n => !q || [n.title, n.type, getParentTitle(n.id), blockText(n)].join(" ").toLowerCase().includes(q));
  body.innerHTML = pages.map(n => `
    <tr data-id="${n.id}">
      <td><button class="table-page-open" data-open="${n.id}">${n.favorite ? "★" : "☆"} ${escapeHtml(n.icon || "◦")} ${escapeHtml(n.title)}</button></td>
      <td>${escapeHtml(n.type || "Topic")}</td>
      <td>${escapeHtml(getParentTitle(n.id))}</td>
      <td>${n.blocks?.length || 0}</td>
      <td class="table-actions"><button data-pin="${n.id}">${n.favorite ? "Unpin" : "Pin"}</button><button data-edit="${n.id}">Edit</button></td>
    </tr>`).join("");
  body.querySelectorAll("[data-open]").forEach(b => b.addEventListener("click", () => { closeAllPages(); selectPage(b.dataset.open); }));
  body.querySelectorAll("[data-edit]").forEach(b => b.addEventListener("click", () => openPageModal("edit", null, b.dataset.edit)));
  body.querySelectorAll("[data-pin]").forEach(b => b.addEventListener("click", () => { const n = findNode(b.dataset.pin); n.favorite = !n.favorite; scheduleSave(); renderTree(); renderStats(); renderAllPagesTable(); }));
}
function blockText(n) { return (n.blocks || []).map(b => [b.content, b.body, b.name, b.caption].filter(Boolean).join(" ")).join(" "); }
function getParentTitle(id) { const found = findParentAndNode(id); return found?.parent?.title || "Workspace"; }

function openBackupCenter() { els.backdrop.classList.remove("hidden"); els.backupPanel.classList.remove("hidden"); }
function closeBackupCenter() { els.backupPanel.classList.add("hidden"); closeBackdropIfClear(); }
function clearLocalData() {
  if (!confirm("Clear all local workspace data from this browser? Export first if you need it.")) return;
  localStorage.removeItem(WORKSPACES_KEY);
  localStorage.removeItem(STORAGE_KEY);
  workspaceDb = { version: 2, activeId: "ws-red-team", workspaces: [{ id: "ws-red-team", name: "Red Team OS", icon: "☠️", template: "red-team", data: { tree: structuredCloneSafe(ROOT_TREE), selectedId: "root-web", updatedAt: Date.now(), recent: [] } }] };
  state = getActiveWorkspace().data;
  selectedId = state.selectedId || state.tree.id;
  saveState(); closeBackupCenter(); renderAll(); toast("Local data reset");
}

function openCommandPalette() {
  els.commandPalette.classList.remove("hidden");
  els.commandInput.value = "";
  renderCommandResults();
  setTimeout(() => els.commandInput.focus(), 20);
}
function closeCommandPalette() { els.commandPalette.classList.add("hidden"); }
function renderCommandResults() {
  const q = els.commandInput.value.toLowerCase().trim();
  const pages = flatten(state.tree).filter(n => !q || n.title.toLowerCase().includes(q) || (n.blocks || []).some(b => JSON.stringify(b).toLowerCase().includes(q))).slice(0, 35);
  const commands = [
    { icon:"◇", title:"Open Workspace Manager", type:"Command", fn: () => openWorkspaceManager() },
    { icon:"＋", title:"Create New Page", type:"Command", fn: () => openPageModal("create", selectedId) },
    { icon:"📁", title:"Create Top-Level Module", type:"Command", fn: () => openPageModal("create", state.tree.id) },
    { icon:"▦", title:"Open All Pages Database", type:"Command", fn: openAllPages },
    { icon:"💾", title:"Open Backup Center", type:"Command", fn: openBackupCenter },
    { icon:"📤", title:"Export Current Workspace", type:"Command", fn: exportCurrentWorkspace },
    { icon:"🧩", title:"Insert Vulnerability Template", type:"Template", fn: () => insertTemplate("vulnerability") },
    { icon:"🛠️", title:"Insert Tool Template", type:"Template", fn: () => insertTemplate("tool") },
    { icon:"🧪", title:"Insert Lab Template", type:"Template", fn: () => insertTemplate("lab") },
    { icon:"🧬", title:"Insert Case Template", type:"Template", fn: () => insertTemplate("case") },
    { icon:"💻", title:"Insert Project Template", type:"Template", fn: () => insertTemplate("project") }
  ].filter(c => !q || c.title.toLowerCase().includes(q));
  els.commandResults.innerHTML = "";
  commands.forEach(c => addCommandItem(c.icon, c.title, c.type, () => { closeCommandPalette(); c.fn(); }));
  pages.forEach(n => addCommandItem(n.icon, n.title, n.type, () => { closeCommandPalette(); selectPage(n.id); }));
}
function addCommandItem(icon, title, type, fn) {
  const el = document.createElement("div");
  el.className = "command-item";
  el.innerHTML = `<span>${escapeHtml(icon || "◦")}</span><div>${escapeHtml(title)}<br><small>${escapeHtml(type || "Page")}</small></div><small>Open</small>`;
  el.addEventListener("click", fn);
  els.commandResults.appendChild(el);
}

function handleSelectionToolbar() {
  const txt = getSelectionText();
  if (!txt || txt.length < 2) { els.selectionToolbar.classList.add("hidden"); return; }
  const sel = window.getSelection();
  if (!sel.rangeCount) return;
  const range = sel.getRangeAt(0);
  const parent = range.commonAncestorContainer.parentElement;
  if (!parent?.closest(".page-panel")) return;
  const r = range.getBoundingClientRect();
  els.selectionToolbar.style.left = Math.min(r.left, window.innerWidth - 340) + "px";
  els.selectionToolbar.style.top = Math.max(8, r.top - 48) + "px";
  els.selectionToolbar.classList.remove("hidden");
}
function getSelectionText() { return window.getSelection()?.toString().trim() || ""; }

function handleDropFiles(e) {
  e.preventDefault();
  els.dropZone.classList.remove("drag-active");
  const files = [...(e.dataTransfer?.files || [])];
  if (!files.length && dragBlockId) return;
  const insertAt = getActiveInsertIndex();
  files.forEach((file, offset) => addFileAsBlock(file, insertAt === null ? null : insertAt + offset));
}
function handlePickedAttachment(e, kind) {
  const files = [...(e.target.files || [])];
  if (!files.length) return;
  const insertAt = getActiveInsertIndex();
  files.forEach((file, offset) => addFileAsBlock(file, insertAt === null ? null : insertAt + offset));
  e.target.value = "";
}
function addFileAsBlock(file, insertIndex = null) {
  const reader = new FileReader();
  reader.onload = () => {
    const node = findNode(selectedId);
    const block = file.type.startsWith("image/")
      ? { id: uid(), type: "image", src: reader.result, caption: file.name }
      : { id: uid(), type: "file", name: file.name, size: file.size, src: reader.result };
    if (insertIndex === null) node.blocks.push(block); else node.blocks.splice(insertIndex, 0, block);
    scheduleSave(); renderPage(); renderStats(); toast("Attached: " + file.name);
  };
  reader.readAsDataURL(file);
}

function exportBackup() {
  saveState();
  const blob = new Blob([JSON.stringify(workspaceDb, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = `knowledge-os-all-workspaces-${new Date().toISOString().slice(0,10)}.json`; a.click();
  URL.revokeObjectURL(url);
}
function exportCurrentWorkspace() {
  saveState();
  const ws = getActiveWorkspace();
  const payload = { version: 2, activeId: ws.id, workspaces: [structuredCloneSafe(ws)] };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const safe = (ws.name || "workspace").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  a.href = url; a.download = `${safe || "workspace"}-${new Date().toISOString().slice(0,10)}.json`; a.click();
  URL.revokeObjectURL(url);
  toast("Current workspace exported");
}
function importBackup(e) {
  const file = e.target.files?.[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const imported = JSON.parse(reader.result);
      if (Array.isArray(imported.workspaces)) {
        workspaceDb = imported;
        workspaceDb.workspaces.forEach(w => normalizeWorkspace(w.data));
        if (!workspaceDb.activeId || !workspaceDb.workspaces.some(w => w.id === workspaceDb.activeId)) workspaceDb.activeId = workspaceDb.workspaces[0].id;
      } else if (imported.tree) {
        normalizeWorkspace(imported);
        workspaceDb = { version: 2, activeId: uid(), workspaces: [{ id: uid(), name: imported.tree.title || "Imported Workspace", icon: imported.tree.icon || "📦", template: "imported", data: imported }] };
        workspaceDb.activeId = workspaceDb.workspaces[0].id;
      } else {
        throw new Error("Invalid backup");
      }
      state = getActiveWorkspace().data; selectedId = state.selectedId || state.tree.id;
      saveState(); renderAll(); renderWorkspaceManager(); toast("Backup imported");
    } catch { toast("Invalid backup file"); }
  };
  reader.readAsText(file);
  e.target.value = "";
}

function toggleXenon() {
  const h = Math.floor(Math.random() * 360);
  const p = [
    hslToHex(h, 100, 58),
    hslToHex((h + 78) % 360, 100, 70),
    hslToHex((h + 162) % 360, 100, 62),
    hslToHex((h + 245) % 360, 100, 55)
  ];
  applyNeonPalette(p);
  localStorage.setItem(THEME_KEY, JSON.stringify(p));
  toast("Xenon spectrum shifted");
}
function hslToHex(h, s, l) {
  s /= 100; l /= 100;
  const k = n => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return "#" + [f(0), f(8), f(4)].map(x => Math.round(255*x).toString(16).padStart(2,"0")).join("");
}
function applyNeonPalette(p) {
  document.body.classList.add("xenon");
  document.body.style.setProperty("--accent", p[0]);
  document.body.style.setProperty("--accent2", p[1]);
  document.body.style.setProperty("--accent3", p[2]);
  document.body.style.setProperty("--accent4", p[3] || p[1]);
  document.body.style.setProperty("--line2", p[0] + "aa");
  document.body.style.setProperty("--shadow", `0 0 42px ${p[0]}aa, 0 0 110px ${p[1]}77, 0 0 190px ${p[2]}55, 0 0 260px ${p[3] || p[1]}33`);
}
function applySavedTheme() {
  try {
    const raw = localStorage.getItem(THEME_KEY);
    if (raw && raw.startsWith("[")) applyNeonPalette(JSON.parse(raw));
    else if (raw === "xenon") applyNeonPalette(["#00e5ff", "#8cfffb", "#b13cff"]);
  } catch {}
}
function playThemeAudio() {
  const dock = $("#musicDock");
  dock.classList.toggle("hidden");
  if (!dock.classList.contains("hidden")) startYouTubeQueue();
}
function handleAudioUpload(e) {
  const file = e.target.files?.[0]; if (!file) return;
  if (audioObjectUrl) URL.revokeObjectURL(audioObjectUrl);
  audioObjectUrl = URL.createObjectURL(file);
  const a = new Audio(audioObjectUrl);
  a.volume = .6;
  a.play().then(() => toast("Local audio playing"));
}
function startYouTubeQueue() {
  renderMusicQueue();
  renderYouTubeFrame(true);
}
function renderYouTubeFrame(autoplay = false) {
  const holder = $("#ytPlayer");
  if (!holder || !musicQueue.length) return;
  const id = musicQueue[musicIndex] || musicQueue[0];
  const ids = musicQueue.length ? musicQueue : [id];
  const ordered = [id, ...ids.filter((x, i) => x !== id || i === musicIndex).filter((_, i) => i > 0)];
  const playlist = encodeURIComponent(ids.join(","));
  const auto = autoplay ? "&autoplay=1" : "";
  const src = `https://www.youtube-nocookie.com/embed/${encodeURIComponent(id)}?rel=0&modestbranding=1&playsinline=1&enablejsapi=1&loop=1&playlist=${playlist}${auto}`;
  holder.innerHTML = `<iframe title="Shadow Audio Queue" src="${src}" allow="autoplay; encrypted-media; picture-in-picture" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>`;
}
function playNextTrack() {
  if (!musicQueue.length) return;
  musicIndex = (musicIndex + 1) % musicQueue.length;
  renderMusicQueue();
  renderYouTubeFrame(true);
}
function addTrackFromInput() {
  const input = $("#musicUrlInput");
  const id = parseYouTubeId(input.value.trim());
  if (!id) return toast("Invalid YouTube link");
  musicQueue.push(id);
  localStorage.setItem("red-team-os-music-queue", JSON.stringify(musicQueue));
  input.value = "";
  renderMusicQueue();
  toast("Track added to queue");
}
function parseYouTubeId(url) {
  if (/^[a-zA-Z0-9_-]{11}$/.test(url)) return url;
  const m = url.match(/(?:v=|youtu\.be\/|embed\/|shorts\/)([a-zA-Z0-9_-]{11})/);
  return m ? m[1] : null;
}
function renderMusicQueue() {
  const list = $("#musicQueue"); if (!list) return;
  list.innerHTML = musicQueue.map((id, i) => `<button class="queue-item ${i===musicIndex?'active':''}" data-i="${i}">${i+1}. ${escapeHtml(id)}</button>`).join("");
  list.querySelectorAll(".queue-item").forEach(btn => btn.addEventListener("click", () => {
    musicIndex = Number(btn.dataset.i);
    renderMusicQueue(); renderYouTubeFrame(true);
  }));
}
function openCurrentTrack() {
  const id = musicQueue[musicIndex] || "WGF9BdL7c3Y";
  window.open(`https://www.youtube.com/watch?v=${encodeURIComponent(id)}`, "_blank");
}
function openQueueOnYouTube() {
  const ids = musicQueue.length ? musicQueue : ["WGF9BdL7c3Y"];
  window.open(`https://www.youtube.com/watch_videos?video_ids=${encodeURIComponent(ids.join(","))}`, "_blank");
}

function randomTopic() {
  const candidates = flatten(state.tree).filter(n => n.id !== state.tree.id && n.type !== "Folder" && n.type !== "Workspace");
  const n = candidates[Math.floor(Math.random() * candidates.length)];
  if (n) { selectPage(n.id); toast("Random: " + n.title); }
  else toast("No topics yet");
}
function randomPayloadDrill() {
  const drills = typeof SAFE_PAYLOAD_DRILLS !== "undefined" ? SAFE_PAYLOAD_DRILLS : [];
  if (!drills.length) return toast("No payload drills loaded");
  const d = drills[Math.floor(Math.random() * drills.length)];
  addBlock("callout", `Random Payload Drill — ${d.category}: ${d.note}`);
  toast("Inserted random payload drill");
}

function initSessionTimer() {
  const el = els.sessionClock || $("#sessionClock");
  if (!el) return;
  const started = Date.now();
  const pad = (n) => String(n).padStart(2, "0");
  function tick() {
    const total = Math.floor((Date.now() - started) / 1000);
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const sec = total % 60;
    el.textContent = `◉ ${pad(h)}:${pad(m)}:${pad(sec)}`;
  }
  tick();
  setInterval(tick, 1000);
}

function initCursor() {
  document.documentElement.classList.add("custom-cursor-ready");
  const dot = $("#cursorDot"), glow = $("#cursorGlow");
  if (!dot || !glow) return;
  let gx = 0, gy = 0, dx = innerWidth/2, dy = innerHeight/2, lastSpark = 0, angle = 0;
  document.addEventListener("mousemove", (e) => {
    dx = e.clientX; dy = e.clientY;
    dot.style.left = dx + "px"; dot.style.top = dy + "px";
    angle = -18;
    dot.style.transform = `translate(-50%, -50%) rotate(${angle}deg)`;
    const now = performance.now();
    if (now - lastSpark > 20) { spawnSpark(dx, dy); lastSpark = now; }
  });
  function loop() {
    gx += (dx - gx) * .14; gy += (dy - gy) * .14;
    glow.style.left = gx + "px"; glow.style.top = gy + "px";
    requestAnimationFrame(loop);
  }
  loop();
  document.addEventListener("mousedown", (e) => {
    document.body.classList.add("cursor-armed");
    const r = document.createElement("span");
    r.className = "click-ripple"; r.style.left = e.clientX + "px"; r.style.top = e.clientY + "px";
    document.body.appendChild(r); setTimeout(() => r.remove(), 820);
    glow.style.width = "76px"; glow.style.height = "76px";
  });
  document.addEventListener("mouseup", () => { document.body.classList.remove("cursor-armed"); glow.style.width = "44px"; glow.style.height = "44px"; });
}
function spawnSpark(x, y) {
  const s = document.createElement("span");
  s.className = "cursor-spark";
  s.style.left = x + "px"; s.style.top = y + "px";
  s.style.setProperty("--dx", `${(Math.random() - .5) * 30}px`);
  s.style.setProperty("--dy", `${(Math.random() - .5) * 30}px`);
  document.body.appendChild(s); setTimeout(() => s.remove(), 700);
}
function initBackground() {
  const c = $("#bgCanvas"), ctx = c.getContext("2d");
  let w, h, pts;
  function resize() {
    w = c.width = innerWidth * devicePixelRatio; h = c.height = innerHeight * devicePixelRatio;
    pts = Array.from({ length: Math.min(90, Math.floor(innerWidth / 16)) }, () => ({ x: Math.random()*w, y: Math.random()*h, vx:(Math.random()-.5)*.25*devicePixelRatio, vy:(Math.random()-.5)*.25*devicePixelRatio }));
  }
  addEventListener("resize", resize); resize();
  function draw() {
    ctx.clearRect(0,0,w,h);
    const accent = getComputedStyle(document.body).getPropertyValue("--accent").trim() || "#ff2b3c";
    ctx.strokeStyle = hexToRgba(accent, .16); ctx.fillStyle = hexToRgba(accent, .35);
    pts.forEach((p,i) => {
      p.x += p.vx; p.y += p.vy;
      if (p.x<0||p.x>w) p.vx*=-1; if (p.y<0||p.y>h) p.vy*=-1;
      ctx.beginPath(); ctx.arc(p.x,p.y,1.2*devicePixelRatio,0,Math.PI*2); ctx.fill();
      for (let j=i+1;j<pts.length;j++) {
        const q=pts[j], d=Math.hypot(p.x-q.x,p.y-q.y);
        if (d < 125*devicePixelRatio) { ctx.globalAlpha = 1 - d/(125*devicePixelRatio); ctx.beginPath(); ctx.moveTo(p.x,p.y); ctx.lineTo(q.x,q.y); ctx.stroke(); ctx.globalAlpha = 1; }
      }
    });
    requestAnimationFrame(draw);
  }
  draw();
}
function hexToRgba(hex, a) {
  if (!hex.startsWith("#")) return `rgba(255,43,60,${a})`;
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n>>16)&255},${(n>>8)&255},${n&255},${a})`;
}

function findNode(id, node = state.tree) {
  if (!node) return null;
  if (node.id === id) return node;
  for (const child of node.children || []) { const found = findNode(id, child); if (found) return found; }
  return null;
}
function findParentAndNode(id, node = state.tree, parent = null) {
  if (node.id === id) return { parent, node, index: parent ? parent.children.findIndex(c => c.id === id) : 0 };
  for (const child of node.children || []) { const found = findParentAndNode(id, child, node); if (found) return found; }
  return null;
}
function flatten(node) { return [node, ...(node.children || []).flatMap(flatten)]; }
function getPath(id, node = state.tree, path = []) {
  if (node.id === id) return [...path, node];
  for (const child of node.children || []) { const p = getPath(id, child, [...path, node]); if (p.length) return p; }
  return [];
}
function escapeHtml(s) { return String(s ?? "").replace(/[&<>"]/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m])); }
function formatSize(n) { if (!n) return ""; const u=["B","KB","MB","GB"]; let i=0; while(n>1024&&i<u.length-1){n/=1024;i++;} return `${n.toFixed(i?1:0)} ${u[i]}`; }
function toast(msg) { els.toast.textContent = msg; els.toast.classList.add("show"); clearTimeout(toast._t); toast._t = setTimeout(() => els.toast.classList.remove("show"), 2200); }


function initSidebarResize() {
  const handle = $("#sidebarResize");
  const sidebar = $("#sidebar");
  if (!handle || !sidebar) return;
  let resizing = false;
  handle.addEventListener("mousedown", () => { resizing = true; document.body.classList.add("resizing"); });
  window.addEventListener("mousemove", (e) => {
    if (!resizing) return;
    const w = Math.max(230, Math.min(420, e.clientX));
    document.documentElement.style.setProperty("--sidebar-w", w + "px");
    localStorage.setItem("red-team-os-sidebar-w", String(w));
  });
  window.addEventListener("mouseup", () => { resizing = false; document.body.classList.remove("resizing"); });
  const saved = localStorage.getItem("red-team-os-sidebar-w");
  if (saved) document.documentElement.style.setProperty("--sidebar-w", saved + "px");
}

/* =========================
   v1.5 Notion Workspace UX
   - Breadcrumbs
   - Workspace search results
   - Trash system
   - Quick Capture + Inbox
   - Resizable editor area
========================= */

function ensureWorkspaceExtras() {
  if (!state) return;
  if (!Array.isArray(state.trash)) state.trash = [];
  if (!Array.isArray(state.inbox)) state.inbox = [];
}

function renderPage() {
  ensureWorkspaceExtras();
  const node = findNode(selectedId) || state.tree.children?.[0] || state.tree;
  selectedId = node.id;
  els.pageTitle.textContent = node.title;
  els.pageDescription.textContent = node.description || `Editable ${String(node.type || "page").toLowerCase()} page.`;
  els.pageIcon.textContent = node.icon || "◦";
  renderBreadcrumbTrail(node.id);
  renderSubpages(node);
  renderBlocks(node);
  renderToc(node);
  renderPageControls(node);
}

function renderBreadcrumbTrail(id) {
  const path = getPath(id);
  if (!els.breadcrumb) return;
  els.breadcrumb.innerHTML = path.map((n, i) => `
    <button class="crumb-link" data-crumb-id="${n.id}">${escapeHtml(n.title)}</button>${i < path.length - 1 ? '<span class="crumb-sep">/</span>' : ''}
  `).join("");
  els.breadcrumb.querySelectorAll("[data-crumb-id]").forEach(btn => {
    btn.addEventListener("click", () => selectPage(btn.dataset.crumbId));
  });
}

function deletePage(id) {
  ensureWorkspaceExtras();
  if (id === state.tree.id) return toast("Workspace root cannot be deleted");
  const found = findParentAndNode(id);
  if (!found) return;
  if (!confirm(`Move "${found.node.title}" to Trash?`)) return;
  const [removed] = found.parent.children.splice(found.index, 1);
  state.trash.unshift({
    id: uid(),
    deletedAt: Date.now(),
    parentId: found.parent?.id || state.tree.id,
    parentTitle: found.parent?.title || "Workspace",
    node: removed
  });
  selectedId = found.parent?.id || state.tree.id;
  scheduleSave();
  renderAll();
  renderTrashList();
  toast("Moved to Trash");
}

function openQuickCapture() {
  ensureWorkspaceExtras();
  $("#quickCaptureTitle").value = "";
  $("#quickCaptureBody").value = "";
  els.backdrop.classList.remove("hidden");
  $("#quickCapturePanel").classList.remove("hidden");
  setTimeout(() => $("#quickCaptureTitle")?.focus(), 30);
}
function closeQuickCapture() { $("#quickCapturePanel")?.classList.add("hidden"); closeBackdropIfClear(); }

function saveQuickCapture() {
  ensureWorkspaceExtras();
  const title = ($("#quickCaptureTitle")?.value || "").trim() || "Quick Note";
  const body = ($("#quickCaptureBody")?.value || "").trim() || "Captured note.";
  const inbox = ensureInboxPage();
  const note = {
    id: uid(),
    title,
    icon: "✦",
    type: "Note",
    favorite: false,
    expanded: false,
    description: "Captured quick note.",
    blocks: [
      { id: uid(), type: "heading", content: title },
      { id: uid(), type: "text", content: body },
      { id: uid(), type: "subheading", content: "Context" },
      { id: uid(), type: "text", content: `Captured at ${new Date().toLocaleString()}` }
    ],
    children: []
  };
  inbox.children.unshift(note);
  inbox.expanded = true;
  selectedId = note.id;
  closeQuickCapture();
  scheduleSave();
  renderAll();
  toast("Saved to Inbox");
}

function ensureInboxPage() {
  let inbox = (state.tree.children || []).find(n => n.title === "Inbox" && n.type === "Folder");
  if (!inbox) {
    inbox = {
      id: uid(),
      title: "Inbox",
      icon: "📥",
      type: "Folder",
      favorite: true,
      expanded: true,
      description: "Unsorted quick captures for this workspace.",
      blocks: [
        { id: uid(), type: "heading", content: "Inbox" },
        { id: uid(), type: "text", content: "Fast notes, links, and ideas land here first. Organize them later." }
      ],
      children: []
    };
    if (!Array.isArray(state.tree.children)) state.tree.children = [];
    state.tree.children.unshift(inbox);
  }
  return inbox;
}

function openInbox() {
  ensureWorkspaceExtras();
  renderInboxList();
  els.backdrop.classList.remove("hidden");
  $("#inboxPanel").classList.remove("hidden");
}
function closeInbox() { $("#inboxPanel")?.classList.add("hidden"); closeBackdropIfClear(); }
function renderInboxList() {
  const box = $("#inboxList");
  if (!box) return;
  const inbox = (state.tree.children || []).find(n => n.title === "Inbox" && n.type === "Folder");
  const notes = inbox?.children || [];
  if (!notes.length) {
    box.innerHTML = `<div class="empty-inbox">Inbox is empty. Use Quick Note to capture ideas fast.</div>`;
    return;
  }
  box.innerHTML = notes.map(n => `
    <div class="inbox-item">
      <div><strong>${escapeHtml(n.icon || "✦")} ${escapeHtml(n.title)}</strong><small>${escapeHtml(n.description || "Inbox note")}</small></div>
      <div class="inbox-actions"><button data-open-inbox="${n.id}">Open</button><button data-pin-inbox="${n.id}">${n.favorite ? "Unpin" : "Pin"}</button></div>
    </div>
  `).join("");
  box.querySelectorAll("[data-open-inbox]").forEach(b => b.addEventListener("click", () => { closeInbox(); selectPage(b.dataset.openInbox); }));
  box.querySelectorAll("[data-pin-inbox]").forEach(b => b.addEventListener("click", () => { const n=findNode(b.dataset.pinInbox); if(n){ n.favorite=!n.favorite; scheduleSave(); renderInboxList(); renderTree(); } }));
}

function openTrash() {
  ensureWorkspaceExtras();
  renderTrashList();
  els.backdrop.classList.remove("hidden");
  $("#trashPanel").classList.remove("hidden");
}
function closeTrash() { $("#trashPanel")?.classList.add("hidden"); closeBackdropIfClear(); }
function renderTrashList() {
  ensureWorkspaceExtras();
  const box = $("#trashList");
  if (!box) return;
  if (!state.trash.length) {
    box.innerHTML = `<div class="empty-inbox">Trash is empty.</div>`;
    return;
  }
  box.innerHTML = state.trash.map(item => `
    <div class="inbox-item danger-item">
      <div><strong>${escapeHtml(item.node.icon || "◦")} ${escapeHtml(item.node.title)}</strong><small>Deleted from ${escapeHtml(item.parentTitle || "Workspace")} · ${new Date(item.deletedAt).toLocaleString()}</small></div>
      <div class="inbox-actions"><button data-restore-trash="${item.id}">Restore</button><button class="danger-mini" data-purge-trash="${item.id}">Purge</button></div>
    </div>
  `).join("");
  box.querySelectorAll("[data-restore-trash]").forEach(b => b.addEventListener("click", () => restoreTrashItem(b.dataset.restoreTrash)));
  box.querySelectorAll("[data-purge-trash]").forEach(b => b.addEventListener("click", () => purgeTrashItem(b.dataset.purgeTrash)));
}
function restoreTrashItem(itemId) {
  ensureWorkspaceExtras();
  const i = state.trash.findIndex(x => x.id === itemId);
  if (i < 0) return;
  const [item] = state.trash.splice(i, 1);
  const parent = findNode(item.parentId) || state.tree;
  if (!Array.isArray(parent.children)) parent.children = [];
  parent.children.push(item.node);
  parent.expanded = true;
  selectedId = item.node.id;
  scheduleSave(); renderAll(); renderTrashList(); toast("Page restored");
}
function purgeTrashItem(itemId) {
  ensureWorkspaceExtras();
  if (!confirm("Permanently delete this page?")) return;
  state.trash = state.trash.filter(x => x.id !== itemId);
  scheduleSave(); renderTrashList(); toast("Purged");
}

function renderCommandResults() {
  const q = els.commandInput.value.toLowerCase().trim();
  const pages = flatten(state.tree).filter(n => {
    if (!q) return true;
    return [n.title, n.type, n.description, blockText(n), getParentTitle(n.id)].join(" ").toLowerCase().includes(q);
  }).slice(0, 50);
  const commands = [
    { icon:"✦", title:"Quick Capture", type:"Command", fn: openQuickCapture },
    { icon:"📥", title:"Open Inbox", type:"Command", fn: openInbox },
    { icon:"🗑️", title:"Open Trash", type:"Command", fn: openTrash },
    { icon:"◇", title:"Open Workspace Manager", type:"Command", fn: () => openWorkspaceManager() },
    { icon:"＋", title:"Create New Page", type:"Command", fn: () => openPageModal("create", selectedId) },
    { icon:"📁", title:"Create Top-Level Module", type:"Command", fn: () => openPageModal("create", state.tree.id) },
    { icon:"▦", title:"Open All Pages Database", type:"Command", fn: openAllPages },
    { icon:"💾", title:"Open Backup Center", type:"Command", fn: openBackupCenter },
    { icon:"📤", title:"Export Current Workspace", type:"Command", fn: exportCurrentWorkspace },
    { icon:"🧩", title:"Insert Vulnerability Template", type:"Template", fn: () => insertTemplate("vulnerability") },
    { icon:"🛠️", title:"Insert Tool Template", type:"Template", fn: () => insertTemplate("tool") },
    { icon:"🧪", title:"Insert Lab Template", type:"Template", fn: () => insertTemplate("lab") }
  ].filter(c => !q || c.title.toLowerCase().includes(q));
  els.commandResults.innerHTML = "";
  commands.forEach(c => addCommandItem(c.icon, c.title, c.type, () => { closeCommandPalette(); c.fn(); }));
  pages.forEach(n => addSearchResultItem(n));
}

function addSearchResultItem(n) {
  const el = document.createElement("div");
  el.className = "command-item search-result-item";
  const path = getPath(n.id).map(x => x.title).join(" / ");
  const snippet = (blockText(n) || n.description || "No text yet").slice(0, 120);
  el.innerHTML = `<span>${escapeHtml(n.icon || "◦")}</span><div>${escapeHtml(n.title)}<br><small>${escapeHtml(path)}</small><em>${escapeHtml(snippet)}</em></div><small>${escapeHtml(n.type || "Page")}</small>`;
  el.addEventListener("click", () => { closeCommandPalette(); selectPage(n.id); });
  els.commandResults.appendChild(el);
}

function closeBackdropIfClear() {
  const panels = [
    els.modal, els.allPagesPanel, els.backupPanel, els.statusBoardPanel, els.workspaceModal, els.commandPalette,
    $("#quickCapturePanel"), $("#inboxPanel"), $("#trashPanel")
  ].filter(Boolean);
  if (panels.every(p => p.classList.contains("hidden"))) els.backdrop.classList.add("hidden");
}

function initEditorResize() {
  const handle = $("#pageResizeHandle");
  if (!handle) return;
  const saved = localStorage.getItem("red-team-os-editor-w");
  if (saved) document.documentElement.style.setProperty("--editor-track", `${saved}px`);
  let resizing = false;
  handle.addEventListener("mousedown", (e) => { resizing = true; document.body.classList.add("resizing-editor"); e.preventDefault(); });
  window.addEventListener("mousemove", (e) => {
    if (!resizing) return;
    const grid = document.querySelector(".content-grid");
    if (!grid) return;
    const left = grid.getBoundingClientRect().left;
    const w = Math.max(560, Math.min(1120, e.clientX - left));
    document.documentElement.style.setProperty("--editor-track", `${w}px`);
    localStorage.setItem("red-team-os-editor-w", String(w));
  });
  window.addEventListener("mouseup", () => { resizing = false; document.body.classList.remove("resizing-editor"); });
}

function bindV15UI() {
  ensureWorkspaceExtras();
  $("#quickNoteBtn")?.addEventListener("click", openQuickCapture);
  $("#inboxBtn")?.addEventListener("click", openInbox);
  $("#trashBtn")?.addEventListener("click", openTrash);
  $("#quickCaptureClose")?.addEventListener("click", closeQuickCapture);
  $("#quickCaptureCancel")?.addEventListener("click", closeQuickCapture);
  $("#quickCaptureSave")?.addEventListener("click", saveQuickCapture);
  $("#inboxClose")?.addEventListener("click", closeInbox);
  $("#trashClose")?.addEventListener("click", closeTrash);
  initEditorResize();
  const input = $("#commandInput");
  if (input) input.placeholder = "Search inside current workspace...";
  scheduleSave();
}

setTimeout(bindV15UI, 0);

/* v1.9 — Knowledge OS feature layer */
const FEATURE_PLUGIN_KEY = "knowledge-os-plugins-v19";
const FEATURE_THEME_KEY = "knowledge-os-theme-studio-v19";
let secondPanePageId = null;
let deferredInstallPrompt = null;

function getPlugins() {
  try { return JSON.parse(localStorage.getItem(FEATURE_PLUGIN_KEY) || "{}"); } catch { return {}; }
}
function setPlugins(p) { localStorage.setItem(FEATURE_PLUGIN_KEY, JSON.stringify(p)); applyPlugins(); }
function ensureFeatureStores() {
  if (!state.timeline) state.timeline = [];
  if (!state.snapshots) state.snapshots = {};
  if (!state.vaultNotes) state.vaultNotes = [];
}
function logEvent(action, detail = "") {
  try {
    ensureFeatureStores();
    const node = findNode(selectedId);
    state.timeline.unshift({ id: uid(), ts: Date.now(), action, detail, pageId: selectedId, pageTitle: node?.title || "Workspace" });
    state.timeline = state.timeline.slice(0, 120);
    scheduleSave();
  } catch {}
}

function bindV19UI() {
  ensureFeatureStores();
  bindLauncherUI();
  bindFeaturePanels();
  bindDorkAssistant();
  bindThemeStudio();
  bindPluginPanel();
  bindSecretMode();
  applyPlugins();
  applyThemeStudio();
  window.addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); deferredInstallPrompt = e; });
  logEvent("Session started", getActiveWorkspace()?.name || "Workspace");
}
setTimeout(bindV19UI, 0);

function bindLauncherUI() {
  $("#launcherBtn")?.addEventListener("click", openLauncher);
  $("#launcherClose")?.addEventListener("click", closeLauncher);
  $("#launcherNewWorkspace")?.addEventListener("click", () => { closeLauncher(); openWorkspaceManager(true); });
  $("#launcherManageWorkspaces")?.addEventListener("click", () => { closeLauncher(); openWorkspaceManager(); });
}
function openLauncher() { renderLauncher(); $("#workspaceLauncher")?.classList.remove("hidden"); }
function closeLauncher() { $("#workspaceLauncher")?.classList.add("hidden"); }
function renderLauncher() {
  const grid = $("#launcherGrid"); if (!grid) return;
  grid.innerHTML = workspaceDb.workspaces.map(ws => `
    <button class="launcher-workspace" data-launch-ws="${ws.id}">
      <span class="big-icon">${escapeHtml(ws.icon || "◇")}</span>
      <strong>${escapeHtml(ws.name)}</strong>
      <small>${escapeHtml(workspaceSubtitle(ws.template))} · ${Math.max(0, flatten(ws.data.tree).length - 1)} pages</small>
    </button>
  `).join("");
  grid.querySelectorAll("[data-launch-ws]").forEach(btn => btn.addEventListener("click", () => { closeLauncher(); switchWorkspace(btn.dataset.launchWs); }));
}

function bindFeaturePanels() {
  $("#mapBtn")?.addEventListener("click", openModuleMap);
  $("#mapClose")?.addEventListener("click", closeModuleMap);
  $("#graphBtn")?.addEventListener("click", openGraphView);
  $("#graphClose")?.addEventListener("click", closeGraphView);
  $("#splitBtn")?.addEventListener("click", toggleSplitView);
  $("#splitClose")?.addEventListener("click", closeSplitView);
  $("#splitSearch")?.addEventListener("input", renderSplitResults);
  $("#focusBtn")?.addEventListener("click", toggleFocusMode);
  $("#vaultBtn")?.addEventListener("click", openVault);
  $("#vaultClose")?.addEventListener("click", closeVault);
  $("#vaultSearch")?.addEventListener("input", renderVault);
  $("#timelineBtn")?.addEventListener("click", openTimeline);
  $("#timelineClose")?.addEventListener("click", closeTimeline);
  $("#snapshotsBtn")?.addEventListener("click", openSnapshots);
  $("#snapshotsClose")?.addEventListener("click", closeSnapshots);
  $("#snapshotSaveBtn")?.addEventListener("click", saveSnapshot);
  $("#snapshotClearBtn")?.addEventListener("click", clearSnapshots);
}

function openModuleMap() {
  renderModuleMap();
  els.backdrop.classList.remove("hidden");
  $("#mapPanel")?.classList.remove("hidden");
}
function closeModuleMap() { $("#mapPanel")?.classList.add("hidden"); closeBackdropIfClear(); }
function renderModuleMap() {
  const box = $("#moduleMap"); if (!box) return;
  const rows = [];
  function walk(n, depth = 0) {
    rows.push(`<div class="map-row" data-open-map="${n.id}" data-depth="${Math.min(depth, 3)}"><span>${escapeHtml(n.icon || "◦")}</span><strong>${escapeHtml(n.title)}</strong><small>${escapeHtml(n.type || "Page")}</small></div>`);
    (n.children || []).forEach(c => walk(c, depth + 1));
  }
  walk(state.tree, 0);
  box.innerHTML = rows.join("");
  box.querySelectorAll("[data-open-map]").forEach(r => r.addEventListener("click", () => { closeModuleMap(); selectPage(r.dataset.openMap); }));
}

function openGraphView() {
  renderGraphView();
  els.backdrop.classList.remove("hidden");
  $("#graphPanel")?.classList.remove("hidden");
}
function closeGraphView() { $("#graphPanel")?.classList.add("hidden"); closeBackdropIfClear(); }
function renderGraphView() {
  const box = $("#graphView"); if (!box) return;
  const pages = flatten(state.tree).slice(0, 85);
  const centerX = 50, centerY = 50;
  const nodes = [];
  const edges = [];
  pages.forEach((n, i) => {
    let x, y;
    if (i === 0) { x = centerX; y = centerY; }
    else {
      const angle = (i / Math.max(1, pages.length - 1)) * Math.PI * 2;
      const ring = 23 + ((i % 3) * 11);
      x = centerX + Math.cos(angle) * ring;
      y = centerY + Math.sin(angle) * ring;
    }
    nodes.push({ n, x, y });
    const parent = findParentAndNode(n.id)?.parent;
    if (parent) edges.push([parent.id, n.id]);
  });
  const pos = Object.fromEntries(nodes.map(o => [o.n.id, o]));
  const htmlEdges = edges.map(([a,b]) => {
    const p = pos[a], c = pos[b]; if (!p || !c) return "";
    const dx = c.x - p.x, dy = c.y - p.y;
    const len = Math.sqrt(dx*dx + dy*dy);
    const ang = Math.atan2(dy, dx) * 180 / Math.PI;
    return `<div class="graph-edge" style="left:${p.x}%;top:${p.y}%;width:${len}%;transform:rotate(${ang}deg)"></div>`;
  }).join("");
  const htmlNodes = nodes.map(({n,x,y}, i) => `<button class="graph-node ${i===0?'root':''}" data-graph-open="${n.id}" style="left:${x}%;top:${y}%">${escapeHtml(n.icon||"◦")} ${escapeHtml(n.title)}</button>`).join("");
  box.innerHTML = htmlEdges + htmlNodes;
  box.querySelectorAll("[data-graph-open]").forEach(b => b.addEventListener("click", () => { closeGraphView(); selectPage(b.dataset.graphOpen); }));
}

function toggleSplitView() {
  const p = $("#splitPanel"); if (!p) return;
  p.classList.toggle("hidden");
  if (!p.classList.contains("hidden")) { renderSplitResults(); renderSplitPreview(secondPanePageId); }
}
function closeSplitView() { $("#splitPanel")?.classList.add("hidden"); }
function renderSplitResults() {
  const q = ($("#splitSearch")?.value || "").toLowerCase().trim();
  const box = $("#splitResults"); if (!box) return;
  const pages = flatten(state.tree).filter(n => n.id !== state.tree.id).filter(n => !q || [n.title, n.type, blockText(n)].join(" ").toLowerCase().includes(q)).slice(0, 40);
  box.innerHTML = pages.map(n => `<button class="split-result" data-split-open="${n.id}">${escapeHtml(n.icon||"◦")} ${escapeHtml(n.title)}<small>${escapeHtml(getPath(n.id).map(x=>x.title).join(" / "))}</small></button>`).join("") || `<em>No results.</em>`;
  box.querySelectorAll("[data-split-open]").forEach(b => b.addEventListener("click", () => { secondPanePageId = b.dataset.splitOpen; renderSplitPreview(secondPanePageId); }));
}
function renderSplitPreview(id) {
  const box = $("#splitPreview"); if (!box) return;
  const n = id ? findNode(id) : null;
  if (!n) { box.innerHTML = `<em>Select a page to preview it here.</em>`; return; }
  box.innerHTML = `<h2>${escapeHtml(n.icon||"◦")} ${escapeHtml(n.title)}</h2><small>${escapeHtml(getPath(n.id).map(x=>x.title).join(" / "))}</small>` + (n.blocks || []).map(b => `<div class="split-block">${escapeHtml(blockDisplayText(b))}</div>`).join("");
}
function blockDisplayText(b) { return b.content || b.children || b.caption || b.name || (b.type === "divider" ? "────" : ""); }
function toggleFocusMode() { document.body.classList.toggle("focus-mode"); toast(document.body.classList.contains("focus-mode") ? "Focus mode" : "Focus off"); }

function openVault() { renderVault(); els.backdrop.classList.remove("hidden"); $("#vaultPanel")?.classList.remove("hidden"); }
function closeVault() { $("#vaultPanel")?.classList.add("hidden"); closeBackdropIfClear(); }
function collectAttachments() {
  const out = [];
  flatten(state.tree).forEach(page => (page.blocks || []).forEach(block => {
    if (block.type === "image" || block.type === "file") out.push({ page, block });
  }));
  return out;
}
function renderVault() {
  const box = $("#vaultList"); if (!box) return;
  const q = ($("#vaultSearch")?.value || "").toLowerCase().trim();
  const items = collectAttachments().filter(({page, block}) => !q || [page.title, block.name, block.caption].join(" ").toLowerCase().includes(q));
  box.innerHTML = items.map(({page, block}) => {
    const preview = block.type === "image" ? `<img src="${block.src}" alt="${escapeHtml(block.caption || page.title)}">` : `<div class="file-chip">📎 ${escapeHtml(block.name || "File")}</div>`;
    return `<div class="vault-item">${preview}<strong>${escapeHtml(block.caption || block.name || "Attachment")}</strong><small>${escapeHtml(page.title)}</small><button data-vault-open="${page.id}">Open Page</button></div>`;
  }).join("") || `<div class="empty-inbox">No attachments in this workspace yet.</div>`;
  box.querySelectorAll("[data-vault-open]").forEach(b => b.addEventListener("click", () => { closeVault(); selectPage(b.dataset.vaultOpen); }));
}

function openTimeline() { renderTimeline(); els.backdrop.classList.remove("hidden"); $("#timelinePanel")?.classList.remove("hidden"); }
function closeTimeline() { $("#timelinePanel")?.classList.add("hidden"); closeBackdropIfClear(); }
function renderTimeline() {
  ensureFeatureStores();
  const box = $("#timelineList"); if (!box) return;
  const fallback = (state.recent || []).map(id => findNode(id)).filter(Boolean).map(n => ({ id: uid(), ts: Date.now(), action: "Recently opened", detail: n.title, pageId: n.id, pageTitle: n.title }));
  const items = (state.timeline?.length ? state.timeline : fallback).slice(0, 80);
  box.innerHTML = items.map(x => `<div class="timeline-item"><strong>${escapeHtml(x.action)}</strong><small>${escapeHtml(x.pageTitle || "Workspace")} · ${new Date(x.ts).toLocaleString()}</small><div>${escapeHtml(x.detail || "")}</div></div>`).join("") || `<div class="empty-inbox">Timeline is empty.</div>`;
}

function openSnapshots() { renderSnapshots(); els.backdrop.classList.remove("hidden"); $("#snapshotsPanel")?.classList.remove("hidden"); }
function closeSnapshots() { $("#snapshotsPanel")?.classList.add("hidden"); closeBackdropIfClear(); }
function saveSnapshot() {
  ensureFeatureStores();
  const n = findNode(selectedId); if (!n) return;
  if (!state.snapshots[selectedId]) state.snapshots[selectedId] = [];
  state.snapshots[selectedId].unshift({ id: uid(), ts: Date.now(), title: n.title, blocks: structuredCloneSafe(n.blocks || []), description: n.description || "" });
  state.snapshots[selectedId] = state.snapshots[selectedId].slice(0, 12);
  scheduleSave(); renderSnapshots(); logEvent("Snapshot saved", n.title); toast("Snapshot saved");
}
function renderSnapshots() {
  ensureFeatureStores();
  const box = $("#snapshotsList"); if (!box) return;
  const list = state.snapshots[selectedId] || [];
  box.innerHTML = list.map(s => `<div class="snapshot-item"><strong>${escapeHtml(s.title || "Snapshot")}</strong><small>${new Date(s.ts).toLocaleString()}</small><div class="snapshot-actions"><button data-restore-snapshot="${s.id}">Restore</button><button data-delete-snapshot="${s.id}">Delete</button></div></div>`).join("") || `<div class="empty-inbox">No snapshots for this page yet.</div>`;
  box.querySelectorAll("[data-restore-snapshot]").forEach(b => b.addEventListener("click", () => restoreSnapshot(b.dataset.restoreSnapshot)));
  box.querySelectorAll("[data-delete-snapshot]").forEach(b => b.addEventListener("click", () => deleteSnapshot(b.dataset.deleteSnapshot)));
}
function restoreSnapshot(id) {
  const n = findNode(selectedId); const snap = (state.snapshots?.[selectedId] || []).find(s => s.id === id);
  if (!n || !snap) return;
  if (!confirm("Restore this snapshot over the current page blocks?")) return;
  n.blocks = structuredCloneSafe(snap.blocks || []); n.description = snap.description || n.description;
  scheduleSave(); renderPage(); renderSnapshots(); logEvent("Snapshot restored", n.title); toast("Snapshot restored");
}
function deleteSnapshot(id) { state.snapshots[selectedId] = (state.snapshots?.[selectedId] || []).filter(s => s.id !== id); scheduleSave(); renderSnapshots(); }
function clearSnapshots() { if (!confirm("Clear snapshots for this page?")) return; if (state.snapshots) state.snapshots[selectedId] = []; scheduleSave(); renderSnapshots(); }

function bindThemeStudio() {
  $("#themeStudioBtn")?.addEventListener("click", openThemeStudio);
  $("#themeStudioClose")?.addEventListener("click", closeThemeStudio);
  document.querySelectorAll("[data-theme-preset]").forEach(btn => btn.addEventListener("click", () => applyThemePreset(btn.dataset.themePreset)));
  ["glowRange","fontRange","depthRange"].forEach(id => $("#"+id)?.addEventListener("input", saveThemeStudio));
}
function openThemeStudio() { hydrateThemeControls(); els.backdrop.classList.remove("hidden"); $("#themeStudioPanel")?.classList.remove("hidden"); }
function closeThemeStudio() { $("#themeStudioPanel")?.classList.add("hidden"); closeBackdropIfClear(); }
function hydrateThemeControls() {
  const cfg = getThemeStudio();
  if ($("#glowRange")) $("#glowRange").value = cfg.glow ?? 35;
  if ($("#fontRange")) $("#fontRange").value = cfg.font ?? 14;
  if ($("#depthRange")) $("#depthRange").value = cfg.depth ?? 60;
}
function getThemeStudio() { try { return JSON.parse(localStorage.getItem(FEATURE_THEME_KEY) || "{}"); } catch { return {}; } }
function saveThemeStudio() {
  const cfg = { ...getThemeStudio(), glow: +($("#glowRange")?.value || 35), font: +($("#fontRange")?.value || 14), depth: +($("#depthRange")?.value || 60) };
  localStorage.setItem(FEATURE_THEME_KEY, JSON.stringify(cfg)); applyThemeStudio();
}
function applyThemeStudio() {
  const cfg = getThemeStudio();
  document.documentElement.style.setProperty("--glow-strength", String(cfg.glow ?? 35));
  document.documentElement.style.setProperty("--editor-font-size", (cfg.font ?? 14) + "px");
  document.documentElement.style.setProperty("--bg-depth", String((cfg.depth ?? 60) / 100));
  if (cfg.preset) applyThemePreset(cfg.preset, false);
}
function applyThemePreset(name, persist = true) {
  const palettes = {
    "dark-red": ["#d72e3e", "#f06672", "#67141e"],
    "deep-web": ["#56606f", "#a3acba", "#1a1f29"],
    "ghost-gray": ["#8b93a3", "#d6dbe4", "#242a34"],
    "xenon-blue": ["#24b8ff", "#a7e8ff", "#0b3048"],
    "toxic-green": ["#35e58b", "#baffd7", "#113924"],
    "purple-ghost": ["#9b6cff", "#d9c6ff", "#251a3d"]
  };
  const p = palettes[name] || palettes["dark-red"];
  document.body.classList.add("xenon");
  document.body.style.setProperty("--accent", p[0]);
  document.body.style.setProperty("--accent2", p[1]);
  document.body.style.setProperty("--accent3", p[2]);
  if (persist) { const cfg = { ...getThemeStudio(), preset: name }; localStorage.setItem(FEATURE_THEME_KEY, JSON.stringify(cfg)); toast("Theme: " + name); }
}

function bindPluginPanel() {
  $("#pluginsBtn")?.addEventListener("click", openPlugins);
  $("#pluginsClose")?.addEventListener("click", closePlugins);
  document.querySelectorAll("[data-plugin-toggle]").forEach(inp => inp.addEventListener("change", savePluginPanel));
}
function openPlugins() { hydratePlugins(); els.backdrop.classList.remove("hidden"); $("#pluginsPanel")?.classList.remove("hidden"); }
function closePlugins() { $("#pluginsPanel")?.classList.add("hidden"); closeBackdropIfClear(); }
function hydratePlugins() {
  const p = getPlugins();
  document.querySelectorAll("[data-plugin-toggle]").forEach(inp => { inp.checked = p[inp.dataset.pluginToggle] !== false; });
}
function savePluginPanel() {
  const p = {};
  document.querySelectorAll("[data-plugin-toggle]").forEach(inp => { p[inp.dataset.pluginToggle] = inp.checked; });
  setPlugins(p);
}
function applyPlugins() {
  const p = getPlugins();
  document.body.classList.toggle("plugin-hide-dorks", p.dorks === false);
  document.body.classList.toggle("plugin-hide-audio", p.audio === false);
  document.body.classList.toggle("plugin-hide-timer", p.timer === false);
  document.body.classList.toggle("plugin-hide-particles", p.particles === false);
  document.body.classList.toggle("plugin-hide-rightPanel", p.rightPanel === false);
}

function bindSecretMode() {
  $("#secretBtn")?.addEventListener("click", toggleSecretMode);
  window.addEventListener("keydown", (e) => {
    if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "x") toggleSecretMode();
  });
}
function toggleSecretMode() {
  document.body.classList.toggle("secret-mode");
  $("#secretCover")?.classList.toggle("hidden", !document.body.classList.contains("secret-mode"));
}

function bindDorkAssistant() {
  $("#dorkOrb")?.addEventListener("click", () => $("#dorkChat")?.classList.toggle("hidden"));
  $("#dorkClose")?.addEventListener("click", () => $("#dorkChat")?.classList.add("hidden"));
  $("#dorkGenerate")?.addEventListener("click", generateDorks);
  $("#dorkTarget")?.addEventListener("keydown", (e) => { if (e.key === "Enter") generateDorks(); });
  $("#dorkCopyAll")?.addEventListener("click", copyAllDorks);
}
function cleanTarget(raw) {
  return (raw || "").trim().replace(/^https?:\/\//i, "").replace(/\/.*$/, "").replace(/[^a-zA-Z0-9._-]/g, "");
}
function dorkTemplates(target) {
  const t = target || "example.com";
  return [
    ["Scope homepage", `site:${t}`],
    ["Subdomains indexed", `site:*.${t} -www`],
    ["Public PDFs", `site:${t} filetype:pdf`],
    ["Public documents", `site:${t} (filetype:doc OR filetype:docx OR filetype:xls OR filetype:xlsx OR filetype:ppt OR filetype:pptx)`],
    ["Login pages", `site:${t} (inurl:login OR inurl:signin OR intitle:login)`],
    ["API keywords", `site:${t} (inurl:api OR inurl:graphql OR inurl:swagger OR inurl:openapi)`],
    ["Developer docs", `site:${t} (inurl:docs OR inurl:developer OR inurl:reference)`],
    ["Error pages", `site:${t} ("error" OR "exception" OR "stack trace")`],
    ["Security contact", `site:${t} (security.txt OR "security policy" OR "bug bounty")`],
    ["Exposed index pages", `site:${t} intitle:"index of"`]
  ];
}
function generateDorks() {
  const target = cleanTarget($("#dorkTarget")?.value || "");
  const box = $("#dorkResults"); if (!box) return;
  if (!target) { box.innerHTML = `<div class="dork-row"><code>Enter a domain first.</code></div>`; return; }
  const rows = dorkTemplates(target);
  box.innerHTML = rows.map(([label, q], i) => `
    <div class="dork-row">
      <div class="dork-label">${escapeHtml(label)}</div>
      <code>${escapeHtml(q)}</code>
      <div class="dork-buttons"><button data-copy-dork="${i}">Copy</button><button data-open-dork="${i}">Open</button><button data-add-dork="${i}">Add Note</button></div>
    </div>
  `).join("");
  box.querySelectorAll("[data-copy-dork]").forEach(b => b.addEventListener("click", () => copyText(rows[+b.dataset.copyDork][1])));
  box.querySelectorAll("[data-open-dork]").forEach(b => b.addEventListener("click", () => window.open("https://www.google.com/search?q=" + encodeURIComponent(rows[+b.dataset.openDork][1]), "_blank", "noopener")));
  box.querySelectorAll("[data-add-dork]").forEach(b => b.addEventListener("click", () => { addBlock("code", rows[+b.dataset.addDork][1]); logEvent("Dork added", target); }));
}
async function copyText(text) { try { await navigator.clipboard.writeText(text); toast("Copied"); } catch { toast("Copy failed"); } }
function copyAllDorks() {
  const target = cleanTarget($("#dorkTarget")?.value || "");
  if (!target) return toast("Enter a target first");
  copyText(dorkTemplates(target).map(x => x[1]).join("\n"));
}

/* Extend command palette with feature commands. */
const oldRenderCommandResultsV19 = renderCommandResults;
renderCommandResults = function() {
  const q = els.commandInput.value.toLowerCase().trim();
  const featureCommands = [
    { icon:"🚀", title:"Open Launcher", type:"Workspace", fn: openLauncher },
    { icon:"🗺️", title:"Open Framework Map", type:"View", fn: openModuleMap },
    { icon:"🕸️", title:"Open Graph View", type:"View", fn: openGraphView },
    { icon:"◫", title:"Toggle Split View", type:"View", fn: toggleSplitView },
    { icon:"◌", title:"Toggle Focus Mode", type:"View", fn: toggleFocusMode },
    { icon:"🧳", title:"Open Vault", type:"Files", fn: openVault },
    { icon:"⏱️", title:"Open Timeline", type:"History", fn: openTimeline },
    { icon:"⟲", title:"Open Snapshots", type:"History", fn: openSnapshots },
    { icon:"🎛️", title:"Open Theme Studio", type:"Settings", fn: openThemeStudio },
    { icon:"🧩", title:"Open Plugins", type:"Settings", fn: openPlugins },
    { icon:"◉", title:"Open Dork Assistant", type:"OSINT", fn: () => $("#dorkChat")?.classList.remove("hidden") },
    { icon:"🕶️", title:"Toggle Secret Mode", type:"Privacy", fn: toggleSecretMode }
  ].filter(c => !q || c.title.toLowerCase().includes(q));
  oldRenderCommandResultsV19();
  if (featureCommands.length) {
    const sep = document.createElement("div"); sep.className = "command-separator"; sep.textContent = "Workspace Commands";
    els.commandResults.prepend(sep);
    featureCommands.reverse().forEach(c => {
      const el = document.createElement("div");
      el.className = "command-item";
      el.innerHTML = `<span>${escapeHtml(c.icon)}</span><div>${escapeHtml(c.title)}<br><small>${escapeHtml(c.type)}</small></div><small>Run</small>`;
      el.addEventListener("click", () => { closeCommandPalette(); c.fn(); });
      els.commandResults.insertBefore(el, sep.nextSibling);
    });
  }
};

/* Log major existing actions without disturbing stability. */
const oldSelectPageV19 = selectPage;
selectPage = function(id, pushHistory = true) { oldSelectPageV19(id, pushHistory); logEvent("Opened page", findNode(id)?.title || "Page"); };
const oldAddBlockV19 = addBlock;
addBlock = function(type, content = null, insertIndex = null) { oldAddBlockV19(type, content, insertIndex); logEvent("Added block", type); };
const oldCreateWorkspaceFromFormV19 = createWorkspaceFromForm;
createWorkspaceFromForm = function() { oldCreateWorkspaceFromFormV19(); logEvent("Workspace created", getActiveWorkspace()?.name || "Workspace"); };

/* Keep backdrop logic aware of v1.9 panels. */
closeBackdropIfClear = function() {
  const panels = [
    els.modal, els.allPagesPanel, els.backupPanel, els.statusBoardPanel, els.workspaceModal, els.commandPalette,
    $("#quickCapturePanel"), $("#inboxPanel"), $("#trashPanel"), $("#mapPanel"), $("#graphPanel"), $("#vaultPanel"), $("#timelinePanel"), $("#snapshotsPanel"), $("#themeStudioPanel"), $("#pluginsPanel")
  ].filter(Boolean);
  if (panels.every(p => p.classList.contains("hidden"))) els.backdrop.classList.add("hidden");
};

/* v2.0 — Screenshot-inspired workspace layer, bookmarks, marketplace, score, duplicates, reading mode, terminal. */
const V20_BOOKMARKS_VERSION = 1;
const LOCAL_MARKETPLACE_TEMPLATES = [
  { id:"bug-bounty", icon:"🎯", title:"Bug Bounty Workspace", desc:"Targets, scope notes, reports, writeups, payload notes, and references.", children:[
    ["🎯","Targets"],["📜","Rules of Engagement"],["🔍","Recon Notes"],["🚨","Findings"],["📑","Reports"],["📚","Writeups"],["☍","Bookmarks"]
  ]},
  { id:"ctf", icon:"🏁", title:"CTF Workspace", desc:"Challenges, categories, solved notes, mistakes, and screenshots.", children:[
    ["🌐","Web"],["🧩","Reverse"],["🧬","Forensics"],["🔐","Crypto"],["📡","Pwn"],["📝","Writeups"]
  ]},
  { id:"reverse", icon:"🧩", title:"Reverse Engineering Workspace", desc:"Binaries, notes, functions, strings, tools, and case files.", children:[
    ["📦","Samples"],["🧠","Concepts"],["🛠️","Tools"],["🔎","Strings & Symbols"],["📚","Writeups"],["🧪","Labs"]
  ]},
  { id:"forensics", icon:"🧬", title:"Forensics Case Workspace", desc:"Cases, evidence, timelines, artifacts, tools, and final notes.", children:[
    ["🗂️","Cases"],["🔎","Evidence"],["⏱️","Timeline"],["🪟","Windows Artifacts"],["🐧","Linux Artifacts"],["📑","Reports"]
  ]},
  { id:"dark-research", icon:"🕸️", title:"Dark Research Workspace", desc:"Research notes, bookmarks, vocabulary, sources, and safe analysis logs.", children:[
    ["🕸️","Research Notes"],["☍","Bookmarks"],["📚","Vocabulary"],["🔎","Sources"],["🧾","Case Files"],["⚙️","Tools"]
  ]},
  { id:"programming", icon:"💻", title:"Programming Workspace", desc:"Projects, snippets, bugs, docs, references, and learning tracks.", children:[
    ["🚀","Projects"],["🧩","Snippets"],["🐞","Bugs & Fixes"],["📚","Docs"],["🧠","Concepts"],["☍","Bookmarks"]
  ]}
];

function bindV20UI() {
  removeDorkAssistantUI();
  ensureV20Stores();
  bindV20Buttons();
  renderRightPanelExtras();
  installQuickLinkHandler();
  extendCommandPaletteV20();
  updateDockBindings();
}
setTimeout(bindV20UI, 0);

function removeDorkAssistantUI() {
  document.querySelectorAll('#dorkOrb,#dorkChat').forEach(x => x.remove());
  document.body.classList.add('plugin-hide-dorks');
}

function ensureV20Stores() {
  if (!Array.isArray(state.bookmarks)) state.bookmarks = [];
  if (!state.bookmarksVersion) state.bookmarksVersion = V20_BOOKMARKS_VERSION;
  if (!Array.isArray(state.activityHeat)) state.activityHeat = [];
}

function bindV20Buttons() {
  $('#scoreBtn')?.addEventListener('click', openKnowledgeScore);
  $('#duplicatesBtn')?.addEventListener('click', openDuplicateDetector);
  $('#bookmarksBtn')?.addEventListener('click', openBookmarksPanel);
  $('#marketplaceBtn')?.addEventListener('click', openMarketplace);
  $('#readingBtn')?.addEventListener('click', openReadingMode);
  $('#terminalBtn')?.addEventListener('click', openTerminalLauncher);
  $('#scoreClose')?.addEventListener('click', closeKnowledgeScore);
  $('#duplicatesClose')?.addEventListener('click', closeDuplicateDetector);
  $('#bookmarksClose')?.addEventListener('click', closeBookmarksPanel);
  $('#bookmarkAdd')?.addEventListener('click', addBookmarkFromForm);
  $('#bookmarksSearch')?.addEventListener('input', renderBookmarks);
  $('#marketplaceClose')?.addEventListener('click', closeMarketplace);
  $('#readingClose')?.addEventListener('click', closeReadingMode);
  $('#terminalClose')?.addEventListener('click', closeTerminalLauncher);
  $('#terminalInput')?.addEventListener('keydown', handleTerminalCommand);
  $('#sideReadingBtn')?.addEventListener('click', openReadingMode);
  $('#sideBookmarkBtn')?.addEventListener('click', () => { openBookmarksPanel(); setTimeout(() => $('#bookmarkTitle')?.focus(), 30); });
  $('#sideDuplicateCheckBtn')?.addEventListener('click', openDuplicateDetector);
}

function updateDockBindings() {
  $('#dockDashboard')?.addEventListener('click', () => selectPage(state.tree.id));
  $('#dockPages')?.addEventListener('click', openAllPages);
  $('#dockMap')?.addEventListener('click', openModuleMap);
  $('#dockBookmarks')?.addEventListener('click', openBookmarksPanel);
  $('#dockReading')?.addEventListener('click', openReadingMode);
}

function calculateKnowledgeScore() {
  const pages = flatten(state.tree).filter(n => n.id !== state.tree.id);
  const total = Math.max(1, pages.length);
  const filled = pages.filter(n => (n.blocks || []).some(b => blockDisplayTextSafe(b).trim().length > 8)).length;
  const blocks = pages.reduce((a,n)=>a+(n.blocks?.length||0),0);
  const attachments = pages.reduce((a,n)=>a+(n.blocks||[]).filter(b=>b.type==='image'||b.type==='file').length,0);
  const pinned = pages.filter(n=>n.favorite).length;
  const children = pages.filter(n => (n.children||[]).length).length;
  const links = pages.reduce((a,n)=>a+extractQuickLinks(n).length,0);
  const weighted = Math.round(Math.min(100,
    (filled/total)*40 + Math.min(blocks, 160)/160*22 + Math.min(attachments, 30)/30*12 + Math.min(pinned, 20)/20*8 + Math.min(children, 25)/25*10 + Math.min(links, 40)/40*8
  ));
  return { score: weighted, pages: pages.length, filled, empty: total-filled, blocks, attachments, pinned, children, links };
}

function openKnowledgeScore() {
  ensureV20Stores();
  renderKnowledgeScore();
  els.backdrop.classList.remove('hidden');
  $('#scorePanel')?.classList.remove('hidden');
}
function closeKnowledgeScore() { $('#scorePanel')?.classList.add('hidden'); closeBackdropIfClear(); }
function renderKnowledgeScore() {
  const box = $('#scoreContent'); if (!box) return;
  const m = calculateKnowledgeScore();
  box.innerHTML = `
    <div class="score-ring" style="--p:${m.score}"><div class="score-ring-inner"><strong>${m.score}</strong><small>/ 100</small></div></div>
    <div class="score-metrics">
      <div class="score-metric"><strong>${m.pages}</strong><small>Pages</small></div>
      <div class="score-metric"><strong>${m.filled}</strong><small>Filled pages</small></div>
      <div class="score-metric"><strong>${m.blocks}</strong><small>Blocks</small></div>
      <div class="score-metric"><strong>${m.attachments}</strong><small>Attachments</small></div>
      <div class="score-metric"><strong>${m.pinned}</strong><small>Pinned</small></div>
      <div class="score-metric"><strong>${m.links}</strong><small>Quick links</small></div>
    </div>
    <p class="backup-note">Score is local and practical: more filled notes, structure, links, and evidence improve it.</p>
  `;
}

function openDuplicateDetector() {
  renderDuplicateDetector();
  els.backdrop.classList.remove('hidden');
  $('#duplicatesPanel')?.classList.remove('hidden');
}
function closeDuplicateDetector() { $('#duplicatesPanel')?.classList.add('hidden'); closeBackdropIfClear(); }
function normalizeTitleText(t) { return String(t||'').toLowerCase().replace(/[^a-z0-9\u0600-\u06ff]+/g,' ').trim(); }
function similarityScore(a,b) {
  const A = new Set(normalizeTitleText(a).split(/\s+/).filter(Boolean));
  const B = new Set(normalizeTitleText(b).split(/\s+/).filter(Boolean));
  if (!A.size || !B.size) return 0;
  const inter = [...A].filter(x=>B.has(x)).length;
  return inter / Math.max(A.size, B.size);
}
function findDuplicates() {
  const pages = flatten(state.tree).filter(n => n.id !== state.tree.id);
  const groups = [];
  const used = new Set();
  pages.forEach((a, i) => {
    if (used.has(a.id)) return;
    const matches = [a];
    pages.slice(i+1).forEach(b => {
      const exact = normalizeTitleText(a.title) === normalizeTitleText(b.title);
      const sim = similarityScore(a.title, b.title) >= .66;
      if (exact || sim) matches.push(b);
    });
    if (matches.length > 1) {
      matches.forEach(x=>used.add(x.id));
      groups.push(matches);
    }
  });
  return groups;
}
function renderDuplicateDetector() {
  const box = $('#duplicatesList'); if (!box) return;
  const groups = findDuplicates();
  if (!groups.length) { box.innerHTML = `<div class="empty-inbox">No duplicates detected in this workspace.</div>`; return; }
  box.innerHTML = groups.map((g, idx) => `
    <div class="duplicate-group">
      <strong>Possible duplicate group ${idx+1}</strong>
      ${g.map(n => `<button data-open-dup="${n.id}">${escapeHtml(n.icon||'◦')} ${escapeHtml(n.title)} <small>${escapeHtml(getPath(n.id).map(x=>x.title).join(' / '))}</small></button>`).join('')}
    </div>
  `).join('');
  box.querySelectorAll('[data-open-dup]').forEach(b => b.addEventListener('click', () => { closeDuplicateDetector(); selectPage(b.dataset.openDup); }));
}

function openBookmarksPanel() {
  ensureV20Stores();
  renderBookmarks();
  els.backdrop.classList.remove('hidden');
  $('#bookmarksPanel')?.classList.remove('hidden');
}
function closeBookmarksPanel() { $('#bookmarksPanel')?.classList.add('hidden'); closeBackdropIfClear(); }
function addBookmarkFromForm() {
  ensureV20Stores();
  const title = ($('#bookmarkTitle')?.value || '').trim();
  const url = ($('#bookmarkUrl')?.value || '').trim();
  const category = ($('#bookmarkCategory')?.value || '').trim() || 'General';
  if (!url) return toast('Add a URL first');
  const finalTitle = title || url.replace(/^https?:\/\//,'').slice(0, 80);
  state.bookmarks.unshift({ id: uid(), title: finalTitle, url, category, createdAt: Date.now(), pageId: selectedId });
  ['bookmarkTitle','bookmarkUrl','bookmarkCategory'].forEach(id => { const e=$('#'+id); if(e) e.value=''; });
  scheduleSave(); renderBookmarks(); toast('Bookmark added');
}
function renderBookmarks() {
  const box = $('#bookmarksList'); if (!box) return;
  ensureV20Stores();
  const q = ($('#bookmarksSearch')?.value || '').toLowerCase().trim();
  const items = state.bookmarks.filter(b => !q || [b.title,b.url,b.category].join(' ').toLowerCase().includes(q));
  if (!items.length) { box.innerHTML = `<div class="empty-inbox">No bookmarks yet.</div>`; return; }
  box.innerHTML = items.map(b => `
    <div class="bookmark-item">
      <strong>${escapeHtml(b.title)}</strong>
      <small>${escapeHtml(b.category || 'General')} · ${escapeHtml(b.url)}</small>
      <div><button data-open-bookmark="${b.id}">Open</button><button data-copy-bookmark="${b.id}">Copy</button><button data-delete-bookmark="${b.id}">Delete</button></div>
    </div>
  `).join('');
  box.querySelectorAll('[data-open-bookmark]').forEach(btn => btn.addEventListener('click', () => { const b = state.bookmarks.find(x=>x.id===btn.dataset.openBookmark); if(b) window.open(b.url, '_blank', 'noopener'); }));
  box.querySelectorAll('[data-copy-bookmark]').forEach(btn => btn.addEventListener('click', () => { const b = state.bookmarks.find(x=>x.id===btn.dataset.copyBookmark); if(b) copyText(b.url); }));
  box.querySelectorAll('[data-delete-bookmark]').forEach(btn => btn.addEventListener('click', () => { state.bookmarks = state.bookmarks.filter(x=>x.id!==btn.dataset.deleteBookmark); scheduleSave(); renderBookmarks(); }));
}

function openMarketplace() {
  renderMarketplace();
  els.backdrop.classList.remove('hidden');
  $('#marketplacePanel')?.classList.remove('hidden');
}
function closeMarketplace() { $('#marketplacePanel')?.classList.add('hidden'); closeBackdropIfClear(); }
function renderMarketplace() {
  const box = $('#marketplaceGrid'); if (!box) return;
  box.innerHTML = LOCAL_MARKETPLACE_TEMPLATES.map(t => `
    <div class="marketplace-card">
      <h3>${escapeHtml(t.icon)} ${escapeHtml(t.title)}</h3>
      <p>${escapeHtml(t.desc)}</p>
      <button data-install-module="${t.id}">Install into current workspace</button>
      <button data-create-market-ws="${t.id}">Create workspace</button>
    </div>
  `).join('');
  box.querySelectorAll('[data-install-module]').forEach(btn => btn.addEventListener('click', () => installMarketplaceModule(btn.dataset.installModule)));
  box.querySelectorAll('[data-create-market-ws]').forEach(btn => btn.addEventListener('click', () => createWorkspaceFromMarketplace(btn.dataset.createMarketWs)));
}
function marketplaceModuleFromTemplate(t) {
  return { id: uid(), icon: t.icon, title: t.title.replace(' Workspace',''), type:'Folder', expanded:true, favorite:false, description:t.desc, blocks:[], children: t.children.map(([icon,title]) => ({ id:uid(), icon, title, type:'Topic', expanded:false, favorite:false, description:'', blocks:[], children:[] })) };
}
function installMarketplaceModule(id) {
  const t = LOCAL_MARKETPLACE_TEMPLATES.find(x=>x.id===id); if(!t) return;
  state.tree.children.push(marketplaceModuleFromTemplate(t));
  state.tree.expanded = true;
  scheduleSave(); renderAll(); toast('Template installed');
}
function createWorkspaceFromMarketplace(id) {
  const t = LOCAL_MARKETPLACE_TEMPLATES.find(x=>x.id===id); if(!t) return;
  const root = marketplaceModuleFromTemplate(t);
  root.title = t.title;
  root.template = 'marketplace';
  const ws = { id: uid(), name: t.title, icon: t.icon, template:'marketplace', data:{ tree: root, selectedId: root.id, updatedAt: Date.now(), recent:[], bookmarks:[] } };
  normalizeWorkspace(ws.data);
  workspaceDb.workspaces.push(ws);
  workspaceDb.activeId = ws.id;
  state = getActiveWorkspace().data;
  selectedId = state.selectedId || state.tree.id;
  saveState(); closeMarketplace(); renderAll(); toast('Workspace created');
}

function extractQuickLinks(node) {
  const text = [node.title, node.description, blockText(node)].join('\n');
  const out = [];
  const re = /\[\[([^\]]{1,80})\]\]/g;
  let m;
  while ((m = re.exec(text))) out.push(m[1].trim());
  return [...new Set(out)].filter(Boolean);
}
function findPageByTitle(title) {
  const q = normalizeTitleText(title);
  return flatten(state.tree).find(n => normalizeTitleText(n.title) === q) || null;
}
function wikilinkHtml(text) {
  return escapeHtml(text).replace(/\[\[([^\]]{1,80})\]\]/g, (all, name) => {
    const page = findPageByTitle(name.trim());
    return `<a class="wikilink ${page?'':'missing'}" data-wikilink="${escapeHtml(name.trim())}">[[${escapeHtml(name.trim())}]]</a>`;
  });
}
function installQuickLinkHandler() {
  document.addEventListener('click', (e) => {
    const a = e.target.closest('[data-wikilink]');
    if (!a) return;
    const page = findPageByTitle(a.dataset.wikilink);
    if (page) { closeReadingMode(); selectPage(page.id); }
    else toast('No page named: ' + a.dataset.wikilink);
  });
}

function openReadingMode() {
  renderReadingMode();
  $('#readingOverlay')?.classList.remove('hidden');
}
function closeReadingMode() { $('#readingOverlay')?.classList.add('hidden'); }
function renderReadingMode() {
  const node = findNode(selectedId); const box = $('#readingContent'); if (!node || !box) return;
  const path = getPath(node.id).map(x => x.title).join(' / ');
  box.innerHTML = `<h1>${escapeHtml(node.icon||'◦')} ${escapeHtml(node.title)}</h1><p class="modal-subtitle">${escapeHtml(path)}</p>` + (node.description ? `<p>${wikilinkHtml(node.description)}</p>` : '') + renderBlocksForReading(node.blocks || []);
}
function renderBlocksForReading(blocks) {
  return blocks.map(b => {
    const c = b.content || '';
    if (b.type === 'heading') return `<h2>${wikilinkHtml(c)}</h2>`;
    if (b.type === 'subheading' || b.type === 'heading3' || b.type === 'heading4') return `<h3>${wikilinkHtml(c)}</h3>`;
    if (b.type === 'quote') return `<blockquote>${wikilinkHtml(c)}</blockquote>`;
    if (b.type === 'callout') return `<p><strong>✦</strong> ${wikilinkHtml(c)}</p>`;
    if (b.type === 'code') return `<pre>${escapeHtml(c)}</pre>`;
    if (b.type === 'checklist') return `<p>${b.checked ? '☑' : '☐'} ${wikilinkHtml(c)}</p>`;
    if (b.type === 'bulleted') return `<ul><li>${wikilinkHtml(c)}</li></ul>`;
    if (b.type === 'numbered') return `<ol><li>${wikilinkHtml(c)}</li></ol>`;
    if (b.type === 'toggle') return `<details open><summary>${wikilinkHtml(c || 'Toggle')}</summary><p>${wikilinkHtml(b.children || '')}</p></details>`;
    if (b.type === 'divider') return `<hr>`;
    if (b.type === 'image') return `<figure><img src="${b.src||''}" alt="${escapeHtml(b.caption||'image')}" style="max-width:100%;border-radius:14px"><figcaption>${escapeHtml(b.caption||'')}</figcaption></figure>`;
    if (b.type === 'file') return `<p>📎 ${escapeHtml(b.name||'Attached file')}</p>`;
    return `<p>${wikilinkHtml(c)}</p>`;
  }).join('');
}

function openTerminalLauncher() {
  const p = $('#terminalPanel'); if (!p) return;
  p.classList.remove('hidden');
  terminalPrint('Knowledge OS terminal ready. Type help.');
  setTimeout(()=>$('#terminalInput')?.focus(), 50);
}
function closeTerminalLauncher() { $('#terminalPanel')?.classList.add('hidden'); }
function terminalPrint(text, cls='') {
  const out = $('#terminalOutput'); if (!out) return;
  const div = document.createElement('div'); div.className = 'terminal-line ' + cls; div.textContent = text; out.appendChild(div); out.scrollTop = out.scrollHeight;
}
function handleTerminalCommand(e) {
  if (e.key !== 'Enter') return;
  const input = e.currentTarget;
  const raw = input.value.trim(); input.value = '';
  if (!raw) return;
  terminalPrint('> ' + raw, 'dim');
  const [cmd, ...rest] = raw.split(' ');
  const arg = rest.join(' ').trim();
  if (cmd === 'help') return terminalPrint('Commands: open <page>, search <text>, new page <name>, random, score, bookmarks, marketplace, reading, focus, clear');
  if (cmd === 'clear') { $('#terminalOutput').innerHTML = ''; return; }
  if (cmd === 'random') { randomTopic(); return terminalPrint('Random topic opened.'); }
  if (cmd === 'score') { openKnowledgeScore(); return terminalPrint('Score panel opened.'); }
  if (cmd === 'bookmarks') { openBookmarksPanel(); return terminalPrint('Bookmarks opened.'); }
  if (cmd === 'marketplace') { openMarketplace(); return terminalPrint('Marketplace opened.'); }
  if (cmd === 'reading') { openReadingMode(); return terminalPrint('Reading mode opened.'); }
  if (cmd === 'focus') { toggleFocusMode(); return terminalPrint('Focus toggled.'); }
  if (cmd === 'open') {
    const page = flatten(state.tree).find(n => normalizeTitleText(n.title).includes(normalizeTitleText(arg)));
    if (page) { selectPage(page.id); terminalPrint('Opened ' + page.title); } else terminalPrint('No page found.', 'err');
    return;
  }
  if (cmd === 'search') {
    openCommandPalette(); els.commandInput.value = arg; renderCommandResults(); terminalPrint('Search opened.'); return;
  }
  if (cmd === 'new' && rest[0] === 'page') {
    const title = rest.slice(1).join(' ').trim() || 'Untitled';
    const parent = findNode(selectedId) || state.tree;
    const node = { id: uid(), title, icon:'📄', type:'Topic', expanded:false, favorite:false, description:'', blocks:[], children:[] };
    parent.children = parent.children || []; parent.children.push(node); parent.expanded = true; selectedId = node.id; scheduleSave(); renderAll(); terminalPrint('Created ' + title); return;
  }
  terminalPrint('Unknown command. Type help.', 'err');
}

function renderRightPanelExtras() {
  const node = findNode(selectedId); if (!node) return;
  const score = calculateKnowledgeScore();
  const quick = $('#quickInfoBox');
  if (quick) quick.innerHTML = `
    <div class="quick-info-item"><span>Type</span><strong>${escapeHtml(node.type || 'Page')}</strong></div>
    <div class="quick-info-item"><span>Blocks</span><strong>${node.blocks?.length || 0}</strong></div>
    <div class="quick-info-item"><span>Subpages</span><strong>${node.children?.length || 0}</strong></div>
    <div class="quick-info-item"><span>Workspace Score</span><strong>${score.score}%</strong></div>
  `;
  const tags = $('#autoTagsBox');
  if (tags) {
    const text = [node.title, node.type, node.description, blockText(node)].join(' ').toLowerCase();
    const tagMap = ['web','recon','xss','sqli','ssrf','api','tool','lab','report','forensics','reverse','programming','notes','payload','bug bounty'];
    const found = tagMap.filter(t => text.includes(t.replace(' ','')) || text.includes(t));
    const out = [...new Set([node.type, ...found])].filter(Boolean).slice(0,8);
    tags.innerHTML = (out.length ? out : ['notes']).map(t => `<span class="tag-pill">${escapeHtml(t)}</span>`).join('');
  }
  const related = $('#relatedBox');
  if (related) {
    const links = extractQuickLinks(node).map(t => findPageByTitle(t)).filter(Boolean);
    const parent = findParentAndNode(node.id)?.parent;
    const siblings = (parent?.children || []).filter(x => x.id !== node.id).slice(0, 4);
    const pages = [...links, ...siblings].filter((x,i,a)=>x && a.findIndex(y=>y.id===x.id)===i).slice(0,6);
    related.innerHTML = pages.length ? pages.map(p => `<button data-related-open="${p.id}">${escapeHtml(p.icon||'◦')} ${escapeHtml(p.title)}</button>`).join('') : '<small>No related pages yet. Use [[Page Name]] in notes.</small>';
    related.querySelectorAll('[data-related-open]').forEach(b => b.addEventListener('click', () => selectPage(b.dataset.relatedOpen)));
  }
}

const oldRenderPageV20 = renderPage;
renderPage = function() { oldRenderPageV20(); renderRightPanelExtras(); };

const oldSaveStateV20 = saveState;
saveState = function() { ensureV20Stores(); oldSaveStateV20(); };

const oldRenderCommandResultsV20 = renderCommandResults;
renderCommandResults = function() {
  oldRenderCommandResultsV20();
  // Remove any leftover Dork Assistant entries from older feature layer.
  [...els.commandResults.querySelectorAll('.command-item')].forEach(item => { if (/dork/i.test(item.textContent)) item.remove(); });
  const q = els.commandInput.value.toLowerCase().trim();
  const extras = [
    { icon:'◎', title:'Open Knowledge Score', type:'Workspace', fn:openKnowledgeScore },
    { icon:'≋', title:'Open Duplicate Detector', type:'Workspace', fn:openDuplicateDetector },
    { icon:'☍', title:'Open Mini Browser Bookmarks', type:'Workspace', fn:openBookmarksPanel },
    { icon:'▣', title:'Open Local Workspace Marketplace', type:'Workspace', fn:openMarketplace },
    { icon:'◌', title:'Open Reading Mode', type:'View', fn:openReadingMode },
    { icon:'⌁', title:'Open Cyber Terminal Launcher', type:'View', fn:openTerminalLauncher }
  ].filter(c => !q || c.title.toLowerCase().includes(q));
  if (!extras.length) return;
  const sep = document.createElement('div'); sep.className = 'command-separator'; sep.textContent = 'Knowledge OS v2.0';
  els.commandResults.prepend(sep);
  extras.reverse().forEach(c => {
    const el = document.createElement('div');
    el.className = 'command-item';
    el.innerHTML = `<span>${escapeHtml(c.icon)}</span><div>${escapeHtml(c.title)}<br><small>${escapeHtml(c.type)}</small></div><small>Run</small>`;
    el.addEventListener('click', () => { closeCommandPalette(); c.fn(); });
    els.commandResults.insertBefore(el, sep.nextSibling);
  });
};

const oldCloseBackdropIfClearV20 = closeBackdropIfClear;
closeBackdropIfClear = function() {
  const panels = [
    els.modal, els.allPagesPanel, els.backupPanel, els.statusBoardPanel, els.workspaceModal, els.commandPalette,
    $('#quickCapturePanel'), $('#inboxPanel'), $('#trashPanel'), $('#mapPanel'), $('#graphPanel'), $('#vaultPanel'), $('#timelinePanel'), $('#snapshotsPanel'), $('#themeStudioPanel'), $('#pluginsPanel'),
    $('#scorePanel'), $('#duplicatesPanel'), $('#bookmarksPanel'), $('#marketplacePanel')
  ].filter(Boolean);
  if (panels.every(p => p.classList.contains('hidden'))) els.backdrop.classList.add('hidden');
};

function blockDisplayTextSafe(b) { return (b?.content || b?.children || b?.caption || b?.name || '').toString(); }

/* v2.1 cleanup: remove experimental commands while keeping editor slash commands. */
(function cleanupV21(){
  const REMOVED_COMMAND_PATTERNS = [
    /random topic/i,
    /random task/i,
    /random payload/i,
    /payload drill/i,
    /focus mode/i,
    /cyber terminal/i,
    /terminal launcher/i,
    /secret mode/i,
    /audio/i,
    /music/i,
    /dork/i
  ];

  function scrubCommandResults(){
    const box = document.querySelector('#commandResults');
    if (!box) return;
    [...box.querySelectorAll('.command-item')].forEach(item => {
      const text = item.textContent || '';
      if (REMOVED_COMMAND_PATTERNS.some(rx => rx.test(text))) item.remove();
    });
    [...box.querySelectorAll('.command-separator')].forEach(sep => {
      let next = sep.nextElementSibling;
      let hasItem = false;
      while (next && !next.classList.contains('command-separator')) {
        if (next.classList.contains('command-item')) { hasItem = true; break; }
        next = next.nextElementSibling;
      }
      if (!hasItem) sep.remove();
    });
  }

  const oldRender = window.renderCommandResults;
  if (typeof oldRender === 'function') {
    window.renderCommandResults = function(){
      oldRender.apply(this, arguments);
      scrubCommandResults();
    };
  }

  function hideRemovedUI(){
    ['randomTopicBtn','randomPayloadBtn','focusBtn','terminalBtn','secretBtn','audioBtn','newWorkspaceBtn','musicDock','terminalPanel','secretCover'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.style.display = 'none';
    });
    document.querySelectorAll('[data-plugin-toggle="audio"]').forEach(el => {
      const row = el.closest('label');
      if (row) row.style.display = 'none';
    });
  }
  document.addEventListener('DOMContentLoaded', hideRemovedUI);
  setTimeout(hideRemovedUI, 0);
})();


/* v2.2 — Floating Utility Orb
   Keeps heavy workspace tools hidden inside one circular launcher. */
function bindUtilityOrb() {
  const toggle = document.querySelector('#utilityOrbToggle');
  const panel = document.querySelector('#utilityOrbPanel');
  const orb = document.querySelector('#utilityOrb');
  if (!toggle || !panel || toggle.dataset.bound === '1') return;
  toggle.dataset.bound = '1';

  const close = () => {
    panel.classList.add('hidden');
    toggle.setAttribute('aria-expanded', 'false');
    orb?.classList.remove('open');
  };
  const open = () => {
    panel.classList.remove('hidden');
    toggle.setAttribute('aria-expanded', 'true');
    orb?.classList.add('open');
  };
  const runAction = (action) => {
    const actions = {
      inbox: () => openInbox?.(),
      trash: () => openTrash?.(),
      vault: () => openVault?.(),
      timeline: () => openTimeline?.(),
      snapshots: () => openSnapshots?.(),
      xenon: () => toggleXenon?.(),
      themeStudio: () => openThemeStudio?.(),
      plugins: () => openPlugins?.(),
      score: () => openKnowledgeScore?.(),
      duplicates: () => openDuplicateDetector?.(),
      bookmarks: () => openBookmarksPanel?.(),
      marketplace: () => openMarketplace?.(),
      reading: () => openReadingMode?.(),
      backup: () => openBackupCenter?.(),
      newPage: () => openPageModal?.('create', selectedId)
    };
    try { actions[action]?.(); }
    catch (err) { console.warn('Utility orb action failed:', action, err); toast?.('Tool is not ready yet'); }
  };

  toggle.addEventListener('click', (e) => {
    e.stopPropagation();
    panel.classList.contains('hidden') ? open() : close();
  });
  panel.querySelectorAll('[data-orb-action]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const action = btn.dataset.orbAction;
      close();
      runAction(action);
    });
  });
  document.addEventListener('click', (e) => {
    if (!orb?.contains(e.target)) close();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') close();
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'u') {
      e.preventDefault();
      panel.classList.contains('hidden') ? open() : close();
    }
  });
}
setTimeout(bindUtilityOrb, 0);

/* v2.4 — Notion Polish Update
   Keeps v2.3 features but makes the editor cleaner, quieter, and closer to Notion. */
(function(){
  const SEARCH_SCOPE_KEY = 'rtos-v24-search-scope';
  const RIGHT_PANEL_KEY = 'rtos-v24-right-panel-collapsed';
  window.v24SearchScope = localStorage.getItem(SEARCH_SCOPE_KEY) || 'current';

  function enablePolishShell(){
    document.body.classList.add('v24-notion-polish');
    if (localStorage.getItem(RIGHT_PANEL_KEY) === '1') document.body.classList.add('right-panel-collapsed');
    ensureRightPanelToggle();
    slimTopActions();
    cleanEditorHints();
  }

  function slimTopActions(){
    // The tools live in the orb now. Keep only Search, New Page, and the timer visible.
    const keep = new Set(['commandBtn','newPageBtn','sessionClock']);
    document.querySelectorAll('.top-actions > *').forEach(el => {
      if (el.tagName === 'INPUT') return;
      if (!keep.has(el.id)) el.classList.add('v24-top-hidden');
    });
  }

  function cleanEditorHints(){
    const drop = document.querySelector('#dropHint');
    if (drop) drop.textContent = 'Drop files on a specific block or insertion line.';
    const addRow = document.querySelector('#notionAddRow');
    if (addRow && !addRow.dataset.v24Cleaned) {
      addRow.dataset.v24Cleaned = '1';
      addRow.innerHTML = '<span>＋</span><button data-add-block="text">Text</button><button data-add-block="heading">Heading</button><button data-add-block="toggle">Toggle</button><button data-add-block="bulleted">Bullet</button><button data-add-block="numbered">Numbered</button><button data-add-block="image">Image</button><button data-add-block="file">File</button>';
      addRow.querySelectorAll('[data-add-block]').forEach(btn => btn.addEventListener('click', () => requestAddBlock(btn.dataset.addBlock)));
    }
  }

  function ensureRightPanelToggle(){
    if (document.querySelector('#rightPanelToggle')) return;
    const btn = document.createElement('button');
    btn.id = 'rightPanelToggle';
    btn.className = 'right-panel-toggle';
    btn.title = 'Show / hide right panel';
    btn.textContent = document.body.classList.contains('right-panel-collapsed') ? '☰' : '›';
    btn.addEventListener('click', () => {
      document.body.classList.toggle('right-panel-collapsed');
      const collapsed = document.body.classList.contains('right-panel-collapsed');
      localStorage.setItem(RIGHT_PANEL_KEY, collapsed ? '1' : '0');
      btn.textContent = collapsed ? '☰' : '›';
    });
    document.body.appendChild(btn);
  }

  function placeCaretEnd(el){
    try {
      el.focus();
      const range = document.createRange();
      range.selectNodeContents(el);
      range.collapse(false);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    } catch {}
  }

  function addFirstBlockFromEmpty(node, text){
    const clean = text || '';
    const b = createBlock('text', clean);
    node.blocks = [b];
    activeBlockId = b.id;
    scheduleSave();
    renderPage();
    setTimeout(() => {
      const target = document.querySelector(`.block[data-id="${b.id}"] .block-content`);
      if (!target) return;
      placeCaretEnd(target);
      if (clean.trim() === '/') showSlashMenu(target);
    }, 20);
  }

  const oldRenderBlocks = renderBlocks;
  renderBlocks = function(node){
    if (!els.blocks) return oldRenderBlocks(node);
    if (!Array.isArray(node.blocks)) node.blocks = [];
    els.blocks.innerHTML = '';
    if (!node.blocks.length) {
      const empty = document.createElement('div');
      empty.className = 'notion-empty-editor';
      empty.contentEditable = 'true';
      empty.spellcheck = false;
      empty.dataset.placeholder = 'Type / for commands';
      empty.addEventListener('input', () => {
        const text = empty.textContent || '';
        if (text.length) addFirstBlockFromEmpty(node, text);
      });
      empty.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); addFirstBlockFromEmpty(node, ''); }
      });
      els.blocks.appendChild(empty);
      return;
    }
    node.blocks.forEach((block, index) => {
      els.blocks.appendChild(renderBlock(block, index));
      els.blocks.appendChild(renderInsertRow(index + 1));
    });
  };

  const oldRenderSubpages = renderSubpages;
  renderSubpages = function(node){
    if (!els.subpagesPanel) return oldRenderSubpages(node);
    const children = Array.isArray(node.children) ? node.children : [];
    const rows = children.map(child => `
      <button class="subpage-row" data-subpage-open="${child.id}" data-subpage-id="${child.id}">
        <span class="subpage-icon">${escapeHtml(child.icon || '📄')}</span>
        <span class="subpage-title">${escapeHtml(child.title || 'Untitled')}</span>
        <span class="subpage-meta">${escapeHtml(child.type || 'Page')}</span>
      </button>`).join('');
    els.subpagesPanel.innerHTML = `
      <div class="subpages-title"><span>Subpages</span><button id="subpageAddBtn" title="Add subpage">＋ New</button></div>
      ${children.length ? rows : '<div class="empty-subpages">No subpages yet.</div>'}
    `;
    els.subpagesPanel.querySelector('#subpageAddBtn')?.addEventListener('click', () => openPageModal('create', node.id));
    els.subpagesPanel.querySelectorAll('[data-subpage-open]').forEach(row => {
      row.addEventListener('click', () => selectPage(row.dataset.subpageOpen));
      row.addEventListener('contextmenu', (e) => showNodeContext(e, row.dataset.subpageOpen));
      row.draggable = true;
      row.addEventListener('dragstart', (e) => { dragNodeId = row.dataset.subpageId; e.dataTransfer.effectAllowed = 'move'; });
      row.addEventListener('dragover', (e) => { e.preventDefault(); row.classList.add('drag-over'); });
      row.addEventListener('dragleave', () => row.classList.remove('drag-over'));
      row.addEventListener('drop', (e) => {
        e.preventDefault(); row.classList.remove('drag-over');
        if (!dragNodeId || dragNodeId === row.dataset.subpageId) return;
        moveNodeInto(dragNodeId, row.dataset.subpageId);
        dragNodeId = null;
      });
    });
  };

  const oldShowSlashMenu = showSlashMenu;
  showSlashMenu = function(target){
    const text = target.textContent.trim();
    if (text !== '/') return;
    const r = target.getBoundingClientRect();
    const items = [
      ['heading', 'H1', 'Heading 1', '#'],
      ['subheading', 'H2', 'Heading 2', '##'],
      ['heading3', 'H3', 'Heading 3', '###'],
      ['heading4', 'H4', 'Heading 4', '####'],
      ['text', 'T', 'Text', ''],
      ['bulleted', '•', 'Bulleted list', '-'],
      ['numbered', '1.', 'Numbered list', '1.'],
      ['checklist', '☐', 'To-do list', '[]'],
      ['toggle', '▸', 'Toggle list', '>'],
      ['code', '{}', 'Code', ''],
      ['quote', '❝', 'Quote', ''],
      ['callout', '✦', 'Callout', ''],
      ['divider', '—', 'Divider', ''],
      ['page', '▣', 'Page', ''],
      ['image', '▧', 'Image', ''],
      ['file', '⌁', 'File', '']
    ];
    els.slashMenu.innerHTML = items.map(([t, icon, label, hint]) => `<button data-type="${t}"><span class="slash-icon">${icon}</span><span class="slash-label">${label}</span><span class="slash-hint">${hint}</span></button>`).join('');
    els.slashMenu.style.left = Math.min(r.left, window.innerWidth - 320) + 'px';
    els.slashMenu.style.top = Math.min(r.bottom + 8, window.innerHeight - 520) + 'px';
    els.slashMenu.classList.remove('hidden');
    els.slashMenu.querySelectorAll('button').forEach(btn => btn.addEventListener('click', () => {
      const node = findNode(selectedId);
      if (!node) return;
      let b = node.blocks?.find(x => x.id === activeBlockId);
      const type = btn.dataset.type;
      if (!b) {
        addBlock(type, '');
        els.slashMenu.classList.add('hidden');
        return;
      }
      if (type === 'image' || type === 'file') {
        b.content = '';
        scheduleSave();
        renderPage();
        requestAddBlock(type);
        els.slashMenu.classList.add('hidden');
        return;
      }
      b.type = type;
      b.content = '';
      if (type === 'toggle') { b.open = true; b.children = ''; }
      els.slashMenu.classList.add('hidden');
      scheduleSave();
      renderPage();
    }));
  };

  function ensureCommandScope(){
    const palette = els.commandPalette;
    if (!palette || palette.querySelector('.command-scope')) return;
    const scope = document.createElement('div');
    scope.className = 'command-scope';
    scope.innerHTML = '<button data-scope="current">Current Workspace</button><button data-scope="all">All Workspaces</button>';
    palette.insertBefore(scope, els.commandInput);
    scope.querySelectorAll('button').forEach(btn => btn.addEventListener('click', () => {
      window.v24SearchScope = btn.dataset.scope;
      localStorage.setItem(SEARCH_SCOPE_KEY, window.v24SearchScope);
      updateCommandScopeButtons();
      renderCommandResults();
    }));
    updateCommandScopeButtons();
  }
  function updateCommandScopeButtons(){
    document.querySelectorAll('.command-scope button').forEach(btn => btn.classList.toggle('active', btn.dataset.scope === window.v24SearchScope));
  }

  const oldOpenCommandPalette = openCommandPalette;
  openCommandPalette = function(){
    oldOpenCommandPalette();
    ensureCommandScope();
    updateCommandScopeButtons();
  };

  function addV24CommandItem(icon, title, type, fn, extra = ''){
    const el = document.createElement('div');
    el.className = 'command-item search-result-item';
    el.innerHTML = `<span>${escapeHtml(icon || '◦')}</span><div>${escapeHtml(title)}<br><small>${escapeHtml(type || 'Page')}</small>${extra ? `<em>${escapeHtml(extra)}</em>` : ''}</div><small>Open</small>`;
    el.addEventListener('click', fn);
    els.commandResults.appendChild(el);
  }

  renderCommandResults = function(){
    ensureCommandScope();
    const q = (els.commandInput?.value || '').toLowerCase().trim();
    const commands = [
      { icon:'＋', title:'Create New Page', type:'Command', fn: () => openPageModal('create', selectedId) },
      { icon:'⌂', title:'Open Dashboard', type:'Command', fn: () => selectPage(state.tree.id) },
      { icon:'▦', title:'Open All Pages', type:'Command', fn: openAllPages },
      { icon:'💾', title:'Open Backup Center', type:'Command', fn: openBackupCenter },
      { icon:'◉', title:'Open Workspace Tools', type:'Command', fn: () => document.querySelector('#utilityOrbToggle')?.click() }
    ].filter(c => !q || c.title.toLowerCase().includes(q));
    els.commandResults.innerHTML = '';
    commands.forEach(c => addV24CommandItem(c.icon, c.title, c.type, () => { closeCommandPalette(); c.fn(); }));

    const currentWs = getActiveWorkspace();
    const spaces = window.v24SearchScope === 'all' ? workspaceDb.workspaces : [currentWs];
    const results = [];
    spaces.forEach(ws => {
      normalizeWorkspace(ws.data);
      flatten(ws.data.tree).forEach(n => {
        const hay = [n.title, n.type, n.description, blockText(n), getPathInTree(ws.data.tree, n.id).map(x => x.title).join(' / ')].join(' ').toLowerCase();
        if (!q || hay.includes(q)) results.push({ ws, n });
      });
    });
    results.slice(0, 45).forEach(({ws, n}) => {
      const path = getPathInTree(ws.data.tree, n.id).map(x => x.title).join(' / ');
      addV24CommandItem(n.icon, n.title, `${ws.name} · ${n.type || 'Page'}`, () => {
        closeCommandPalette();
        if (workspaceDb.activeId !== ws.id) {
          workspaceDb.activeId = ws.id;
          state = ws.data;
        }
        selectPage(n.id);
      }, path);
    });
  };

  function getPathInTree(root, id){
    const trail = [];
    function walk(n){
      trail.push(n);
      if (n.id === id) return true;
      for (const c of (n.children || [])) if (walk(c)) return true;
      trail.pop();
      return false;
    }
    walk(root);
    return trail;
  }

  const oldRenderPage = renderPage;
  renderPage = function(){
    oldRenderPage();
    enablePolishShell();
    const node = findNode(selectedId);
    if (node && (!node.blocks || node.blocks.length === 0)) {
      setTimeout(() => document.querySelector('.notion-empty-editor')?.focus(), 40);
    }
  };

  // Make reading mode cleaner without removing editing state permanently.
  const oldOpenReadingMode = window.openReadingMode || (typeof openReadingMode === 'function' ? openReadingMode : null);
  if (oldOpenReadingMode) {
    openReadingMode = function(){
      document.body.classList.add('v24-reading-clean');
      oldOpenReadingMode.apply(this, arguments);
      setTimeout(() => document.body.classList.remove('v24-reading-clean'), 500);
    };
  }

  // Start polish immediately and rerender once so overrides apply to the current page.
  enablePolishShell();
  setTimeout(() => { try { renderAll(); } catch(e) { console.warn('v2.4 polish render failed', e); } }, 0);
})();


/* v2.5 — Notion Intelligence Pack: page preview, smart templates, covers, page lock, link previews, stronger marketplace, workspace themes, page health. */
const V25_VERSION = 1;
const V25_THEME_MAP = {
  "red-team": "red-team",
  "forensics": "forensics",
  "programming": "programming",
  "reverse": "reverse",
  "dark-research": "deep-web",
  "study": "study",
  "marketplace": "red-team",
  "blank": "neutral"
};
const V25_TEMPLATE_PACKS = [
  { id:'vuln-note', icon:'🚨', title:'Vulnerability Note', desc:'Overview, impact, detection notes, evidence, references.', blocks:[
    ['heading','Overview'], ['text',''], ['heading','Impact'], ['text',''], ['heading','Detection Notes'], ['bulleted',''], ['heading','Evidence'], ['text',''], ['heading','References'], ['bulleted','']
  ]},
  { id:'tool-note', icon:'🛠️', title:'Tool Note', desc:'Purpose, setup notes, common usage, troubleshooting, related pages.', blocks:[
    ['heading','Purpose'], ['text',''], ['heading','Setup Notes'], ['text',''], ['heading','Common Usage'], ['code',''], ['heading','Troubleshooting'], ['bulleted',''], ['heading','Related Pages'], ['text','[[Related Page]]']
  ]},
  { id:'lab-note', icon:'🧪', title:'Lab Note', desc:'Goal, environment, steps, what worked, what failed, lesson learned.', blocks:[
    ['heading','Goal'], ['text',''], ['heading','Environment'], ['text',''], ['heading','Steps'], ['numbered',''], ['heading','What Worked'], ['bulleted',''], ['heading','What Failed'], ['bulleted',''], ['heading','Lesson Learned'], ['text','']
  ]},
  { id:'report-note', icon:'📑', title:'Report Note', desc:'Summary, scope, evidence, risk, recommendation, timeline.', blocks:[
    ['heading','Summary'], ['text',''], ['heading','Scope'], ['text',''], ['heading','Evidence'], ['text',''], ['heading','Risk'], ['text',''], ['heading','Recommendation'], ['text',''], ['heading','Timeline'], ['bulleted','']
  ]},
  { id:'forensics-case', icon:'🧬', title:'Forensics Case', desc:'Case summary, evidence, timeline, artifacts, findings.', blocks:[
    ['heading','Case Summary'], ['text',''], ['heading','Evidence'], ['bulleted',''], ['heading','Timeline'], ['bulleted',''], ['heading','Artifacts'], ['bulleted',''], ['heading','Findings'], ['text','']
  ]},
  { id:'programming-project', icon:'💻', title:'Programming Project', desc:'Goal, stack, features, tasks, bugs, notes.', blocks:[
    ['heading','Goal'], ['text',''], ['heading','Tech Stack'], ['bulleted',''], ['heading','Features'], ['checklist',''], ['heading','Bugs'], ['bulleted',''], ['heading','Notes'], ['text','']
  ]},
  { id:'reverse-note', icon:'🧩', title:'Reverse Engineering Note', desc:'Target, observations, strings, functions, findings.', blocks:[
    ['heading','Target'], ['text',''], ['heading','Observations'], ['bulleted',''], ['heading','Strings / Indicators'], ['code',''], ['heading','Functions'], ['bulleted',''], ['heading','Findings'], ['text','']
  ]}
];

function v25EnsureDom() {
  if (!$('#pageCoverBar')) {
    const cover = document.createElement('section');
    cover.id = 'pageCoverBar';
    cover.className = 'page-cover hidden';
    cover.innerHTML = '<div class="page-cover-shade"></div><div class="page-cover-text" id="pageCoverText"></div>';
    const hero = document.querySelector('.hero');
    hero?.parentNode?.insertBefore(cover, hero);
  }
  if (!$('#pagePreviewPopover')) {
    const prev = document.createElement('div');
    prev.id = 'pagePreviewPopover';
    prev.className = 'page-preview-popover hidden';
    document.body.appendChild(prev);
  }
  if (!$('#smartTemplatePanel')) {
    const panel = document.createElement('section');
    panel.id = 'smartTemplatePanel';
    panel.className = 'data-panel compact-panel hidden';
    panel.innerHTML = `
      <div class="data-panel-head"><div><h2>Smart Templates</h2><p>Insert a structured page layout into the current page.</p></div><button id="smartTemplateClose">×</button></div>
      <div id="smartTemplateGrid" class="smart-template-grid"></div>
    `;
    document.body.appendChild(panel);
    $('#smartTemplateClose')?.addEventListener('click', closeSmartTemplates);
  }
  if (!$('#pageHealthBox')) {
    const quickCard = document.querySelector('.quick-info-card');
    const card = document.createElement('div');
    card.className = 'side-card page-health-card';
    card.innerHTML = '<div class="side-title">Page Health</div><div id="pageHealthBox" class="page-health-box"></div>';
    quickCard?.after(card);
  }
  const pageControl = document.querySelector('.page-control-card');
  if (pageControl && !$('#pageLockBtn')) {
    pageControl.insertAdjacentHTML('beforeend', `
      <button class="wide-btn" id="pageCoverBtn">Add / Change Cover</button>
      <button class="wide-btn ghost" id="pageCoverRemoveBtn">Remove Cover</button>
      <button class="wide-btn" id="pageLockBtn">Lock Page</button>
    `);
    $('#pageCoverBtn')?.addEventListener('click', changePageCover);
    $('#pageCoverRemoveBtn')?.addEventListener('click', removePageCover);
    $('#pageLockBtn')?.addEventListener('click', togglePageLock);
  }
}

function v25NormalizeCurrentNode(node) {
  if (!node) return;
  if (typeof node.locked !== 'boolean') node.locked = false;
  if (typeof node.coverText !== 'string') node.coverText = '';
  if (typeof node.coverStyle !== 'string') node.coverStyle = '';
}

function v25BlockText(b) {
  if (!b) return '';
  return [b.content || '', b.children || '', b.caption || '', b.name || ''].join(' ');
}
function v25NodeText(node) { return [node?.title || '', node?.description || '', ...(node?.blocks || []).map(v25BlockText)].join('\n'); }
function v25FirstLines(node) {
  const lines = v25NodeText(node).split(/\n+/).map(x => x.trim()).filter(Boolean);
  return lines.slice(0, 3).join(' · ') || 'Empty page';
}
function v25ExtractUrls(text) {
  const re = /https?:\/\/[^\s<>()"']{4,}/gi;
  return [...new Set((text || '').match(re) || [])].slice(0, 3);
}
function v25UrlHost(url) { try { return new URL(url).hostname.replace(/^www\./,''); } catch { return url; } }
function v25LinkPreviewHtml(url) {
  return `<a class="link-preview-card" href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">
    <span class="link-preview-icon">↗</span><span><strong>${escapeHtml(v25UrlHost(url))}</strong><small>${escapeHtml(url)}</small></span>
  </a>`;
}

function v25ApplyPageLockState(node) {
  document.body.classList.toggle('page-locked', !!node.locked);
  els.pageTitle?.setAttribute('contenteditable', node.locked ? 'false' : 'true');
  els.pageDescription?.setAttribute('contenteditable', node.locked ? 'false' : 'true');
  document.querySelectorAll('#blocks [contenteditable="true"], #blocks [contenteditable="false"]').forEach(el => el.setAttribute('contenteditable', node.locked ? 'false' : 'true'));
  $('#pageLockBtn') && ($('#pageLockBtn').textContent = node.locked ? 'Unlock Page' : 'Lock Page');
}

function v25RenderCover(node) {
  const cover = $('#pageCoverBar');
  const text = $('#pageCoverText');
  if (!cover || !text) return;
  if (!node.coverText && !node.coverStyle) { cover.classList.add('hidden'); return; }
  cover.classList.remove('hidden');
  cover.dataset.coverStyle = node.coverStyle || 'shadow';
  text.textContent = node.coverText || node.title || '';
}
function changePageCover() {
  const node = findNode(selectedId); if (!node) return;
  const text = prompt('Cover text', node.coverText || node.title || '');
  if (text === null) return;
  const styles = ['shadow','red','gray','blue','green','purple'];
  const style = prompt('Cover style: shadow, red, gray, blue, green, purple', node.coverStyle || 'shadow') || 'shadow';
  node.coverText = text.trim();
  node.coverStyle = styles.includes(style.trim()) ? style.trim() : 'shadow';
  scheduleSave(); renderPage(); toast('Cover updated');
}
function removePageCover() {
  const node = findNode(selectedId); if (!node) return;
  node.coverText = ''; node.coverStyle = '';
  scheduleSave(); renderPage(); toast('Cover removed');
}
function togglePageLock() {
  const node = findNode(selectedId); if (!node) return;
  node.locked = !node.locked;
  scheduleSave(); renderPage(); toast(node.locked ? 'Page locked' : 'Page unlocked');
}

function v25CalculatePageHealth(node) {
  const blocks = node.blocks || [];
  const textLen = v25NodeText(node).trim().length;
  const headings = blocks.filter(b => ['heading','subheading','heading3','heading4','toggle'].includes(b.type)).length;
  const media = blocks.filter(b => ['image','file'].includes(b.type)).length;
  const links = extractQuickLinks(node).length + v25ExtractUrls(v25NodeText(node)).length;
  const subpages = (node.children || []).length;
  let score = 0;
  if (textLen > 30) score += 28;
  if (textLen > 160) score += 20;
  if (headings) score += 18;
  if (links) score += 12;
  if (media) score += 10;
  if (subpages) score += 8;
  if (node.description && node.description.trim()) score += 4;
  const missing = [];
  if (textLen <= 30) missing.push('notes');
  if (!headings) missing.push('headings');
  if (!links) missing.push('links');
  if (!media) missing.push('media');
  return { score: Math.min(100, score), missing };
}
function v25RenderPageHealth(node) {
  const box = $('#pageHealthBox'); if (!box) return;
  const h = v25CalculatePageHealth(node);
  box.innerHTML = `<div class="health-meter"><span style="width:${h.score}%"></span></div><div class="health-row"><strong>${h.score}%</strong><small>${h.missing.length ? 'Missing: '+h.missing.join(', ') : 'Looks organized'}</small></div>`;
}

function openSmartTemplates() {
  v25EnsureDom();
  const grid = $('#smartTemplateGrid'); if (!grid) return;
  grid.innerHTML = V25_TEMPLATE_PACKS.map(t => `<button class="smart-template-card" data-smart-template="${escapeHtml(t.id)}"><span>${escapeHtml(t.icon)}</span><strong>${escapeHtml(t.title)}</strong><small>${escapeHtml(t.desc)}</small></button>`).join('');
  grid.querySelectorAll('[data-smart-template]').forEach(btn => btn.addEventListener('click', () => insertSmartTemplate(btn.dataset.smartTemplate)));
  els.backdrop.classList.remove('hidden');
  $('#smartTemplatePanel')?.classList.remove('hidden');
}
function closeSmartTemplates() { $('#smartTemplatePanel')?.classList.add('hidden'); closeBackdropIfClear(); }
function insertSmartTemplate(id) {
  const tpl = V25_TEMPLATE_PACKS.find(x => x.id === id); const node = findNode(selectedId);
  if (!tpl || !node) return;
  if (!Array.isArray(node.blocks)) node.blocks = [];
  const blocks = tpl.blocks.map(([type, content]) => createBlock(type, content));
  node.blocks.push(...blocks);
  closeSmartTemplates(); scheduleSave(); renderPage(); toast(tpl.title + ' inserted');
}

function v25InstallPagePreview() {
  const preview = $('#pagePreviewPopover'); if (!preview || preview.dataset.bound) return;
  preview.dataset.bound = '1';
  let previewTimer = null;
  document.addEventListener('mouseover', (e) => {
    const row = e.target.closest('.tree-row[data-id], .subpage-row[data-subpage-id], [data-related-open]');
    if (!row) return;
    const id = row.dataset.id || row.dataset.subpageId || row.dataset.relatedOpen;
    const node = findNode(id); if (!node) return;
    clearTimeout(previewTimer);
    previewTimer = setTimeout(() => {
      preview.innerHTML = `<div class="preview-title">${escapeHtml(node.icon||'◦')} ${escapeHtml(node.title||'Untitled')}</div><div class="preview-path">${escapeHtml(getPath(node.id).map(x=>x.title).join(' / '))}</div><p>${escapeHtml(v25FirstLines(node))}</p>`;
      const r = row.getBoundingClientRect();
      preview.style.left = Math.min(r.right + 14, window.innerWidth - 360) + 'px';
      preview.style.top = Math.min(r.top, window.innerHeight - 180) + 'px';
      preview.classList.remove('hidden');
    }, 350);
  });
  document.addEventListener('mouseout', (e) => {
    if (e.target.closest('.tree-row[data-id], .subpage-row[data-subpage-id], [data-related-open]')) {
      clearTimeout(previewTimer); preview.classList.add('hidden');
    }
  });
}

function v25WorkspaceThemeName() {
  const ws = getActiveWorkspace?.();
  const t = state.tree?.workspaceTheme || state.tree?.template || ws?.template || 'blank';
  return V25_THEME_MAP[t] || (String(t).includes('forensic') ? 'forensics' : String(t).includes('program') ? 'programming' : 'neutral');
}
function v25ApplyWorkspaceTheme() {
  document.body.dataset.workspaceTheme = v25WorkspaceThemeName();
}

function v25EnhanceMarketplace() {
  if (window.__v25MarketplaceEnhanced) return;
  window.__v25MarketplaceEnhanced = true;
  const extra = [
    { id:'web-pentest', icon:'🌐', title:'Web Pentesting Workspace', desc:'Fundamentals, recon, web vulnerabilities, API security, tools, labs, reports.', children:[['🌐','Fundamentals'],['🔍','Recon'],['🚨','Vulnerabilities'],['📡','API Security'],['🛠️','Tools'],['🧪','Labs'],['📑','Reports']]},
    { id:'active-directory', icon:'🏰', title:'Active Directory Workspace', desc:'AD basics, users/groups, Kerberos notes, lab notes, tools, detection notes.', children:[['🏰','AD Basics'],['👥','Users & Groups'],['🔐','Kerberos'],['📇','LDAP'],['🧭','Privilege Paths'],['🧪','Labs'],['🛠️','Tools']]},
    { id:'osint', icon:'🛰️', title:'OSINT Workspace', desc:'Sources, usernames, domains, emails, bookmarks, evidence notes, timelines.', children:[['🛰️','Sources'],['👤','Usernames'],['🌐','Domains'],['✉️','Emails'],['☍','Bookmarks'],['🔎','Evidence'],['⏱️','Timeline']]},
    { id:'malware-analysis', icon:'🦠', title:'Malware Analysis Workspace', desc:'Samples, static analysis, dynamic analysis, IOCs, screenshots, reports.', children:[['📦','Samples'],['🔎','Static Analysis'],['⚙️','Dynamic Analysis'],['🧬','IOCs'],['📸','Screenshots'],['📑','Reports']]},
    { id:'personal-knowledge', icon:'🧠', title:'Personal Knowledge Workspace', desc:'Inbox, concepts, mistakes, dictionary, bookmarks, learning paths.', children:[['📥','Inbox'],['🧠','Concepts'],['⚠️','Mistakes Library'],['📚','Dictionary'],['☍','Bookmarks'],['🧭','Learning Paths']]}
  ];
  extra.forEach(t => { if (!LOCAL_MARKETPLACE_TEMPLATES.some(x => x.id === t.id)) LOCAL_MARKETPLACE_TEMPLATES.push(t); });
}

const v25OldRenderMarketplace = typeof renderMarketplace === 'function' ? renderMarketplace : null;
renderMarketplace = function() {
  v25EnhanceMarketplace();
  const box = $('#marketplaceGrid'); if (!box) return;
  box.innerHTML = LOCAL_MARKETPLACE_TEMPLATES.map(t => `
    <div class="marketplace-card v25-market-card">
      <div class="market-icon">${escapeHtml(t.icon)}</div>
      <h3>${escapeHtml(t.title)}</h3>
      <p>${escapeHtml(t.desc)}</p>
      <div class="market-tags">${(t.children || []).slice(0,4).map(c=>`<span>${escapeHtml(c[1])}</span>`).join('')}</div>
      <button data-install-module="${escapeHtml(t.id)}">Install into current workspace</button>
      <button data-create-market-ws="${escapeHtml(t.id)}">Create workspace</button>
    </div>
  `).join('');
  box.querySelectorAll('[data-install-module]').forEach(btn => btn.addEventListener('click', () => installMarketplaceModule(btn.dataset.installModule)));
  box.querySelectorAll('[data-create-market-ws]').forEach(btn => btn.addEventListener('click', () => createWorkspaceFromMarketplace(btn.dataset.createMarketWs)));
};

const v25OldShowSlashMenu = typeof showSlashMenu === 'function' ? showSlashMenu : null;
showSlashMenu = function(target) {
  v25OldShowSlashMenu?.(target);
  if (!els.slashMenu || els.slashMenu.classList.contains('hidden')) return;
  if (!els.slashMenu.querySelector('[data-type="smartTemplate"]')) {
    const btn = document.createElement('button');
    btn.dataset.type = 'smartTemplate';
    btn.innerHTML = '<span class="slash-icon">▣</span><span class="slash-label">Smart Template</span><span class="slash-hint">template</span>';
    btn.addEventListener('click', () => {
      const b = findNode(selectedId)?.blocks?.find(x => x.id === activeBlockId);
      if (b && (b.content || '').trim() === '/') b.content = '';
      els.slashMenu.classList.add('hidden'); scheduleSave(); renderPage(); openSmartTemplates();
    });
    els.slashMenu.appendChild(btn);
  }
};

const v25OldRenderBlock = typeof renderBlock === 'function' ? renderBlock : null;
renderBlock = function(block, index) {
  const el = v25OldRenderBlock(block, index);
  try {
    if (!['code','file','image'].includes(block.type)) {
      const urls = v25ExtractUrls(v25BlockText(block));
      if (urls.length) {
        const box = document.createElement('div');
        box.className = 'link-preview-list';
        box.innerHTML = urls.map(v25LinkPreviewHtml).join('');
        el.querySelector('.block-body')?.appendChild(box);
      }
    }
  } catch {}
  return el;
};

const v25OldRenderPage = typeof renderPage === 'function' ? renderPage : null;
renderPage = function() {
  v25EnsureDom();
  const node = findNode(selectedId) || state.tree;
  v25NormalizeCurrentNode(node);
  v25OldRenderPage?.();
  v25RenderCover(node);
  v25ApplyPageLockState(node);
  v25RenderPageHealth(node);
  v25ApplyWorkspaceTheme();
  v25InstallPagePreview();
  const tocCard = $('#toc')?.closest('.side-card');
  if (tocCard) tocCard.classList.toggle('hidden-soft', !$('#toc')?.children.length);
};

const v25OldRenderPageControls = typeof renderPageControls === 'function' ? renderPageControls : null;
renderPageControls = function(node) {
  v25OldRenderPageControls?.(node);
  v25EnsureDom();
  v25NormalizeCurrentNode(node);
  $('#pageLockBtn') && ($('#pageLockBtn').textContent = node.locked ? 'Unlock Page' : 'Lock Page');
  $('#pageCoverRemoveBtn') && ($('#pageCoverRemoveBtn').disabled = !node.coverText && !node.coverStyle);
};

const v25OldSaveModalPage = typeof saveModalPage === 'function' ? saveModalPage : null;
saveModalPage = function() {
  const before = selectedId;
  v25OldSaveModalPage?.();
  const n = findNode(selectedId || before);
  if (n) v25NormalizeCurrentNode(n);
};

const v25OldRenderAll = typeof renderAll === 'function' ? renderAll : null;
renderAll = function() { v25EnhanceMarketplace(); v25OldRenderAll?.(); v25ApplyWorkspaceTheme(); };

function v25Boot() {
  v25EnsureDom();
  v25EnhanceMarketplace();
  v25ApplyWorkspaceTheme();
  v25InstallPagePreview();
}
setTimeout(v25Boot, 0);
