const STORAGE_KEY = "red-team-os-data-v1";
const WORKSPACES_KEY = "red-team-os-workspaces-v1";
const LEGACY_STORAGE_KEYS = ["red-team-os-v07", "red-team-os-v06", "red-team-os-v05", "red-team-os-v04"];
const THEME_KEY = "red-team-os-theme-v17";

const PAGE_TYPES = [
  "Folder",
  "Topic",
  "Vulnerability",
  "Tool",
  "Lab",
  "Writeup",
  "Report",
  "Forensics Case",
  "Programming Project",
  "Reverse Engineering",
  "Research Note",
  "Snippet",
  "Evidence",
  "Note"
];

const STATUS_OPTIONS = ["Not Started", "Learning", "Practicing", "Completed", "Mastered"];

const WEB_TREE = {
  id: "root-web",
  title: "Web Application Penetration Testing",
  icon: "📁",
  type: "Folder",
  status: "Learning",
  favorite: true,
  expanded: true,
  description: "Build, edit, and expand your personal web security knowledge base.",
  blocks: [
    { id: uid(), type: "heading", content: "Web Application Penetration Testing" },
    { id: uid(), type: "text", content: "This workspace is designed as a living playbook for learning, notes, labs, references, and safe authorized testing workflows." },
    { id: uid(), type: "toggle", content: "How to use this workspace", open: true, children: "Open a topic from the sidebar, edit blocks, attach screenshots, add notes, and export backups regularly." }
  ],
  children: [
    folder("🌐", "Fundamentals", [
      topic("🌍", "HTTP / HTTPS"), topic("🧭", "DNS"), topic("🍪", "Cookies"), topic("🧩", "Sessions"), topic("🛡️", "SOP"), topic("🔁", "CORS"), topic("📜", "CSP"), topic("🔐", "Authentication")
    ]),
    folder("🔍", "Recon", [
      topic("🧠", "Information Gathering"), topic("🌐", "Subdomain Enumeration"), topic("🏷️", "Virtual Hosts"), topic("📡", "Port Scanning"), topic("🔎", "Google Dorks"), topic("🧬", "Technology Detection"), topic("📂", "Content Discovery")
    ]),
    folder("🛠️", "Tools", [
      tool("🧪", "Burp Suite"), tool("📡", "Nmap"), tool("⚡", "ffuf"), tool("🎯", "Arjun"), tool("🌐", "httpx"), tool("☢️", "nuclei"), tool("🕷️", "katana"), tool("➕", "More Tools")
    ]),
    folder("🚨", "Vulnerabilities", [
      folder("💉", "Injection", [
        vuln("🛢️", "SQLi"), vuln("🧬", "SSTI"), vuln("⌨️", "Command Injection"), vuln("📇", "LDAP Injection"), vuln("🍃", "NoSQL Injection"), vuln("📄", "XXE"), vuln("↩️", "CRLF Injection")
      ]),
      folder("💻", "Client Side", [
        vuln("⚡", "XSS"), vuln("🧱", "HTML Injection"), vuln("🖱️", "Clickjacking"), vuln("🧩", "DOM Clobbering"), vuln("↪️", "Open Redirect")
      ]),
      folder("🔐", "Authentication", [
        vuln("🚪", "Broken Authentication"), vuln("📌", "Session Fixation"), vuln("🍪", "Session Hijacking"), vuln("🔑", "JWT"), vuln("🪪", "OAuth")
      ]),
      folder("🧱", "Access Control", [
        vuln("🆔", "IDOR"), vuln("🛤️", "Path Traversal"), vuln("📁", "File Inclusion"), vuln("⬆️", "Privilege Escalation"), vuln("📦", "Mass Assignment")
      ]),
      vuln("☁️", "SSRF"), vuln("🛡️", "CSRF"), vuln("🔁", "CORS"), vuln("🏁", "Race Condition"), vuln("📨", "HTTP Request Smuggling"), vuln("🧊", "Cache Poisoning"), vuln("🧬", "Prototype Pollution"), vuln("🎭", "Web Cache Deception")
    ]),
    playbookSystemModule(),
    folder("📡", "API Security", [
      topic("🔌", "REST"), topic("📊", "GraphQL"), topic("🧼", "SOAP"), topic("🕸️", "WebSocket")
    ]),
    folder("📑", "Bug Bounty", [
      topic("🧭", "Methodology"), topic("✅", "Checklist"), topic("📝", "Reporting"), topic("📚", "Writeups"), topic("📦", "Payloads")
    ]),
    folder("📚", "Labs", [
      lab("🧪", "PortSwigger"), lab("🧊", "HTB"), lab("🏠", "TryHackMe"), topic("🗒️", "Notes")
    ])
  ]
};

const ROOT_TREE = {
  id: "workspace-root",
  title: "Red Team OS",
  icon: "☠️",
  type: "Workspace",
  status: "Learning",
  favorite: true,
  expanded: true,
  template: "red-team",
  description: "A flexible red team knowledge workspace. Add, delete, rename, and reshape modules freely.",
  blocks: workspaceDashboardBlocks("Red Team OS", "red-team"),
  children: defaultRedTeamModules()
};

function uid() {
  return "id-" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

function folder(icon, title, children = []) {
  return { id: uid(), title, icon, type: "Folder", status: "Not Started", favorite: false, expanded: true, description: `${title} section.`, blocks: defaultBlocks(title, "Folder"), children };
}
function topic(icon, title) {
  return { id: uid(), title, icon, type: "Topic", status: "Not Started", favorite: false, expanded: false, description: `Notes and references for ${title}.`, blocks: defaultBlocks(title, "Topic"), children: [] };
}
function vuln(icon, title) {
  return { id: uid(), title, icon, type: "Vulnerability", status: "Not Started", favorite: false, expanded: false, description: `Structured learning page for ${title}.`, blocks: vulnerabilityBlocks(title), children: [] };
}
function tool(icon, title) {
  return { id: uid(), title, icon, type: "Tool", status: "Not Started", favorite: false, expanded: false, description: `Tool notes for ${title}.`, blocks: toolBlocks(title), children: [] };
}
function lab(icon, title) {
  return { id: uid(), title, icon, type: "Lab", status: "Not Started", favorite: false, expanded: false, description: `Lab tracker for ${title}.`, blocks: labBlocks(title), children: [] };
}


function redTeamCoreModule() {
  return folder("☠️", "Red Team Core", [
    folder("🧭", "Methodology", [
      topic("📌", "Scope & Rules"), topic("🧱", "Kill Chain"), topic("🧬", "MITRE ATT&CK"), topic("📝", "Reporting"), topic("🧠", "Lessons Learned")
    ]),
    folder("🛡️", "OPSEC & Ethics", [
      topic("⚖️", "Legal Boundaries"), topic("🔒", "Data Handling"), topic("📋", "Engagement Notes"), topic("🚦", "Stop Conditions")
    ]),
    folder("🎯", "Operations", [
      topic("🧩", "Planning"), topic("📊", "Objectives"), topic("🧪", "Lab Simulation"), topic("✅", "Checklists")
    ])
  ]);
}

function activeDirectoryModule() {
  return folder("🖥️", "Active Directory", [
    topic("🏛️", "AD Fundamentals"), topic("👥", "Users & Groups"), topic("🔑", "Kerberos"), topic("📇", "LDAP"), topic("🏰", "Domain Controllers"),
    folder("🧭", "Enumeration Notes", [topic("🧠", "Concepts"), topic("🧰", "Tools"), topic("📸", "Screenshots")]),
    folder("📚", "Labs", [lab("🧪", "AD Lab Notes"), topic("✅", "Progress")])
  ]);
}

function osintModule() {
  return folder("🔎", "OSINT", [
    topic("🌐", "Domains"), topic("👤", "Usernames"), topic("📧", "Emails"), topic("🏢", "Companies"), topic("🗺️", "Infrastructure"),
    folder("🧰", "Tools", [tool("🔍", "Search Engines"), tool("📚", "Archives"), tool("🧭", "Maps")]),
    topic("📝", "Source Log")
  ]);
}

function networkModule() {
  return folder("📡", "Network Pentesting", [
    topic("🧱", "Network Basics"), topic("📡", "Port Scanning"), topic("🔌", "Service Enumeration"), topic("🪟", "SMB"), topic("🔐", "SSH"), topic("🖥️", "RDP"), topic("🧭", "Internal Mapping")
  ]);
}

function cloudModule() {
  return folder("☁️", "Cloud Security", [
    topic("🟧", "AWS"), topic("🔷", "Azure"), topic("🌈", "GCP"), topic("🔐", "IAM"), topic("🪣", "Storage"), topic("🧾", "Logs"), topic("⚙️", "Misconfigurations")
  ]);
}

function playbookSystemModule() {
  return folder("🧭", "Playbook System", [
    topic("⚡", "Quick Search Index"),
    payloadPage("📦", "Payload Library"),
    toolkitPage("🧰", "Interactive Toolkit"),
    topic("🧪", "Random Training Drills"),
    topic("🧭", "Methods"),
    topic("🛡️", "WAF Notes & PoC Library"),
    topic("🧠", "Advanced Topics")
  ]);
}

function payloadPage(icon, title) {
  return { id: uid(), title, icon, type: "Topic", status: "Not Started", favorite: false, expanded: false, description: "Organized payload notes for authorized labs and learning.", blocks: payloadLibraryBlocks(title), children: [] };
}

function toolkitPage(icon, title) {
  return { id: uid(), title, icon, type: "Tool", status: "Not Started", favorite: false, expanded: false, description: "Interactive tool notes and command-builder ideas for your own authorized lab workflow.", blocks: toolkitBlocks(title), children: [] };
}

function ensureWebPlaybook(webRoot) {
  if (!webRoot || !Array.isArray(webRoot.children)) return;
  const existing = new Set(webRoot.children.map(n => n.title));
  if (!existing.has("Playbook System")) webRoot.children.splice(Math.min(3, webRoot.children.length), 0, playbookSystemModule());
  const toolkit = webRoot.children.find(n => n.title === "Tools");
  if (toolkit && Array.isArray(toolkit.children)) {
    const toolNames = new Set(toolkit.children.map(n => n.title));
    if (!toolNames.has("Interactive Toolkit")) toolkit.children.push(toolkitPage("🧰", "Interactive Toolkit"));
  }
}

function toolkitModule() {
  return folder("🧰", "Toolkit", [
    folder("🛠️", "Tool Arsenal", [tool("🧪", "Burp Suite"), tool("📡", "Nmap"), tool("⚡", "ffuf"), tool("🎯", "Arjun"), tool("☢️", "nuclei")]),
    folder("📦", "Payload Library", [payloadPage("🧪", "Lab Payload Notes"), payloadPage("🌐", "Web Payload Notes"), payloadPage("📡", "API Payload Notes")]),
    folder("📚", "Cheat Sheets", [topic("🐧", "Linux"), topic("🪟", "Windows"), topic("🌐", "Web"), topic("☁️", "Cloud")]),
    folder("🧪", "Labs & Training", [lab("🧪", "PortSwigger"), lab("🧊", "HTB"), lab("🏠", "TryHackMe"), topic("📝", "Personal Lab")])
  ]);
}

function defaultRedTeamModules() {
  const web = structuredCloneSafe(WEB_TREE);
  return [
    redTeamCoreModule(),
    web,
    activeDirectoryModule(),
    osintModule(),
    networkModule(),
    cloudModule(),
    toolkitModule()
  ];
}

function defaultBlocks(title, type = "Topic") {
  // New pages start completely empty, closer to Notion.
  // Use the + row, slash commands, or templates when you want structure.
  return [];
}

function vulnerabilityBlocks(title) {
  return [
    { id: uid(), type: "heading", content: title },
    { id: uid(), type: "subheading", content: "Overview" },
    { id: uid(), type: "text", content: "Explain the concept in your own words. Keep it focused on authorized labs, learning, and ethical testing." },
    { id: uid(), type: "subheading", content: "How It Works" },
    { id: uid(), type: "text", content: "Describe the root cause, affected components, and common conditions." },
    { id: uid(), type: "subheading", content: "Where To Find" },
    { id: uid(), type: "checklist", checked: false, content: "Forms, parameters, headers, API endpoints, or authentication flows" },
    { id: uid(), type: "subheading", content: "Detection Notes" },
    { id: uid(), type: "text", content: "Write safe detection ideas, lab observations, and false positive notes." },
    { id: uid(), type: "subheading", content: "Impact" },
    { id: uid(), type: "text", content: "Explain business impact and risk in a clear report-style format." },
    { id: uid(), type: "subheading", content: "Labs & References" },
    { id: uid(), type: "text", content: "Add PortSwigger, HTB, TryHackMe, writeups, screenshots, and personal notes." }
  ];
}

function toolBlocks(title) {
  return [
    { id: uid(), type: "heading", content: title },
    { id: uid(), type: "subheading", content: "Purpose" },
    { id: uid(), type: "text", content: "What this tool is used for and when it is useful." },
    { id: uid(), type: "subheading", content: "Setup Notes" },
    { id: uid(), type: "code", content: "# Add your safe lab setup notes here" },
    { id: uid(), type: "subheading", content: "Common Options" },
    { id: uid(), type: "text", content: "Document options you use in authorized labs and training environments." },
    { id: uid(), type: "subheading", content: "Related Topics" },
    { id: uid(), type: "text", content: "Link this tool to vulnerabilities, recon, labs, and writeups." }
  ];
}

function labBlocks(title) {
  return [
    { id: uid(), type: "heading", content: title },
    { id: uid(), type: "subheading", content: "Progress" },
    { id: uid(), type: "checklist", checked: false, content: "Create a lab list" },
    { id: uid(), type: "checklist", checked: false, content: "Attach screenshots and notes" },
    { id: uid(), type: "checklist", checked: false, content: "Write what you learned" },
    { id: uid(), type: "subheading", content: "Notes" },
    { id: uid(), type: "text", content: "Track solved labs, weak points, and topics to revisit." }
  ];
}


function workspaceDashboardBlocks(name, template = "blank") {
  const map = {
    "red-team": [
      ["Mission Control", "Track red team modules, web notes, labs, tools, payload ideas, and safe authorized testing knowledge."],
      ["Current Focus", "Start with Web Application Penetration Testing. Add Active Directory, OSINT, Network, Cloud, and Mobile when the base is stable."],
      ["Quick Rules", "Keep notes organized, attach screenshots, export backups, and separate lab notes from real-world references."]
    ],
    forensics: [
      ["Case Control", "Manage cases, evidence notes, timelines, artifacts, screenshots, and final findings."],
      ["Current Focus", "Start with disk, memory, network, mobile, and Windows/Linux artifact sections."],
      ["Evidence Habit", "Document source, time, tool used, observations, and confidence level for every finding."]
    ],
    programming: [
      ["Developer Control", "Manage languages, projects, snippets, bugs, tasks, experiments, and learning notes."],
      ["Current Focus", "Keep projects separate from snippets. Track errors and fixes as reusable notes."],
      ["Build Habit", "Write goals, features, bugs, next steps, and useful commands for each project."]
    ],
    reverse: [
      ["Reverse Control", "Organize binaries, static notes, dynamic notes, strings, imports, functions, and findings."],
      ["Current Focus", "Separate beginner notes, tools, labs, crackmes, malware-analysis references, and writeups."],
      ["Analysis Habit", "Document environment, sample metadata, observed behavior, screenshots, and lessons learned." ]
    ],
    "dark-research": [
      ["Research Control", "Organize threat intelligence, open-source references, onion notes, sources, screenshots, and safety reminders."],
      ["Current Focus", "Keep this workspace for documentation and research notes only. Avoid illegal access, markets, or harmful activity."],
      ["OPSEC Habit", "Separate sources, dates, confidence, screenshots, and legal/ethical boundaries for every note." ]
    ],
    study: [
      ["Study Control", "Organize subjects, lessons, tasks, references, revision notes, and progress."],
      ["Current Focus", "Split every subject into chapters, exercises, weak points, and summaries."],
      ["Review Habit", "Create checklists, attach files, and mark pages by status."]
    ],
    blank: [
      ["Workspace Control", "Build your own system from scratch. Add modules, pages, files, and templates as needed."],
      ["Current Focus", "Create a few top-level modules first, then expand slowly."],
      ["Organization Habit", "Use status, pins, and backups to keep the workspace clean."]
    ]
  };
  const rows = map[template] || map.blank;
  return [
    { id: uid(), type: "heading", content: name },
    { id: uid(), type: "text", content: "This is the main dashboard page for this workspace. Edit it freely and shape it around your workflow." },
    ...rows.flatMap(([title, body]) => ([
      { id: uid(), type: "subheading", content: title },
      { id: uid(), type: "text", content: body }
    ])),
    { id: uid(), type: "checklist", checked: false, content: "Pin the most important pages" },
    { id: uid(), type: "checklist", checked: false, content: "Export a backup after big edits" }
  ];
}

function caseBlocks(title) {
  return [
    { id: uid(), type: "heading", content: title },
    { id: uid(), type: "subheading", content: "Case Summary" },
    { id: uid(), type: "text", content: "Write the case goal, context, scope, and key questions." },
    { id: uid(), type: "subheading", content: "Evidence" },
    { id: uid(), type: "checklist", checked: false, content: "Attach screenshots, files, logs, or notes" },
    { id: uid(), type: "subheading", content: "Timeline" },
    { id: uid(), type: "text", content: "Document important events in order." },
    { id: uid(), type: "subheading", content: "Findings" },
    { id: uid(), type: "text", content: "Summarize observations and confidence level." },
    { id: uid(), type: "subheading", content: "Final Notes" },
    { id: uid(), type: "text", content: "Lessons learned, follow-up tasks, and references." }
  ];
}

function projectBlocks(title) {
  return [
    { id: uid(), type: "heading", content: title },
    { id: uid(), type: "subheading", content: "Goal" },
    { id: uid(), type: "text", content: "What should this project achieve?" },
    { id: uid(), type: "subheading", content: "Tech Stack" },
    { id: uid(), type: "text", content: "Languages, frameworks, libraries, tools, and environment." },
    { id: uid(), type: "subheading", content: "Features" },
    { id: uid(), type: "checklist", checked: false, content: "Add first feature" },
    { id: uid(), type: "subheading", content: "Bugs & Fixes" },
    { id: uid(), type: "text", content: "Track errors, fixes, and useful references." },
    { id: uid(), type: "subheading", content: "Next Steps" },
    { id: uid(), type: "checklist", checked: false, content: "Define next task" }
  ];
}

function snippetBlocks(title) {
  return [
    { id: uid(), type: "heading", content: title },
    { id: uid(), type: "subheading", content: "Purpose" },
    { id: uid(), type: "text", content: "What problem does this snippet solve?" },
    { id: uid(), type: "subheading", content: "Snippet" },
    { id: uid(), type: "code", content: "// Paste your snippet here" },
    { id: uid(), type: "subheading", content: "Notes" },
    { id: uid(), type: "text", content: "Usage notes, edge cases, and references." }
  ];
}

function evidenceBlocks(title) {
  return [
    { id: uid(), type: "heading", content: title },
    { id: uid(), type: "subheading", content: "Source" },
    { id: uid(), type: "text", content: "Where did this evidence come from?" },
    { id: uid(), type: "subheading", content: "Observation" },
    { id: uid(), type: "text", content: "What does it show? Attach images/files below." },
    { id: uid(), type: "subheading", content: "Confidence" },
    { id: uid(), type: "text", content: "Low / Medium / High and why." }
  ];
}

function reverseBlocks(title) {
  return [
    { id: uid(), type: "heading", content: title },
    { id: uid(), type: "subheading", content: "Target / Sample" },
    { id: uid(), type: "text", content: "Name, hash, platform, architecture, and safe lab context." },
    { id: uid(), type: "subheading", content: "Static Notes" },
    { id: uid(), type: "text", content: "Strings, imports, functions, sections, symbols, and suspicious patterns." },
    { id: uid(), type: "subheading", content: "Dynamic Notes" },
    { id: uid(), type: "text", content: "Observed behavior, logs, screenshots, and lab-only execution notes." },
    { id: uid(), type: "subheading", content: "Findings" },
    { id: uid(), type: "text", content: "Summarize what you learned and what needs deeper analysis." }
  ];
}

function researchBlocks(title) {
  return [
    { id: uid(), type: "heading", content: title },
    { id: uid(), type: "subheading", content: "Research Question" },
    { id: uid(), type: "text", content: "What are you trying to understand or document?" },
    { id: uid(), type: "subheading", content: "Sources" },
    { id: uid(), type: "text", content: "Add source names, dates, confidence level, and screenshots/files if needed." },
    { id: uid(), type: "subheading", content: "Observations" },
    { id: uid(), type: "text", content: "Write neutral observations. Keep it legal, ethical, and research-only." },
    { id: uid(), type: "subheading", content: "Next Notes" },
    { id: uid(), type: "checklist", checked: false, content: "Add follow-up reference" }
  ];
}

const SAFE_PAYLOAD_DRILLS = [
  { category: "Recon", note: "Build a checklist for discovering visible endpoints in an authorized lab." },
  { category: "XSS", note: "Document contexts where user input is reflected, then test only inside training labs." },
  { category: "SQLi", note: "Record input points and expected database error/boolean behavior in lab environments." },
  { category: "SSRF", note: "Map request-making features and document safe callback testing notes in a lab." },
  { category: "Auth", note: "Create a checklist for session, cookie, JWT, and OAuth review." },
  { category: "API", note: "Track endpoint, method, auth requirement, object ID, and rate-limit observations." }
];

function payloadLibraryBlocks(title) {
  return [
    { id: uid(), type: "heading", content: title },
    { id: uid(), type: "callout", content: "Payload notes are for authorized labs, CTFs, and owned environments only. Keep real target data out of this page." },
    { id: uid(), type: "subheading", content: "Categories" },
    { id: uid(), type: "bulleted", content: "Recon notes" },
    { id: uid(), type: "bulleted", content: "XSS lab notes" },
    { id: uid(), type: "bulleted", content: "SQLi lab notes" },
    { id: uid(), type: "bulleted", content: "SSRF lab notes" },
    { id: uid(), type: "bulleted", content: "Auth / API notes" },
    { id: uid(), type: "subheading", content: "One-Click Copy Area" },
    { id: uid(), type: "code", content: "Add your own lab-safe payload or command note here." },
    { id: uid(), type: "subheading", content: "Random Drill" },
    { id: uid(), type: "text", content: "Use the Random Payload button to insert a safe training drill into the current page." }
  ];
}

function toolkitBlocks(title) {
  return [
    { id: uid(), type: "heading", content: title },
    { id: uid(), type: "text", content: "Build small tool notes, command builders, and copy-ready snippets for authorized labs." },
    { id: uid(), type: "subheading", content: "Tool Card" },
    { id: uid(), type: "checklist", checked: false, content: "Purpose" },
    { id: uid(), type: "checklist", checked: false, content: "Inputs" },
    { id: uid(), type: "checklist", checked: false, content: "Safe lab example" },
    { id: uid(), type: "checklist", checked: false, content: "Notes / references" }
  ];
}

const PAGE_TEMPLATES = {
  vulnerability: vulnerabilityBlocks("New Vulnerability"),
  tool: toolBlocks("New Tool"),
  lab: labBlocks("New Lab"),
  writeup: [
    { id: uid(), type: "heading", content: "Writeup" },
    { id: uid(), type: "subheading", content: "Summary" },
    { id: uid(), type: "text", content: "What was the goal and what did you learn?" },
    { id: uid(), type: "subheading", content: "Steps" },
    { id: uid(), type: "text", content: "Document the authorized lab workflow in a clear, safe, educational way." },
    { id: uid(), type: "subheading", content: "Lessons Learned" },
    { id: uid(), type: "text", content: "Mistakes, key ideas, and notes for next time." }
  ],
  report: [
    { id: uid(), type: "heading", content: "Bug Bounty Report" },
    { id: uid(), type: "subheading", content: "Summary" },
    { id: uid(), type: "text", content: "Clear, respectful, and reproducible summary." },
    { id: uid(), type: "subheading", content: "Impact" },
    { id: uid(), type: "text", content: "Explain practical risk without exaggeration." },
    { id: uid(), type: "subheading", content: "Evidence" },
    { id: uid(), type: "text", content: "Attach screenshots and safe reproduction notes." },
    { id: uid(), type: "subheading", content: "Remediation" },
    { id: uid(), type: "text", content: "Suggest clear fixes and references." }
  ],
  case: caseBlocks("Forensics Case"),
  project: projectBlocks("Programming Project"),
  snippet: snippetBlocks("Snippet"),
  evidence: evidenceBlocks("Evidence"),
  reverse: reverseBlocks("Reverse Engineering Note"),
  research: researchBlocks("Research Note")
};
