# Red Team OS v2.4 — Notion Polish Update

This version is built on the stable v2.3 base and focuses on making the editor cleaner, lighter, and closer to a Notion-style writing experience.

## Highlights

- Cleaner Notion-like editor canvas.
- Empty pages show only: `Type / for commands`.
- Better slash menu with core blocks only.
- Simpler subpages rows.
- Right panel can be hidden or shown with a small toggle.
- Workspace Tools stay inside the floating orb.
- Bottom dock is hidden for a cleaner workspace.
- Search now supports:
  - Current Workspace
  - All Workspaces
- Top bar is quieter: Search, New Page, and session timer stay visible.
- Blocks, insert rows, callouts, toggles, and code blocks are visually softer.
- Reading view gets a temporary cleaner mode.

## Notes

All data is still saved locally in your browser. Use Backup regularly before moving to a newer version.


## v2.5

Added: page preview, smart templates, page covers, mini TOC polish, stronger local marketplace, link previews, page lock, per-workspace theme mood, and page health.

Not added in this version: Custom Slash Commands, Daily Session Summary, and Clean HTML Export.
